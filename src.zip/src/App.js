
import 'bootstrap/dist/css/bootstrap.min.css';
import {BrowserRouter,Routes,Route}from 'react-router-dom';
import Logincomponent from './Components/Logincomponent';
import EmployeeList from './Components/EmployeeList';
import PayHeads from './Components/PayHeads';
import Dashboard from './Components/Dashboard';

import Sidebar from './Components/Sidebar';
import EmployeeDetail from './Components/EmployeeDetail';
import Salaries from './Components/Salaries';
import SalaryForm from './Components/SalaryForm';
import SelectMonth from './Components/SelectMonth';
import SalaryCalculator from './Components/SalaryCalculator';
import SalaryCal from './Components/SalaryCal';
import SalaryCal1 from './Components/salarycal1';

import MonthSalaryCalculator from './Components/MonthSalaryCalculator';
import TotaOfMonth from './Components/TotalOfMonth';
import MainComponent from './Components/MainComponent';
import PayrunCard from './Components/PayrunCard';
import SalaryList from './Components/SalaryList';
import SalaryCalculator1 from './Components/SalaryCalculator1';



function App() {
  return (
    <div>
    <BrowserRouter>

    <Routes>
<Route path="/"  element={ <Logincomponent/>  }/>
<Route path="/Dashboard"  element={ <Dashboard/>  }/>
<Route path="/EmployeeList"  element={ <EmployeeList/>  }/>
<Route path="/PayHeads"  element={ <PayHeads/>  }/>
<Route path="/Dashboard"  element={ <Dashboard/>  }/>
<Route path="/Sidebar"  element={ <Sidebar/>  }/>
<Route path="/Salaries"  element={ <Salaries/>  }/>
<Route path="/SalaryForm"  element={ <SalaryForm/>  }/>
<Route path="/SalaryCalculator"  element={ <SalaryCalculator/>  }/>
<Route path="/SalaryCal"  element={ <SalaryCal/>  }/>
<Route path="/SalaryList"  element={ <SalaryList/>  }/>
<Route path="/SalaryCal1"  element={ <SalaryCal1/>  }/>
<Route path="/SalaryService"  element={ <salaryService/>  }/>
<Route path="/MonthSalaryCalculator"  element={ <MonthSalaryCalculator/>  }/>
<Route path="/TotalOfMonth"  element={ <TotaOfMonth/>  }/>
<Route path="/MainComponent"  element={ <MainComponent/>  }/>
<Route path= "/PayrunCard" element={<PayrunCard/>}/>
<Route path= "/SalaryCalculator1" element={<SalaryCalculator1/>}/>
{/* {/* <Route path="/SelectMonth" exact component={SelectMonth} /> */}

</Routes>
</BrowserRouter>
    </div>
   
  );
}

export default App;

