import React, { useState } from 'react';
import axios from 'axios';
import { Container, Form, Button, Row, Col, Card } from 'react-bootstrap';
import SalaryMonthModal from './SalaryMonthModal'; // Adjust the import path as per your file structure

const SalaryCal1 = () => {
  const [empCode, setEmpCode] = useState('');
  const [earnings, setEarnings] = useState(0);
  const [deductions, setDeductions] = useState(0);
  const [payheadAmounts, setPayheadAmounts] = useState([]);
  const [result, setResult] = useState(null);
  const [showModal, setShowModal] = useState(false); // State to control modal visibility
  const [selectedMonth, setSelectedMonth] = useState('');
  const [selectedYear, setSelectedYear] = useState('');

  const handlePayheadChange = (index, field, value) => {
    const newPayheadAmounts = [...payheadAmounts];
    newPayheadAmounts[index][field] = value;
    setPayheadAmounts(newPayheadAmounts);
  };

  const handleAddPayhead = () => {
    setPayheadAmounts([...payheadAmounts, { id: null, amount: 0, paytype: 'Earnings' }]);
  };

  const handleOpenModal = () => {
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };

  const handleMonthSelect = (month, year) => {
    setSelectedMonth(month);
    setSelectedYear(year);
    setShowModal(false); // Close modal after selecting month
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8080/api/salary/calculate', {
        empCode,
        salaryMonth: `${selectedMonth} ${selectedYear}`,
        earnings,
        deductions,
        payheadAmounts
      });
      setResult(response.data);
    } catch (error) {
      console.error('Error calculating salary:', error);
    }
  };

  return (
    <Container>
      <h1 className="my-4">Salary Calculator</h1>
      <Form onSubmit={handleSubmit}>
        {/* Existing form inputs */}
        {/* Add button to open modal */}
        <Button variant="primary" onClick={handleOpenModal}>Select Salary Month</Button>

        {/* Payhead Amounts rendering */}
        {/* Submit button */}
        <Button variant="success" type="submit" className="mt-3">Calculate Salary</Button>
      </Form>

      {/* Render modal */}
      <SalaryMonthModal
        handleClose={handleCloseModal}
        show={showModal}
        onMonthSelect={handleMonthSelect}
      />

      {/* Display results */}
      {result && (
        <Card className="mt-4">
          <Card.Body>
            <h2>Salary Details</h2>
            <p><strong>Net Salary:</strong> {result.netSalary}</p>
            <p><strong>Earnings Total:</strong> {result.earningsTotal}</p>
            <p><strong>Deductions Total:</strong> {result.deductionsTotal}</p>
          </Card.Body>
        </Card>
      )}
    </Container>
  );
};

export default SalaryCal1;
