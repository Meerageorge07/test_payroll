
// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import './PayrunCard.css';

// const PayrunCard = () => {
//   const [payrun, setPayrun] = useState(null);
//   const [paymentDate, setPaymentDate] = useState('');
//   const [loading, setLoading] = useState(true);
//   const [employees, setEmployees] = useState([]);

//   useEffect(() => {
//     // Fetch the payrun details from the backend
//     axios.get("http://localhost:8080/api/payroll/latest")
//       .then(response => {
//         setPayrun(response.data);
//         setPaymentDate(response.data.paymentDate);
//         setLoading(false);
//       })
//       .catch(error => {
//         console.error('Error fetching payrun data', error);
//         setLoading(false);
//       });
//   }, []);

//   useEffect(() => {
//     // Fetch employee details associated with the payrun
//     if (payrun) {
//       axios.get(`http://localhost:8080/api/payroll/${payrun.id}/employees`)
//         .then(response => {
//           setEmployees(response.data);
//         })
//         .catch(error => {
//           console.error('Error fetching employee details', error);
//         });
//     }
//   }, [payrun]);

//   const handlePaymentDateChange = (event) => {
//     setPaymentDate(event.target.value);
//   };

//   const handleSave = () => {
//     // Update the payment date in the backend
//     axios.put(`http://localhost:8080/api/payroll/${payrun.id}`, { paymentDate })
//       .then(response => {
//         setPayrun(response.data);
//         alert('Payment date updated successfully');
//       })
//       .catch(error => {
//         console.error('Error updating payment date', error);
//         alert('Failed to update payment date');
//       });
//   };

//   const handleViewDetails = () => {
//     // Implement view details functionality here (expand details or modal)
//     console.log('View Details clicked');
//     // Example: Show detailed employee and salary information
//     // This can be implemented as a modal or expanded section in the card
//   };

//   if (loading) {
//     return <div>Loading...</div>;
//   }

//   if (!payrun) {
//     return <div>No payrun data available</div>;
//   }

//   return (
//     <div className="payrun-card">
//       <h2>Employee Net Salary</h2>
//       <p>Net Pay: ${payrun.employeesNetPay}</p>
//       <p>Payment Start Date: {payrun.paymentStartDate}</p>
//       <p>
//         Payment Date: 
//         <input
//           type="date"
//           value={paymentDate}
//           onChange={handlePaymentDateChange}
//         />
//       </p>
//       <p>Status: {payrun.payStatus}</p>
//       <button onClick={handleSave}>Save</button>
//       <button onClick={handleViewDetails}>View Details</button>

//       {/* Modal for detailed employee information */}
//       {employees.length > 0 && (
//         <div className="modal">
//           <div className="modal-content">
//             <span className="close" onClick={() => setEmployees([])}>&times;</span>
//             <h3>Employee Details</h3>
//             {employees.map(employee => (
//               <div key={employee.id}>
//                 <p>Name: {employee.name}</p>
//                 <p>Position: {employee.position}</p>
//                 {/* Add more fields as needed */}
//               </div>
//             ))}
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default PayrunCard;
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import SalaryList from './SalaryList'; // Import the SalaryList component
import './PayrunCard.css';
import Sidebar from './Sidebar';

const PayrunCard = () => {
  const [payrun, setPayrun] = useState(null);
  const [paymentDate, setPaymentDate] = useState('');
  const [loading, setLoading] = useState(true);
  const [employees, setEmployees] = useState([]);
  const [showSalaryList, setShowSalaryList] = useState(false); // State to control visibility of SalaryList

  useEffect(() => {
    // Fetch the payrun details from the backend
    axios.get("http://localhost:8080/api/payroll/latest")
      .then(response => {
        setPayrun(response.data);
        setPaymentDate(response.data.paymentDate);
        setLoading(false);
      })
      .catch(error => {
        console.error('Error fetching payrun data', error);
        setLoading(false);
      });
  }, []);

  useEffect(() => {
    // Fetch employee details associated with the payrun
    if (payrun) {
      axios.get(`http://localhost:8080/api/payroll/${payrun.id}/employees`)
        .then(response => {
          setEmployees(response.data);
        })
        .catch(error => {
          console.error('Error fetching employee details', error);
        });
    }
  }, [payrun]);

  const handlePaymentDateChange = (event) => {
    setPaymentDate(event.target.value);
  };

  const handleSave = () => {
    // Update the payment date in the backend
    axios.put(`http://localhost:8080/api/payroll/${payrun.id}`, { paymentDate })
      .then(response => {
        setPayrun(response.data);
        alert('Payment date updated successfully');
      })
      .catch(error => {
        console.error('Error updating payment date', error);
        alert('Failed to update payment date');
      });
  };

  const handleViewDetails = () => {
    setShowSalaryList(true); // Show the SalaryList component
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (!payrun) {
    return <div>No payrun data available</div>;
  }

  return (
    <div className="main-layout">
    <Sidebar />
    <div className="content">
      <h2>Employee Net Salary</h2>
      <p>Net Pay: {payrun.employeesNetPay}</p>
      <p>Payment Start Date: {payrun.paymentStartDate}</p>
      <p>
        Payment Date: 
        <input
          type="date"
          value={paymentDate}
          onChange={handlePaymentDateChange}
        />
      </p>
      <p>Status: {payrun.payStatus}</p>
      <button onClick={handleSave}>Save</button>
      <button onClick={handleViewDetails}>View Details</button>

      {/* Conditionally render SalaryList component */}
      {showSalaryList && <SalaryList />}
    </div> </div>
  );
};

export default PayrunCard;
