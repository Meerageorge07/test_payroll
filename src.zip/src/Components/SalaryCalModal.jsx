// import React, { useState } from 'react';
// import axios from 'axios';
// import { Modal, Button, Form } from 'react-bootstrap';
// import DatePicker from 'react-datepicker';
// import 'react-datepicker/dist/react-datepicker.css';

// const SalaryCalModal = ({ showModal, handleCloseModal, handleSalarySubmit }) => {
//   const [empCode, setEmpCode] = useState('');
//   const [salaryMonth, setSalaryMonth] = useState(new Date());
//   const [earnings, setEarnings] = useState(0);
//   const [deductions, setDeductions] = useState(0);
//   const [result, setResult] = useState(null);

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       const formattedMonth = `${salaryMonth.getFullYear()}-${('0' + (salaryMonth.getMonth() + 1)).slice(-2)}`;
//       const response = await axios.post('http://localhost:8080/api/salary/calculate', {
//         empCode,
//         salaryMonth: formattedMonth,
//         earnings,
//         deductions
//       });
//       setResult(response.data);
//       handleSalarySubmit(response.data); // Pass data to parent component
//       handleCloseModal(); // Close modal after submission
//     } catch (error) {
//       console.error('Error calculating salary:', error);
//     }
//   };

//   return (
//     <Modal show={showModal} onHide={handleCloseModal}>
//       <Modal.Header closeButton>
//         <Modal.Title>Salary Calculator</Modal.Title>
//       </Modal.Header>
//       <Modal.Body>
//         <Form onSubmit={handleSubmit}>
//           <Form.Group controlId="formEmployeeCode">
//             <Form.Label>Employee Code</Form.Label>
//             <Form.Control
//               type="text"
//               value={empCode}
//               onChange={(e) => setEmpCode(e.target.value)}
//               required
//             />
//           </Form.Group>

//           <Form.Group controlId="formSalaryMonth">
//             <Form.Label>Salary Month</Form.Label>
//             <DatePicker
//               selected={salaryMonth}
//               onChange={date => setSalaryMonth(date)}
//               dateFormat="MM/yyyy"
//               showMonthYearPicker
//               className="form-control"
//               required
//             />
//           </Form.Group>

//           <Form.Group controlId="formEarnings">
//             <Form.Label>Earnings</Form.Label>
//             <Form.Control
//               type="number"
//               value={earnings}
//               onChange={(e) => setEarnings(parseFloat(e.target.value))}
//               required
//             />
//           </Form.Group>

//           <Form.Group controlId="formDeductions">
//             <Form.Label>Deductions</Form.Label>
//             <Form.Control
//               type="number"
//               value={deductions}
//               onChange={(e) => setDeductions(parseFloat(e.target.value))}
//               required
//             />
//           </Form.Group>

//           <Button variant="primary" type="submit">
//             Calculate Salary
//           </Button>
//         </Form>
//       </Modal.Body>
//       <Modal.Footer>
//         <Button variant="secondary" onClick={handleCloseModal}>
//           Close
//         </Button>
//       </Modal.Footer>
//     </Modal>
//   );
// };

// export default SalaryCalModal;
import React, { useState } from 'react';
import axios from 'axios';
import { Modal, Button, Form } from 'react-bootstrap';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

const SalaryCalModal = ({ showModal, handleCloseModal, handleSalarySubmit, handleSalaryCreatedMessage }) => {
  const [empCode, setEmpCode] = useState('');
  const [salaryMonth, setSalaryMonth] = useState(new Date());
  const [earnings, setEarnings] = useState(0);
  const [deductions, setDeductions] = useState(0);
  const [result, setResult] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const formattedMonth = `${salaryMonth.getFullYear()}-${('0' + (salaryMonth.getMonth() + 1)).slice(-2)}`;
      const response = await axios.post('http://localhost:8080/api/salary/calculate', {
        empCode,
        salaryMonth: formattedMonth,
        earnings,
        deductions
      });
      setResult(response.data);
      handleSalarySubmit(response.data); // Pass data to parent component
      handleSalaryCreatedMessage('Salary created successfully!'); // Pass message to parent component
      handleCloseModal(); // Close modal after submission
    } catch (error) {
      console.error('Error calculating salary:', error);
    }
  };

  return (
    <Modal show={showModal} onHide={handleCloseModal}>
      <Modal.Header closeButton>
        <Modal.Title>Salary Calculator</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <Form onSubmit={handleSubmit}>
          <Form.Group controlId="formEmployeeCode">
            <Form.Label>Employee Code</Form.Label>
            <Form.Control
              type="text"
              value={empCode}
              onChange={(e) => setEmpCode(e.target.value)}
              required
            />
          </Form.Group>

          <Form.Group controlId="formSalaryMonth">
            <Form.Label>Salary Month</Form.Label>
            <DatePicker
              selected={salaryMonth}
              onChange={date => setSalaryMonth(date)}
              dateFormat="MM/yyyy"
              showMonthYearPicker
              className="form-control"
              required
            />
          </Form.Group>

          <Form.Group controlId="formEarnings">
            <Form.Label>Earnings</Form.Label>
            <Form.Control
              type="number"
              value={earnings}
              onChange={(e) => setEarnings(parseFloat(e.target.value))}
              required
            />
          </Form.Group>

          <Form.Group controlId="formDeductions">
            <Form.Label>Deductions</Form.Label>
            <Form.Control
              type="number"
              value={deductions}
              onChange={(e) => setDeductions(parseFloat(e.target.value))}
              required
            />
          </Form.Group>

          <Button variant="primary" type="submit">
            Calculate Salary
          </Button>
        </Form>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleCloseModal}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default SalaryCalModal;

