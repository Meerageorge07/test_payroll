import { useState } from "react";
import { Link,useNavigate } from 'react-router-dom';
import axios from "axios";
import { toast, ToastContainer } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';


function Logincomponent() {

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [passwordError, setPasswordError] = useState("");
    const [emailError, setEmailError] = useState("");

   const navigate = useNavigate();

    const validateForm = () => {
        let valid = true;
        if (!email) {
            setEmailError("This field is required");
            valid = false;
        } else {
            setEmailError("");
        }
        if (!password) {
            setPasswordError("This field is required");
            valid = false;
        } else {
            setPasswordError("");
        }
        return valid;
    };

    const login = async (event) => {
        event.preventDefault();
        if (!validateForm()) return;

        try {
            const response = await axios.post("http://localhost:8080/login/role", {
                email: email,
                password: password,
            });

            console.log(response.data);
            const role = response.data;

            if (role === 'user is admin') {
                localStorage.setItem('user', JSON.stringify(response.data.user));
                navigate('/Dashboard');
            } else if (role === 'user is an employee') {
              // navigate('/Home');
              toast.error("employee");
            } else {
                toast.error("Invalid email or password");
            }
        } catch (error) {
            console.error('Error logging in:', error);
            toast.error("Invalid email or password");
        }
    };

    return (
       
       
  
        <div className="row d-flex align-items-center justify-content-center mt-5">
            <ToastContainer position="top-center" />
            {/* <div className={CSS.bg}> */}
            <div>
                <div className="d-flex justify-content-center align-items-center">
                    <div className="col-md-4">
                        <form onSubmit={login}>
                            <div className="mt-5">
                                <div className="form-group">
                                    <label className="control-label">Email</label>
                                    <input
                                        type="text"
                                        placeholder="Enter your email"
                                        className="form-control"
                                        value={email}
                                        onChange={(event) => setEmail(event.target.value)}
                                    />
                                    {emailError && <small className="text-danger">{emailError}</small>}
                                </div>
                            </div>
                            <div className="mt-3">
                                <div data-mdb-input-init className="form-outline mb-4">
                                    <div className="form-group">
                                        <label className="control-label">Password</label>
                                        <input
                                            type="password"
                                            placeholder="Enter your password"
                                            className="form-control"
                                            value={password}
                                            onChange={(event) => setPassword(event.target.value)}
                                        />
                                        {passwordError && <small className="text-danger">{passwordError}</small>}
                                   <br></br>
                                        {/* <div className="text-end"> */}
                                            <Link to="/ForgotPassword" className="text-decoration-none">Forgot Password?</Link>
                                        {/* </div> */}
                                    </div>
                                </div>
                            </div>
                            <div className="form-group">
                                <div className="mt-3">
                                    <div className="mb-1">
                                        <button type="submit" className="btn btn-primary btn-block">Login</button>
                                    </div>
                                </div>
                            </div>
                            <br />
                            Don't have an account? <Link to="/Register" className="text-decoration-none">Register</Link>
                        </form>
                    </div>
                </div>
            {/* </div> */}
        </div>   </div>  
    );
}

export default Logincomponent;
