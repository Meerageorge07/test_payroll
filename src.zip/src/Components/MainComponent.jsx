import React, { useState } from 'react';
import axios from 'axios';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Sidebar from './Sidebar';

const TotalOfMonth = () => {
  const [salaryMonth, setSalaryMonth] = useState(null);
  const [netSalary, setNetSalary] = useState(null);
  const [error, setError] = useState(null);

  const handleDateChange = (date) => {
    setSalaryMonth(date);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!salaryMonth) {
      setError('Please select a month');
      return;
    }
    setError(null);

    try {
      const response = await axios.get('http://localhost:8080/api/salary/totalNetSalary', {
        params: { salaryMonth: salaryMonth.toISOString().slice(0, 7) }
      });
      setNetSalary(response.data);
    // setNetSalary(response)
    } catch (err) {
      setError('Failed to fetch the total net salary');
      console.error(err);
    }
  };

  return (
    <div className="card">
      <div className="card-body">
        <h1 className="card-title">Total Net Salary</h1>
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label className="form-label">
              Select Salary Month:
              <DatePicker
                selected={salaryMonth}
                onChange={handleDateChange}
                dateFormat="yyyy-MM"
                showMonthYearPicker
                className="form-control"
                placeholderText="YYYY-MM"
              />
            </label>
          </div>
          <button type="submit" className="btn btn-primary mb-3">
            Get Total Net Salary
          </button>
        </form>
        {error && <div className="alert alert-danger">{error}</div>}
        {netSalary !== null && (
          <div className="card mt-3">
            <div className="card-body">
              <h2 className="card-title">Net Salary</h2>
              <div className="mb-3">
                <div className="d-flex justify-content-between">
                  <span>Total Net Salary:</span>
                  <span>{netSalary}</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const MonthSalaryCalculator = () => {
  const [empCode, setEmpCode] = useState('');
  const [monthlySalary, setMonthlySalary] = useState(null);
  const [error, setError] = useState('');

  const getMonthlyNetSalary = async (empCode) => {
    const BASE_URL = 'http://localhost:8080'; // Replace with your actual backend URL
    try {
      const response = await fetch(`${BASE_URL}/api/salary/employees/${empCode}/monthly-net-salary`);
      if (!response.ok) {
        throw new Error('Error fetching monthly salary');
      }
      const data = await response.json();
      return data; // Assuming API response structure returns monthlySalary
    } catch (error) {
      throw new Error('Error fetching monthly salary');
    }
  };

  const handleCalculate = async () => {
    try {
      const salary = await getMonthlyNetSalary(empCode);
      setMonthlySalary(salary);
      console.log(salary);
      setError('');
    } catch (error) {
      setError('Error fetching monthly salary. Please try again.');
      setMonthlySalary(null);
    }
  };

  return (
    <div className="card">
      <div className="card-body">
        <h1 className="card-title">Salary Calculator</h1>
        <div className="mb-3">
          <label className="form-label">
            Employee ID:
            <input
              type="text"
              className="form-control"
              value={empCode}
              onChange={(e) => setEmpCode(e.target.value)}
            />
          </label>
        </div>
        <button className="btn btn-primary mb-3" onClick={handleCalculate}>
          Calculate Monthly Salary
        </button>
        {error && <div className="alert alert-danger">{error}</div>}
        {monthlySalary !== null && (
          <div className="card mt-3">
            <div className="card-body">
              <h2 className="card-title">Monthly Salary</h2>
              <div className="mb-3">
                <div className="d-flex justify-content-between">
                  <span>Monthly Salary:</span>
                  <span>{monthlySalary}</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const MainComponent = () => {
  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-lg-3 col-md-4 col-sm-5 mt-5">
          <Sidebar />
        </div>
        <div className="col-lg-9 col-md-8 col-sm-7 mt-5">
          <div className="row">
            <div className="col-md-6 mb-4">
              <TotalOfMonth />
            </div>
            <div className="col-md-6 mb-4">
              <MonthSalaryCalculator />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MainComponent;
