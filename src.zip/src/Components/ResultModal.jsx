// src/ResultModal.js

import React from 'react';
import { Modal, Button } from 'react-bootstrap';

const ResultModal = ({ show, handleClose, calculatedSalary }) => {
    return (
        <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
                <Modal.Title>Calculated Salary</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                {calculatedSalary ? (
                    <div>
                        <p>Employee: {calculatedSalary.employees.name}</p>
                        <p>Salary Month: {calculatedSalary.salaryMonth}</p>
                        <p>Earnings Total: {calculatedSalary.earningsTotal}</p>
                        <p>Deductions Total: {calculatedSalary.deductionsTotal}</p>
                        <p>Net Salary: {calculatedSalary.netSalary}</p>
                    </div>
                ) : (
                    <p>No salary calculated.</p>
                )}
            </Modal.Body>
            <Modal.Footer>
                <Button variant="secondary" onClick={handleClose}>
                    Close
                </Button>
            </Modal.Footer>
        </Modal>
    );
};

export default ResultModal;
