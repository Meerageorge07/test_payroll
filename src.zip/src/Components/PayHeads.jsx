
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Button } from 'react-bootstrap';
import AddPayHeadModal from './AddPayHeadModal';
import Sidebar from './Sidebar';
import './PayHeads.css';

const PayHeads = () => {
    const [payHeads, setPayHeads] = useState([]);
    const [showModal, setShowModal] = useState(false);

    useEffect(() => {
        fetchPayHeads(); // Fetch pay heads on component mount
    }, []);

    const fetchPayHeads = async() => {

      try{ 
        const response=await axios.get('http://localhost:8080/api/payheads')
           
                setPayHeads(response.data);
            }
            catch (error) {
                console.error('Error fetching pay heads:', error);
            };
    };

    const handleCloseModal = () => setShowModal(false);
    const handleShowModal=()=>setShowModal(true);
//

    const handleAddPayHead = async(newPayHead) => {
        try{
      await  axios.post('http://localhost:8080/api/payheads', newPayHead)
            fetchPayHeads();
            //    setPayHeads([...payHeads, response.data]);
                handleCloseModal(); // Close modal after successful addition
            }
            catch(error){
                console.error('Error creating pay head:', error);
            };
    };

    const getBadgeVariant = (paytype) => {
        return paytype === 'Deductions' ? 'bg-danger text-white' : 'bg-success'; // Red for deductions, green for earnings
    };

    return (
        <div className="main-layout">
            <Sidebar/>
            <div className="content">
                <div className="container mt-4">
                    <div className="d-flex justify-content-end mb-4">
                        <Button variant="primary" onClick={() => setShowModal(true)}>
                            Add Pay Head
                        </Button>
                    </div>
                    {/* <h2 className="text-center">Payheads</h2> */}
                    <div className="container mt-4">
                    <table className="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Type</th>
                            </tr>
                        </thead>
                        <tbody>
                            {payHeads.map((payheads, index) => (
                                <tr key={payheads.id}>
                                    <td>{payheads.name}</td>
                                    <td>
                                        <span className={`badge rounded-pill ${getBadgeVariant(payheads.paytype)}`}>
                                            {payheads.paytype}
                                        </span>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    <AddPayHeadModal
                        show={showModal}
                        handleClose={handleCloseModal}
                        handleAddPayHead={handleAddPayHead}
                    />
                </div>
            </div>
        </div></div>
    );
};

export default PayHeads;
//=======================================

