// src/services/salaryService.js
import axios from 'axios';

const API_URL = 'http://localhost:8080/api/salary/employees';

export const getGrossSalary = async (employeeId) => {
  try {
    const response = await axios.get(`${API_URL}/${employeeId}`);
    return response.data;
  } catch (error) {
    console.error('Error fetching gross salary:', error);
    throw error;
  }
};
