// import React, { useState } from 'react';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import Sidebar from './Sidebar';

// const MonthSalaryCalculator = () => {
//   const [empCode, setEmpCode] = useState('');
//   const [monthlySalary, setMonthlySalary] = useState(null);

//   const [error, setError] = useState('');

//   const getMonthlyNetSalary = async (empCode) => {
//     const BASE_URL = 'http://localhost:8080'; // Replace with your actual backend URL
//     try {
//       const response = await fetch(`${BASE_URL}/api/salary/net}/${empCode}`);
//       if (!response.ok) {
//         throw new Error('Error fetching monthly salary');
//       }
//       const data = await response.json();
//       return data; // Assuming API response structure returns monthlySalary
//     } catch (error) {
//       throw new Error('Error fetching monthly salary');
//     }
//   };

//   const handleCalculate = async () => {
//     try {
//       const salary = await getMonthlyNetSalary(empCode);
//       setMonthlySalary(salary);
//       console.log(salary);
//       setError('');
//     } catch (error) {
//       setError('Error fetching monthly salary. Please try again.');
//       setMonthlySalary(null);
//     }
//   };

//   return (
//     <div className="container-fluid">
//       <div className="row">
//         <div className="col-lg-5 col-md-4 col-sm-5 mt-5">
//           {/* Sidebar component or other components */}
//           <Sidebar />
//         </div>
//         <div className="col-lg-5 col-md-5 col-sm-5 mt-5">
//           <div className="card">
//             <div className="card-body">
//               <h1 className="card-title">Salary Calculator</h1>
//               <div className="mb-3">
//                 <label className="form-label">
//                   Employee ID:
//                   <input
//                     type="text"
//                     className="form-control"
//                     value={empCode}
//                     onChange={(e) => setEmpCode(e.target.value)}
//                   />
//                 </label>
//               </div>
//               <button className="btn btn-primary mb-3" onClick={handleCalculate}>
//                 Calculate Monthly Salary
//               </button>
//               {error && <div className="alert alert-danger">{error}</div>}
//               {monthlySalary !== null && (
//                 <div className="card mt-3">
//                   <div className="card-body">
//                     <h2 className="card-title">Monthly Salary</h2>
//                     <div className="mb-3">
//                       <div className="d-flex justify-content-between">
//                         <span>Monthly Salary:</span>
//                         <span>{monthlySalary}</span>
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               )}
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default MonthSalaryCalculator;
import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import Sidebar from './Sidebar';

const MonthSalaryCalculator = () => {
  const [empCode, setEmpCode] = useState('');
  const [monthlySalary, setMonthlySalary] = useState(null);
  const [error, setError] = useState('');

  const getMonthlyNetSalary = async (empCode) => {
    const BASE_URL = 'http://localhost:8080/api/salary/net'; // Replace with your actual backend URL
    try {
      const response = await fetch(`${BASE_URL}/${empCode}`); // Corrected the URL
      if (!response.ok) {
        throw new Error('Error fetching monthly salary');
      }
      const data = await response.json();
      return data; // Assuming API response structure returns monthlySalary
    } catch (error) {
      throw new Error('Error fetching monthly salary');
    }
  };

  const handleCalculate = async () => {
    try {
      const salary = await getMonthlyNetSalary(empCode);
      setMonthlySalary(salary);
      setError('');
    } catch (error) {
      setError('Error fetching monthly salary. Please try again.');
      setMonthlySalary(null);
    }
  };

  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-lg-5 col-md-4 col-sm-5 mt-5">
          <Sidebar />
        </div>
        <div className="col-lg-5 col-md-5 col-sm-5 mt-5">
          <div className="card">
            <div className="card-body">
              <h1 className="card-title">Salary Calculator</h1>
              <div className="mb-3">
                <label className="form-label">
                  Employee ID:
                  <input
                    type="text"
                    className="form-control"
                    value={empCode}
                    onChange={(e) => setEmpCode(e.target.value)}
                  />
                </label>
              </div>
              <button className="btn btn-primary mb-3" onClick={handleCalculate}>
                Calculate Monthly Salary
              </button>
              {error && <div className="alert alert-danger">{error}</div>}
              {monthlySalary !== null && (
                <div className="card mt-3">
                  <div className="card-body">
                    <h2 className="card-title">Monthly Salary</h2>
                    <div className="mb-3">
                      <div className="d-flex justify-content-between">
                        <span>Monthly Salary:</span>
                        <span>{monthlySalary}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MonthSalaryCalculator;
