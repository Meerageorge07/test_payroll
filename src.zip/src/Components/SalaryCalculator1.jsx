// import React, { useState } from 'react';
// import axios from 'axios';

// const SalaryCalculator1 = () => {
//     const [empCode, setEmpCode] = useState('');
//     const [payheads, setPayheads] = useState([]);
//     const [earnings, setEarnings] = useState({});
//     const [deductions, setDeductions] = useState({});
//     const [message, setMessage] = useState('');

//     const handleInputChange = (event) => {
//         setEmpCode(event.target.value);
//     };

//     const fetchPayheads = async () => {
//         try {
//             const response = await axios.get(`http://localhost:8080/payhead/payheads?empCode=${empCode}`);
//             setPayheads(response.data);
//         } catch (error) {
//             console.error('Error fetching payheads', error);
//         }
//     };

//     const handleAmountChange = (event, type) => {
//         const { name, value } = event.target;
//         if (type === 'earnings') {
//             setEarnings({ ...earnings, [name]: parseFloat(value) });
//         } else {
//             setDeductions({ ...deductions, [name]: parseFloat(value) });
//         }
//     };

    
//     const handleSubmit = async (event) => {
//             event.preventDefault();
//            setMessage('');  // Clear any previous messages
    
//         try {
//             const response = await axios.post('http://localhost:8080/payhead/update', {
//                 earnings,
//                 deductions
//             }, {
//                 headers: {
//                     'Content-Type': 'application/json'
//                 },
//                 params: {
//                     empCode: empCode
//                 }
//             });
    
//             if (response.status === 200) {
//                 setMessage('Salary update successful.');
//             } else {
//                 setMessage('Failed to update salary.');
//             }
//         } catch (error) {
//             console.error('Error updating salary', error);
//             setMessage('Error updating salary. Please try again.');
//         }
//     };
    
//     return (
//         <div className="salary-calculator">
//             <h2>Calculate Salary</h2>
//             <form onSubmit={handleSubmit}>
//                 <div>
//                     <label htmlFor="empCode">Employee Code:</label>
//                     <input
//                         type="text"
//                         id="empCode"
//                         value={empCode}
//                         onChange={handleInputChange}
//                     />
//                 </div>
//                 <button type="button" onClick={fetchPayheads}>Fetch Payheads</button>

//                 {payheads.length > 0 && (
//                     <>
//                         <h3>Earnings</h3>
//                         {payheads.filter(ph => ph.paytype === 'Earnings').map(ph => (
//                             <div key={ph.payId}>
//                                 <label>{ph.name}</label>
//                                 <input
//                                     type="number"
//                                     name={ph.name}
//                                     onChange={(e) => handleAmountChange(e, 'earnings')}
//                                 />
//                             </div>
//                         ))}

//                         <h3>Deductions</h3>
//                         {payheads.filter(ph => ph.paytype === 'Deductions').map(ph => (
//                             <div key={ph.payId}>
//                                 <label>{ph.name}</label>
//                                 <input
//                                     type="number"
//                                     name={ph.name}
//                                     onChange={(e) => handleAmountChange(e, 'deductions')}
//                                 />
//                             </div>
//                         ))}
//                     </>
//                 )}

//                 <button type="submit">Update Salary</button>
//             </form>
//             {message && <p>{message}</p>}
//         </div>
//     );
// };

// export default SalaryCalculator1;
// src/components/SalaryCalculator1.jsx

// import React, { useState } from 'react';
// import axios from 'axios';
// import './SalaryCalculator1.css';

// const SalaryCalculator1 = ({ onClose }) => {
//     const [empCode, setEmpCode] = useState('');
//     const [payheads, setPayheads] = useState([]);
//     const [earnings, setEarnings] = useState({});
//     const [deductions, setDeductions] = useState({});
//     const [message, setMessage] = useState('');

//     const handleInputChange = (event) => {
//         setEmpCode(event.target.value);
//     };

//     const fetchPayheads = async () => {
//         try {
//             const response = await axios.get(`http://localhost:8080/payhead/payheads?empCode=${empCode}`);
//             setPayheads(response.data);
//         } catch (error) {
//             console.error('Error fetching payheads', error);
//         }
//     };

//     const handleAmountChange = (event, type) => {
//         const { name, value } = event.target;
//         if (type === 'earnings') {
//             setEarnings({ ...earnings, [name]: parseFloat(value) });
//         } else {
//             setDeductions({ ...deductions, [name]: parseFloat(value) });
//         }
//     };

//     const handleSubmit = async (event) => {
//         event.preventDefault();
//         setMessage('');

//         try {
//             const response = await axios.post('http://localhost:8080/payhead/update', {
//                 earnings,
//                 deductions
//             }, {
//                 headers: {
//                     'Content-Type': 'application/json'
//                 },
//                 params: {
//                     empCode: empCode
//                 }
//             });

//             if (response.status === 200) {
//                 setMessage('Salary update successful.');
//             } else {
//                 setMessage('Failed to update salary.');
//             }
//         } catch (error) {
//             console.error('Error updating salary', error);
//             setMessage('Error updating salary. Please try again.');
//         }
//     };

//     return (
//         <div className="salary-calculator">
//             <div className="salary-calculator-content">
//                 <button className="close-btn" onClick={onClose}>X</button>
//                 <h2>Calculate Salary</h2>
//                 <form onSubmit={handleSubmit}>
//                     <div>
//                         <label htmlFor="empCode">Employee Code:</label>
//                         <input
//                             type="text"
//                             id="empCode"
//                             value={empCode}
//                             onChange={handleInputChange}
//                         />
//                     </div>
//                     <button type="button" onClick={fetchPayheads}>Fetch Payheads</button>

//                     {payheads.length > 0 && (
//                         <>
//                             <h3>Earnings</h3>
//                             {payheads.filter(ph => ph.paytype === 'Earnings').map(ph => (
//                                 <div key={ph.payId}>
//                                     <label>{ph.name}</label>
//                                     <input
//                                         type="number"
//                                         name={ph.name}
//                                         onChange={(e) => handleAmountChange(e, 'earnings')}
//                                     />
//                                 </div>
//                             ))}

//                             <h3>Deductions</h3>
//                             {payheads.filter(ph => ph.paytype === 'Deductions').map(ph => (
//                                 <div key={ph.payId}>
//                                     <label>{ph.name}</label>
//                                     <input
//                                         type="number"
//                                         name={ph.name}
//                                         onChange={(e) => handleAmountChange(e, 'deductions')}
//                                     />
//                                 </div>
//                             ))}
//                         </>
//                     )}

//                     <button type="submit">Update Salary</button>
//                 </form>
//                 {message && <p>{message}</p>}
//             </div>
//         </div>
//     );
// };

// export default SalaryCalculator1;
// src/components/SalaryCalculator1.jsx

// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import './SalaryCalculator1.css';

// const SalaryCalculator1 = ({ onClose, isOpen }) => {
//     const [empCode, setEmpCode] = useState('');
//     const [payheads, setPayheads] = useState([]);
//     const [earnings, setEarnings] = useState({});
//     const [deductions, setDeductions] = useState({});
//     const [message, setMessage] = useState('');

//     useEffect(() => {
//         if (isOpen) {
//             setEmpCode('');
//             setPayheads([]);
//             setEarnings({});
//             setDeductions({});
//             setMessage('');
//         }
//     }, [isOpen]);

//     const handleInputChange = (event) => {
//         setEmpCode(event.target.value);
//     };

//     const fetchPayheads = async () => {
//         try {
//             const response = await axios.get(`http://localhost:8080/payhead/payheads?empCode=${empCode}`);
//             setPayheads(response.data);
//         } catch (error) {
//             console.error('Error fetching payheads', error);
//         }
//     };

//     const handleAmountChange = (event, type) => {
//         const { name, value } = event.target;
//         if (type === 'earnings') {
//             setEarnings({ ...earnings, [name]: parseFloat(value) });
//         } else {
//             setDeductions({ ...deductions, [name]: parseFloat(value) });
//         }
//     };

//     const handleSubmit = async (event) => {
//         event.preventDefault();
//         setMessage('');

//         try {
//             const response = await axios.post('http://localhost:8080/payhead/update', {
//                 earnings,
//                 deductions
//             }, {
//                 headers: {
//                     'Content-Type': 'application/json'
//                 },
//                 params: {
//                     empCode: empCode
//                 }
//             });

//             if (response.status === 200) {
//                 setMessage('Salary update successful.');
//             } else {
//                 setMessage('Failed to update salary.');
//             }
//         } catch (error) {
//             console.error('Error updating salary', error);
//             setMessage('Error updating salary. Please try again.');
//         }
//     };

//     return (
//         <div className={`salary-calculator ${isOpen ? 'open' : ''}`}>
//             <div className="salary-calculator-content">
//                 <button className="close-btn" onClick={onClose}>X</button>
//                 <h2>Calculate Salary</h2>
//                 <form onSubmit={handleSubmit}>
//                     <div>
//                         <label htmlFor="empCode">Employee Code:</label>
//                         <input
//                             type="text"
//                             id="empCode"
//                             value={empCode}
//                             onChange={handleInputChange}
//                         />
//                     </div>
//                     <button type="button" onClick={fetchPayheads}>Fetch Payheads</button>

//                     {payheads.length > 0 && (
//                         <>
//                             <h3>Earnings</h3>
//                             {payheads.filter(ph => ph.paytype === 'Earnings').map(ph => (
//                                 <div key={ph.payId}>
//                                     <label>{ph.name}</label>
//                                     <input
//                                         type="number"
//                                         name={ph.name}
//                                         onChange={(e) => handleAmountChange(e, 'earnings')}
//                                     />
//                                 </div>
//                             ))}

//                             <h3>Deductions</h3>
//                             {payheads.filter(ph => ph.paytype === 'Deductions').map(ph => (
//                                 <div key={ph.payId}>
//                                     <label>{ph.name}</label>
//                                     <input
//                                         type="number"
//                                         name={ph.name}
//                                         onChange={(e) => handleAmountChange(e, 'deductions')}
//                                     />
//                                 </div>
//                             ))}
//                         </>
//                     )}

//                     <button type="submit">Update Salary</button>
//                 </form>
//                 {message && <p>{message}</p>}
//             </div>
//         </div>
//     );
// };

// export default SalaryCalculator1;
///////////////////////////////////////////////////////////////////////////////////
// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import './SalaryCalculator1.css';

// const SalaryCalculator1 = ({ onClose, isOpen, onUpdate }) => {
//     const [empCode, setEmpCode] = useState('');
//     const [payheads, setPayheads] = useState([]);
//     const [earnings, setEarnings] = useState({});
//     const [deductions, setDeductions] = useState({});
//     const [message, setMessage] = useState('');

//     useEffect(() => {
//         if (isOpen) {
//             setEmpCode('');
//             setPayheads([]);
//             setEarnings({});
//             setDeductions({});
//             setMessage('');
//         }
//     }, [isOpen]);

//     const handleInputChange = (event) => {
//         setEmpCode(event.target.value);
//     };

//     const fetchPayheads = async () => {
//         try {
//             const response = await axios.get(`http://localhost:8080/payhead/payheads?empCode=${empCode}`);
//             setPayheads(response.data);
//         } catch (error) {
//             console.error('Error fetching payheads', error);
//         }
//     };

//     const handleAmountChange = (event, type) => {
//         const { name, value } = event.target;
//         if (type === 'earnings') {
//             setEarnings({ ...earnings, [name]: parseFloat(value) });
//         } else {
//             setDeductions({ ...deductions, [name]: parseFloat(value) });
//         }
//     };

//     const handleSubmit = async (event) => {
//         event.preventDefault();
//         setMessage('');

//         try {
//             const response = await axios.post('http://localhost:8080/payhead/update', {
//                 earnings,
//                 deductions
//             }, {
//                 headers: {
//                     'Content-Type': 'application/json'
//                 },
//                 params: {
//                     empCode: empCode
//                 }
//             });

//             if (response.status === 200) {
//                 setMessage('Salary update successful.');
//                 onUpdate(); // Call the callback to notify parent component
//             } else {
//                 setMessage('Failed to update salary.');
//             }
//         } catch (error) {
//             console.error('Error updating salary', error);
//             setMessage('Error updating salary. Please try again.');
//         }
//     };

//     return (
//         <div className={`salary-calculator ${isOpen ? 'open' : ''}`}>
//             <div className="salary-calculator-content">
//                 <button className="close-btn" onClick={onClose}>X</button>
//                 <h2>Calculate Salary</h2>
//                 <form onSubmit={handleSubmit}>
//                     <div>
//                         <label htmlFor="empCode">Employee Code:</label>
//                         <input
//                             type="text"
//                             id="empCode"
//                             value={empCode}
//                             onChange={handleInputChange}
//                         />
//                     </div>
//                     <button type="button" onClick={fetchPayheads}>Fetch Payheads</button>

//                     {payheads.length > 0 && (
//                         <>
//                             <h3>Earnings</h3>
//                             {payheads.filter(ph => ph.paytype === 'Earnings').map(ph => (
//                                 <div key={ph.payId}>
//                                     <label>{ph.name}</label>
//                                     <input
//                                         type="number"
//                                         name={ph.name}
//                                         onChange={(e) => handleAmountChange(e, 'earnings')}
//                                     />
//                                 </div>
//                             ))}

//                             <h3>Deductions</h3>
//                             {payheads.filter(ph => ph.paytype === 'Deductions').map(ph => (
//                                 <div key={ph.payId}>
//                                     <label>{ph.name}</label>
//                                     <input
//                                         type="number"
//                                         name={ph.name}
//                                         onChange={(e) => handleAmountChange(e, 'deductions')}
//                                     />
//                                 </div>
//                             ))}
//                         </>
//                     )}

//                     <button type="submit">Update Salary</button>
//                 </form>
//                 {message && <p>{message}</p>}
//             </div>
//         </div>
//     );
// };

// export default SalaryCalculator1;
/////////////////////////////////////////////////////////////////////////////////////
// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import './SalaryCalculator1.css';

// const SalaryCalculator1 = ({ onClose, isOpen, onUpdate, employee }) => {
//     const [empCode, setEmpCode] = useState('');
//     const [payheads, setPayheads] = useState([]);
//     const [earnings, setEarnings] = useState({});
//     const [deductions, setDeductions] = useState({});
//     const [message, setMessage] = useState('');

//     useEffect(() => {
//         if (isOpen && employee) {
//             setEmpCode(employee.empCode);
//             fetchPayheads(employee.empCode);
//             setMessage('');
//         }
//     }, [isOpen, employee]);

//     const fetchPayheads = async (empCode) => {
//         try {
//             const response = await axios.get(`http://localhost:8080/payhead/payheads?empCode=${empCode}`);
//             setPayheads(response.data);
//         } catch (error) {
//             console.error('Error fetching payheads', error);
//         }
//     };

//     const handleAmountChange = (event, type) => {
//         const { name, value } = event.target;
//         if (type === 'earnings') {
//             setEarnings({ ...earnings, [name]: parseFloat(value) });
//         } else {
//             setDeductions({ ...deductions, [name]: parseFloat(value) });
//         }
//     };

//     const handleSubmit = async (event) => {
//         event.preventDefault();
//         setMessage('');

//         try {
//             const response = await axios.post('http://localhost:8080/payhead/update', {
//                 earnings,
//                 deductions
//             }, {
//                 headers: {
//                     'Content-Type': 'application/json'
//                 },
//                 params: {
//                     empCode: empCode
//                 }
//             });

//             if (response.status === 200) {
//                 setMessage('Salary update successful.');
//                 onUpdate(); // Call the callback to notify parent component
//             } else {
//                 setMessage('Failed to update salary.');
//             }
//         } catch (error) {
//             console.error('Error updating salary', error);
//             setMessage('Error updating salary. Please try again.');
//         }
//     };

//     return (
//         <div className={`salary-calculator ${isOpen ? 'open' : ''}`}>
//             <div className="salary-calculator-content">
//                 <button className="close-btn" onClick={onClose}>X</button>
//                 <h2>Calculate Salary</h2>
//                 <form onSubmit={handleSubmit}>
//                     <div>
//                         <label htmlFor="empCode">Employee Code:</label>
//                         <input
//                             type="text"
//                             id="empCode"
//                             value={empCode}
//                             readOnly
//                         />
//                     </div>

//                     {payheads.length > 0 && (
//                         <>
//                             <h3>Earnings</h3>
//                             {payheads.filter(ph => ph.paytype === 'Earnings').map(ph => (
//                                 <div key={ph.payId}>
//                                     <label>{ph.name}</label>
//                                     <input
//                                         type="number"
//                                         name={ph.name}
//                                         onChange={(e) => handleAmountChange(e, 'earnings')}
//                                     />
//                                 </div>
//                             ))}

//                             <h3>Deductions</h3>
//                             {payheads.filter(ph => ph.paytype === 'Deductions').map(ph => (
//                                 <div key={ph.payId}>
//                                     <label>{ph.name}</label>
//                                     <input
//                                         type="number"
//                                         name={ph.name}
//                                         onChange={(e) => handleAmountChange(e, 'deductions')}
//                                     />
//                                 </div>
//                             ))}
//                         </>
//                     )}

//                     <button type="submit">Update Salary</button>
//                 </form>
//                 {message && <p>{message}</p>}
//             </div>
//         </div>
//     );
// };

// export default SalaryCalculator1;
/////////////////////////////////////////
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './SalaryCalculator1.css';

const SalaryCalculator1 = ({ onClose, isOpen, onUpdate, employee, onSave }) => {
    const [empCode, setEmpCode] = useState('');
    const [payheads, setPayheads] = useState([]);
    const [earnings, setEarnings] = useState({});
    const [deductions, setDeductions] = useState({});
    const [message, setMessage] = useState('');

    useEffect(() => {
        if (isOpen && employee) {
            setEmpCode(employee.empCode);
            fetchPayheads(employee.empCode);
            setMessage('');
        }
    }, [isOpen, employee]);

    const fetchPayheads = async (empCode) => {
        try {
            const response = await axios.get(`http://localhost:8080/payhead/payheads?empCode=${empCode}`);
            setPayheads(response.data);
        } catch (error) {
            console.error('Error fetching payheads', error);
        }
    };

    const handleAmountChange = (event, type) => {
        const { name, value } = event.target;
        if (type === 'earnings') {
            setEarnings({ ...earnings, [name]: parseFloat(value) });
        } else {
            setDeductions({ ...deductions, [name]: parseFloat(value) });
        }
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        setMessage('');

        try {
            const response = await axios.post('http://localhost:8080/payhead/update', {
                earnings,
                deductions
            }, {
                headers: {
                    'Content-Type': 'application/json'
                },
                params: {
                    empCode: empCode
                }
            });

            if (response.status === 200) {
                setMessage('Salary update successful.');
                onUpdate(); // Call the callback to notify parent component
                onSave({ empCode, earnings, deductions }); // Pass the updated data to the parent component
            } else {
                setMessage('Failed to update salary.');
            }
        } catch (error) {
            console.error('Error updating salary', error);
            setMessage('Error updating salary. Please try again.');
        }
    };

    return (
        <div className={`salary-calculator ${isOpen ? 'open' : ''}`}>
            <div className="salary-calculator-content">
                <button className="close-btn" onClick={onClose}>X</button>
                <h2>Calculate Salary</h2>
                <form onSubmit={handleSubmit}>
                    <div>
                        <label htmlFor="empCode">Employee Code:</label>
                        <input
                            type="text"
                            id="empCode"
                            value={empCode}
                            readOnly
                        />
                    </div>

                    {payheads.length > 0 && (
                        <>
                            <h3>Earnings</h3>
                            {payheads.filter(ph => ph.paytype === 'Earnings').map(ph => (
                                <div key={ph.payId}>
                                    <label>{ph.name}</label>
                                    <input
                                        type="number"
                                        name={ph.name}
                                        onChange={(e) => handleAmountChange(e, 'earnings')}
                                    />
                                </div>
                            ))}

                            <h3>Deductions</h3>
                            {payheads.filter(ph => ph.paytype === 'Deductions').map(ph => (
                                <div key={ph.payId}>
                                    <label>{ph.name}</label>
                                    <input
                                        type="number"
                                        name={ph.name}
                                        onChange={(e) => handleAmountChange(e, 'deductions')}
                                    />
                                </div>
                            ))}
                        </>
                    )}

                    <button type="submit">Update Salary</button>
                </form>
                {message && <p>{message}</p>}
            </div>
        </div>
    );
};

export default SalaryCalculator1;
