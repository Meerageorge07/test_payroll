// // // src/AddSalaryModal.js

// // import React, { useState, useEffect } from 'react';
// // import { Modal, Button, Form } from 'react-bootstrap';

// // const AddSalaryModal = ({ show, handleClose, handleSubmit, salaryMonth }) => {
// //     const [empCode, setEmpCode] = useState('');
// //     const [earnings, setEarnings] = useState('');
// //     const [deductions, setDeductions] = useState('');

// //     useEffect(() => {
// //         // Pre-fill the employee code and salary month if available
// //         if (salaryMonth) {
// //             setEmpCode(salaryMonth.employee.empCode);
// //         }
// //     }, [salaryMonth]);

// //     const onSubmit = (e) => {
// //         e.preventDefault();
// //         handleSubmit({
// //             empCode,
// //             salaryMonth,
// //             earnings: parseFloat(earnings),
// //             deductions: parseFloat(deductions),
// //         });
// //         handleClose();
// //     };

// //     return (
// //         <Modal show={show} onHide={handleClose}>
// //             <Modal.Header closeButton>
// //                 <Modal.Title>Add Salary</Modal.Title>
// //             </Modal.Header>
// //             <Modal.Body>
// //                 <Form onSubmit={onSubmit}>
// //                     <Form.Group controlId="formEmpCode">
// //                         <Form.Label>Employee Code</Form.Label>
// //                         <Form.Control
// //                             type="text"
// //                             value={empCode}
// //                             onChange={(e) => setEmpCode(e.target.value)}
// //                             required
// //                         />
// //                     </Form.Group>
// //                     <Form.Group controlId="formSalaryMonth">
// //                         <Form.Label>Salary Month</Form.Label>
// //                         <Form.Control
// //                             type="text"
// //                             value={salaryMonth}
// //                             readOnly
// //                             required
// //                         />
// //                     </Form.Group>
// //                     <Form.Group controlId="formEarnings">
// //                         <Form.Label>Earnings</Form.Label>
// //                         <Form.Control
// //                             type="number"
// //                             step="0.01"
// //                             value={earnings}
// //                             onChange={(e) => setEarnings(e.target.value)}
// //                             required
// //                         />
// //                     </Form.Group>
// //                     <Form.Group controlId="formDeductions">
// //                         <Form.Label>Deductions</Form.Label>
// //                         <Form.Control
// //                             type="number"
// //                             step="0.01"
// //                             value={deductions}
// //                             onChange={(e) => setDeductions(e.target.value)}
// //                             required
// //                         />
// //                     </Form.Group>
// //                     <Button variant="primary" type="submit">
// //                         Calculate
// //                     </Button>
// //                 </Form>
// //             </Modal.Body>
// //         </Modal>
// //     );
// // };

// // export default AddSalaryModal;
// // import React, { useState, useEffect } from 'react';
// // import axios from 'axios';
// // import 'bootstrap/dist/css/bootstrap.min.css';
// // import 'bootstrap/dist/js/bootstrap.bundle.min';

// // const SalaryMonthModal = ({ employee, handleClose, showAddSalaryModal, onSalaryCreated }) => {
// //   const [months, setMonths] = useState([]);
// //   const [years, setYears] = useState([]);
// //   const [payheads, setPayheads] = useState([]);
// //   const [selectedPayheads, setSelectedPayheads] = useState([]);
// //   const [selectedMonth, setSelectedMonth] = useState(null);
// //   const [selectedYear, setSelectedYear] = useState(null);

// //   useEffect(() => {
// //     const calculateMonthsAndYears = () => {
// //       const currentMonth = new Date().getMonth() + 1;
// //       const currentYear = new Date().getFullYear();
// //       const before2Month = currentMonth - 2;
// //       const monthsArray = [];
// //       const yearsArray = [];

// //       for (let i = before2Month; i < before2Month + 16; i++) {
// //         const date = new Date(currentYear, i, 1);
// //         monthsArray.push(date.toLocaleString('default', { month: 'long' }));
// //         yearsArray.push(date.getFullYear());
// //       }

// //       setMonths(monthsArray);
// //       setYears(yearsArray);
// //     };

// //     calculateMonthsAndYears();

// //     const fetchPayheads = async () => {
// //       try {
// //         const response = await axios.get("http://localhost:8080/api/payheads");
// //         setPayheads(response.data);
// //       } catch (error) {
// //         console.error("Error fetching payheads:", error);
// //       }
// //     };

// //     fetchPayheads();
// //   }, []);

// //   const handleMonthClick = (month, year) => {
// //     setSelectedMonth(month);
// //     setSelectedYear(year);
// //   };

// //   const handlePayheadChange = (index, amount) => {
// //     const newSelectedPayheads = [...selectedPayheads];
// //     newSelectedPayheads[index] = {
// //       ...newSelectedPayheads[index],
// //       amount: parseFloat(amount) || 0
// //     };
// //     setSelectedPayheads(newSelectedPayheads);
// //   };

// //   const handlePayheadSelect = (payhead) => {
// //     setSelectedPayheads([...selectedPayheads, { ...payhead, amount: 0 }]);
// //   };

// //   const handleRemovePayhead = (index) => {
// //     const newSelectedPayheads = selectedPayheads.filter((_, i) => i !== index);
// //     setSelectedPayheads(newSelectedPayheads);
// //   };

// //   const calculateTotals = () => {
// //     let earnings = 0;
// //     let deductions = 0;
// //     selectedPayheads.forEach((payhead) => {
// //       if (payhead.type === "earning") {
// //         earnings += payhead.amount;
// //       } else if (payhead.type === "deduction") {
// //         deductions += payhead.amount;
// //       }
// //     });
// //     return { earnings, deductions };
// //   };

// //   const handleSubmit = async () => {
// //     const { earnings, deductions } = calculateTotals();
// //     const salaryData = {
// //       empCode: employee.empCode,
// //       name: employee.name,
// //       salaryMonth: `${selectedMonth} ${selectedYear}`,
// //       earnings,
// //       deductions,
// //       netSalary: earnings - deductions,
// //       payheads: selectedPayheads
// //     };

// //     try {
// //       const response = await axios.post("http://localhost:8080/api/salary", salaryData);
// //       onSalaryCreated(response.data);
// //       handleClose();
// //     } catch (error) {
// //       console.error("Error creating salary:", error);
// //     }
// //   };

// //   return (
// //     <div className={`modal fade show`} style={{ display: 'block' }} tabIndex="-1">
// //       <div className="modal-dialog">
// //         <div className="modal-content">
// //           <div className="modal-header">
// //             <button type="button" className="close" aria-label="Close" onClick={handleClose}>
// //               <span aria-hidden="true">&times;</span>
// //             </button>
// //             <h4 className="modal-title">Select Month for Salary</h4>
// //           </div>
// //           <div className="modal-body">
// //             {!selectedMonth && !selectedYear ? (
// //               <div className="row">
// //                 {months.map((month, index) => (
// //                   <div
// //                     key={index}
// //                     className={`col-sm-3 ${month === new Date().toLocaleString('default', { month: 'long' }) && years[index] === new Date().getFullYear() ? 'bg-danger' : ''}`}
// //                   >
// //                     <a href="#" onClick={() => handleMonthClick(month, years[index])}>
// //                       {month.toUpperCase()}<br />{years[index]}
// //                     </a>
// //                   </div>
// //                 ))}
// //               </div>
// //             ) : (
// //               <div>
// //                 <div className="form-group">
// //                   <label htmlFor="selectedMonth">Selected Month</label>
// //                   <input
// //                     type="text"
// //                     className="form-control"
// //                     id="selectedMonth"
// //                     value={`${selectedMonth} ${selectedYear}`}
// //                     readOnly
// //                   />
// //                 </div>
// //                 <div className="form-group">
// //                   <label htmlFor="payheadSelect">Select Payhead</label>
// //                   <select
// //                     className="form-control"
// //                     id="payheadSelect"
// //                     onChange={(e) => handlePayheadSelect(payheads.find(ph => ph.id === parseInt(e.target.value)))}
// //                   >
// //                     <option value="">--Select Payhead--</option>
// //                     {payheads.map((payhead) => (
// //                       <option key={payhead.id} value={payhead.id}>
// //                         {payhead.name} ({payhead.type})
// //                       </option>
// //                     ))}
// //                   </select>
// //                 </div>
// //                 <div>
// //                   {selectedPayheads.map((payhead, index) => (
// //                     <div key={index} className="form-group">
// //                       <label>{payhead.name} ({payhead.type})</label>
// //                       <input
// //                         type="number"
// //                         className="form-control"
// //                         value={payhead.amount}
// //                         onChange={(e) => handlePayheadChange(index, e.target.value)}
// //                       />
// //                       <button className="btn btn-danger" onClick={() => handleRemovePayhead(index)}>Remove</button>
// //                     </div>
// //                   ))}
// //                 </div>
// //                 <button type="button" className="btn btn-primary" onClick={handleSubmit}>
// //                   Submit
// //                 </button>
// //               </div>
// //             )}
// //           </div>
// //         </div>
// //       </div>
// //     </div>
// //   );
// // };

// // export default SalaryMonthModal;
// import React, { useState } from 'react';
// import { Modal, Button, Form } from 'react-bootstrap';

// const AddSalaryModal = ({ show, handleClose, handleSubmit }) => {
//     const [data, setData] = useState({
//         empCode: '',
//         name: '',
//         salaryMonth: '',
//         earnings: 0,
//         deductions: 0,
//         netSalary: 0,
//         payheads: [],
//     });

//     const handleChange = (e) => {
//         const { name, value } = e.target;
//         setData({
//             ...data,
//             [name]: value,
//         });
//     };

//     const handleFormSubmit = () => {
//         handleSubmit(data);
//     };

//     return (
//         <Modal show={show} onHide={handleClose}>
//             <Modal.Header closeButton>
//                 <Modal.Title>Add Salary</Modal.Title>
//             </Modal.Header>
//             <Modal.Body>
//                 <Form>
//                     <Form.Group controlId="formEmpCode">
//                         <Form.Label>Employee Code</Form.Label>
//                         <Form.Control
//                             type="text"
//                             name="empCode"
//                             value={data.empCode}
//                             onChange={handleChange}
//                             required
//                         />
//                     </Form.Group>
//                     <Form.Group controlId="formName">
//                         <Form.Label>Employee Name</Form.Label>
//                         <Form.Control
//                             type="text"
//                             name="name"
//                             value={data.name}
//                             onChange={handleChange}
//                             required
//                         />
//                     </Form.Group>
//                     <Form.Group controlId="formSalaryMonth">
//                         <Form.Label>Salary Month</Form.Label>
//                         <Form.Control
//                             type="text"
//                             name="salaryMonth"
//                             value={data.salaryMonth}
//                             onChange={handleChange}
//                             required
//                         />
//                     </Form.Group>
//                     <Form.Group controlId="formEarnings">
//                         <Form.Label>Earnings</Form.Label>
//                         <Form.Control
//                             type="number"
//                             name="earnings"
//                             value={data.earnings}
//                             onChange={handleChange}
//                             required
//                         />
//                     </Form.Group>
//                     <Form.Group controlId="formDeductions">
//                         <Form.Label>Deductions</Form.Label>
//                         <Form.Control
//                             type="number"
//                             name="deductions"
//                             value={data.deductions}
//                             onChange={handleChange}
//                             required
//                         />
//                     </Form.Group>
//                     <Form.Group controlId="formNetSalary">
//                         <Form.Label>Net Salary</Form.Label>
//                         <Form.Control
//                             type="number"
//                             name="netSalary"
//                             value={data.earnings - data.deductions}
//                             readOnly
//                         />
//                     </Form.Group>
//                     <Button variant="primary" onClick={handleFormSubmit}>
//                         Submit
//                     </Button>
//                 </Form>
//             </Modal.Body>
//         </Modal>
//     );
// };

// export default AddSalaryModal;
import React, { useState } from 'react';
import { Modal, Button, Form } from 'react-bootstrap';

const AddSalaryModal = ({ show, handleClose, handleSubmit }) => {
    const [data, setData] = useState({
        empCode: '',
        name: '',
        salaryMonth: '',
        earnings: 0,
        deductions: 0,
        payheads: [{ payheadname: '', payAmount: 0, payType: '' }],
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setData({
            ...data,
            [name]: value,
        });
    };

    const handlePayheadChange = (index, e) => {
        const { name, value } = e.target;
        const payheads = [...data.payheads];
        payheads[index][name] = value;
        setData({ ...data, payheads });
    };

    const addPayhead = () => {
        setData({
            ...data,
            payheads: [...data.payheads, { payheadname: '', payAmount: 0, payType: '' }],
        });
    };

    const handleFormSubmit = () => {
        const formData = {
            ...data,
            netSalary: data.earnings - data.deductions,
        };
        handleSubmit(formData);
    };

    return (
        <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
                <Modal.Title>Add Salary</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Form>
                    <Form.Group controlId="formEmpCode">
                        <Form.Label>Employee Code</Form.Label>
                        <Form.Control
                            type="text"
                            name="empCode"
                            value={data.empCode}
                            onChange={handleChange}
                            required
                        />
                    </Form.Group>
                    <Form.Group controlId="formName">
                        <Form.Label>Employee Name</Form.Label>
                        <Form.Control
                            type="text"
                            name="name"
                            value={data.name}
                            onChange={handleChange}
                            required
                        />
                    </Form.Group>
                    <Form.Group controlId="formSalaryMonth">
                        <Form.Label>Salary Month</Form.Label>
                        <Form.Control
                            type="text"
                            name="salaryMonth"
                            value={data.salaryMonth}
                            onChange={handleChange}
                            required
                        />
                    </Form.Group>
                    <Form.Group controlId="formEarnings">
                        <Form.Label>Earnings</Form.Label>
                        <Form.Control
                            type="number"
                            name="earnings"
                            value={data.earnings}
                            onChange={handleChange}
                            required
                        />
                    </Form.Group>
                    <Form.Group controlId="formDeductions">
                        <Form.Label>Deductions</Form.Label>
                        <Form.Control
                            type="number"
                            name="deductions"
                            value={data.deductions}
                            onChange={handleChange}
                            required
                        />
                    </Form.Group>
                    {data.payheads.map((payhead, index) => (
                        <div key={index}>
                            <Form.Group controlId={`formPayheadname${index}`}>
                                <Form.Label>Payhead Name</Form.Label>
                                <Form.Control
                                    type="text"
                                    name="payheadname"
                                    value={payhead.payheadname}
                                    onChange={(e) => handlePayheadChange(index, e)}
                                    required
                                />
                            </Form.Group>
                            <Form.Group controlId={`formPayAmount${index}`}>
                                <Form.Label>Pay Amount</Form.Label>
                                <Form.Control
                                    type="number"
                                    name="payAmount"
                                    value={payhead.payAmount}
                                    onChange={(e) => handlePayheadChange(index, e)}
                                    required
                                />
                            </Form.Group>
                            <Form.Group controlId={`formPayType${index}`}>
                                <Form.Label>Pay Type</Form.Label>
                                <Form.Control
                                    type="text"
                                    name="payType"
                                    value={payhead.payType}
                                    onChange={(e) => handlePayheadChange(index, e)}
                                    required
                                />
                            </Form.Group>
                        </div>
                    ))}
                    <Button variant="secondary" onClick={addPayhead}>
                        Add Payhead
                    </Button>
                    <Form.Group controlId="formNetSalary">
                        <Form.Label>Net Salary</Form.Label>
                        <Form.Control
                            type="number"
                            name="netSalary"
                            value={data.earnings - data.deductions}
                            readOnly
                        />
                    </Form.Group>
                    <Button variant="primary" onClick={handleFormSubmit}>
                        Submit
                    </Button>
                </Form>
            </Modal.Body>
        </Modal>
    );
};

export default AddSalaryModal;
