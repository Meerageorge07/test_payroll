// // import React, { useState } from 'react';
// // import axios from 'axios';
// // import { Container, Form, Button, Row, Col, Card } from 'react-bootstrap';

// // const SalaryCal = () => {
// //   const [empCode, setEmpCode] = useState('');
// //   const [salaryMonth, setSalaryMonth] = useState('');
// //   const [earnings, setEarnings] = useState(0);
// //   const [deductions, setDeductions] = useState(0);
// //   const [payheadAmounts, setPayheadAmounts] = useState([]);
// //   const [result, setResult] = useState(null);

// //   const handlePayheadChange = (index, field, value) => {
// //     const newPayheadAmounts = [...payheadAmounts];
// //     newPayheadAmounts[index][field] = value;
// //     setPayheadAmounts(newPayheadAmounts);
// //   };

// //   const handleAddPayhead = () => {
// //     setPayheadAmounts([...payheadAmounts, { id: null, amount: 0, paytype: 'Earnings' }]);
// //   };

// //   const handleSubmit = async (e) => {
// //     e.preventDefault();
// //     try {
// //       const response = await axios.post('http://localhost:8080/api/salary/calculate', {
// //         empCode,
// //         salaryMonth,
// //         earnings,
// //         deductions,
// //         payheadAmounts
// //       });
// //       setResult(response.data);
// //     } catch (error) {
// //       console.error('Error calculating salary:', error);
// //     }
// //   };

// //   return (
// //     <Container>
// //       <h1 className="my-4">Salary Calculator</h1>
// //       <Form onSubmit={handleSubmit}>
// //         <Form.Group as={Row} controlId="formEmployeeCode">
// //           <Form.Label column sm={2}>Employee Code</Form.Label>
// //           <Col sm={10}>
// //             <Form.Control
// //               type="text"
// //               value={empCode}
// //               onChange={(e) => setEmpCode(e.target.value)}
// //               required
// //             />
// //           </Col>
// //         </Form.Group>

// //         <Form.Group as={Row} controlId="formSalaryMonth">
// //           <Form.Label column sm={2}>Salary Month</Form.Label>
// //           <Col sm={10}>
// //             <Form.Control
// //               type="text"
// //               value={salaryMonth}
// //               onChange={(e) => setSalaryMonth(e.target.value)}
// //               required
// //             />
// //           </Col>
// //         </Form.Group>

// //         <Form.Group as={Row} controlId="formEarnings">
// //           <Form.Label column sm={2}>Earnings</Form.Label>
// //           <Col sm={10}>
// //             <Form.Control
// //               type="number"
// //               value={earnings}
// //               onChange={(e) => setEarnings(parseFloat(e.target.value))}
// //               required
// //             />
// //           </Col>
// //         </Form.Group>

// //         <Form.Group as={Row} controlId="formDeductions">
// //           <Form.Label column sm={2}>Deductions</Form.Label>
// //           <Col sm={10}>
// //             <Form.Control
// //               type="number"
// //               value={deductions}
// //               onChange={(e) => setDeductions(parseFloat(e.target.value))}
// //               required
// //             />
// //           </Col>
// //         </Form.Group>

// //         <h3 className="my-3">Payhead Amounts</h3>
// //         {payheadAmounts.map((payhead, index) => (
// //           <Card className="mb-3" key={index}>
// //             <Card.Body>
// //               <Form.Group as={Row} controlId={`formPayheadAmount${index}`}>
// //                 <Form.Label column sm={2}>Amount</Form.Label>
// //                 <Col sm={4}>
// //                   <Form.Control
// //                     type="number"
// //                     value={payhead.amount}
// //                     onChange={(e) => handlePayheadChange(index, 'amount', parseFloat(e.target.value))}
// //                     required
// //                   />
// //                 </Col>
// //                 <Form.Label column sm={2}>Type</Form.Label>
// //                 <Col sm={4}>
// //                   <Form.Control
// //                     as="select"
// //                     value={payhead.paytype}
// //                     onChange={(e) => handlePayheadChange(index, 'paytype', e.target.value)}
// //                     required
// //                   >
// //                     <option value="Earnings">Earnings</option>
// //                     <option value="Deductions">Deductions</option>
// //                   </Form.Control>
// //                 </Col>
// //               </Form.Group>
// //             </Card.Body>
// //           </Card>
// //         ))}
// //         <Button variant="primary" onClick={handleAddPayhead}>Add Payhead</Button>

// //         <Button variant="success" type="submit" className="mt-3">Calculate Salary</Button>
// //       </Form>
// //       {result && (
// //         <Card className="mt-4">
// //           <Card.Body>
// //             <h2>Salary Details</h2>
// //             <p><strong>Net Salary:</strong> {result.netSalary}</p>
// //             <p><strong>Earnings Total:</strong> {result.earningsTotal}</p>
// //             <p><strong>Deductions Total:</strong> {result.deductionsTotal}</p>
// //           </Card.Body>
// //         </Card>
// //       )}
// //     </Container>
// //   );
// // };

// // export default SalaryCal;
// import React, { useState } from 'react';
// import axios from 'axios';
// import { Container, Form, Button, Row, Col, Card } from 'react-bootstrap';

// const SalaryCal = () => {
//   const [empCode, setEmpCode] = useState('');
//   const [salaryMonth, setSalaryMonth] = useState('');
//   const [earnings, setEarnings] = useState(0);
//   const [deductions, setDeductions] = useState(0);
//   const [payheadAmounts, setPayheadAmounts] = useState([]);
//   const [result, setResult] = useState(null);

//   const handlePayheadChange = (index, field, value) => {
//     const newPayheadAmounts = [...payheadAmounts];
//     newPayheadAmounts[index][field] = value;
//     setPayheadAmounts(newPayheadAmounts);
//   };

//   const handleAddPayhead = () => {
//     setPayheadAmounts([...payheadAmounts, { payid: null, paytype: 'Earnings', payname: '', payamount: 0 }]);
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       const response = await axios.post('http://localhost:8080/api/salary/calculate', {
//         empCode,
//         salaryMonth,
//         earnings,
//         deductions,
//         payheadAmounts
//       });
//       setResult(response.data);
//     } catch (error) {
//       console.error('Error calculating salary:', error);
//     }
//   };

//   return (
//     <Container>
//       <h1 className="my-4">Salary Calculator</h1>
//       <Form onSubmit={handleSubmit}>
//         <Form.Group as={Row} controlId="formEmployeeCode">
//           <Form.Label column sm={2}>Employee Code</Form.Label>
//           <Col sm={10}>
//             <Form.Control
//               type="text"
//               value={empCode}
//               onChange={(e) => setEmpCode(e.target.value)}
//               required
//             />
//           </Col>
//         </Form.Group>

//         <Form.Group as={Row} controlId="formSalaryMonth">
//           <Form.Label column sm={2}>Salary Month</Form.Label>
//           <Col sm={10}>
//             <Form.Control
//               type="text"
//               value={salaryMonth}
//               onChange={(e) => setSalaryMonth(e.target.value)}
//               required
//             />
//           </Col>
//         </Form.Group>

//         <Form.Group as={Row} controlId="formEarnings">
//           <Form.Label column sm={2}>Earnings</Form.Label>
//           <Col sm={10}>
//             <Form.Control
//               type="number"
//               value={earnings}
//               onChange={(e) => setEarnings(parseFloat(e.target.value))}
//               required
//             />
//           </Col>
//         </Form.Group>

//         <Form.Group as={Row} controlId="formDeductions">
//           <Form.Label column sm={2}>Deductions</Form.Label>
//           <Col sm={10}>
//             <Form.Control
//               type="number"
//               value={deductions}
//               onChange={(e) => setDeductions(parseFloat(e.target.value))}
//               required
//             />
//           </Col>
//         </Form.Group>

//         <h3 className="my-3">Payhead Amounts</h3>
//         {payheadAmounts.map((payhead, index) => (
//           <Card className="mb-3" key={index}>
//             <Card.Body>
//               <Form.Group as={Row} controlId={`formPayheadAmount${index}`}>
//                 <Form.Label column sm={2}>Pay ID</Form.Label>
//                 <Col sm={4}>
//                   <Form.Control
//                     type="text"
//                     value={payhead.payid}
//                     onChange={(e) => handlePayheadChange(index, 'payid', e.target.value)}
//                     required
//                   />
//                 </Col>
//                 <Form.Label column sm={2}>Pay Type</Form.Label>
//                 <Col sm={4}>
//                   <Form.Control
//                     as="select"
//                     value={payhead.paytype}
//                     onChange={(e) => handlePayheadChange(index, 'paytype', e.target.value)}
//                     required
//                   >
//                     <option value="Earnings">Earnings</option>
//                     <option value="Deductions">Deductions</option>
//                   </Form.Control>
//                 </Col>
//               </Form.Group>
//               <Form.Group as={Row} controlId={`formPayheadName${index}`}>
//                 <Form.Label column sm={2}>Pay Name</Form.Label>
//                 <Col sm={4}>
//                   <Form.Control
//                     type="text"
//                     value={payhead.payname}
//                     onChange={(e) => handlePayheadChange(index, 'payname', e.target.value)}
//                     required
//                   />
//                 </Col>
//                 <Form.Label column sm={2}>Pay Amount</Form.Label>
//                 <Col sm={4}>
//                   <Form.Control
//                     type="number"
//                     value={payhead.payamount}
//                     onChange={(e) => handlePayheadChange(index, 'payamount', parseFloat(e.target.value))}
//                     required
//                   />
//                 </Col>
//               </Form.Group>
//             </Card.Body>
//           </Card>
//         ))}
//         <Button variant="primary" onClick={handleAddPayhead}>Add Payhead</Button>

//         <Button variant="success" type="submit" className="mt-3">Calculate Salary</Button>
//       </Form>
//       {result && (
//         <Card className="mt-4">
//           <Card.Body>
//             <h2>Salary Details</h2>
//             <p><strong>Net Salary:</strong> {result.netSalary}</p>
//             <p><strong>Earnings Total:</strong> {result.earningsTotal}</p>
//             <p><strong>Deductions Total:</strong> {result.deductionsTotal}</p>
//           </Card.Body>
//         </Card>
//       )}
//     </Container>
//   );
// };

// export default SalaryCal;
import React, { useState } from 'react';
import axios from 'axios';
import { Modal, Button, Form } from 'react-bootstrap';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

const SalaryCal = () => {
  const [showModal, setShowModal] = useState(false);
  const [empCode, setEmpCode] = useState('');
  const [salaryMonth, setSalaryMonth] = useState(new Date());
  const [earnings, setEarnings] = useState(0);
  const [deductions, setDeductions] = useState(0);
  const [result, setResult] = useState(null);

  const handleShowModal = () => setShowModal(true);
  const handleCloseModal = () => setShowModal(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const formattedMonth = `${salaryMonth.getFullYear()}-${('0' + (salaryMonth.getMonth() + 1)).slice(-2)}`;
      const response = await axios.post('http://localhost:8080/api/salary/calculate', {
        empCode,
        salaryMonth: formattedMonth,
        earnings,
        deductions
      });
      setResult(response.data);
      setShowModal(false);
    } catch (error) {
      console.error('Error calculating salary:', error);
    }
  };

  return (
    <>
      <Button variant="primary" onClick={handleShowModal}>
        Open Salary Calculator
      </Button>

      <Modal show={showModal} onHide={handleCloseModal}>
        <Modal.Header closeButton>
          <Modal.Title>Salary Calculator</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form onSubmit={handleSubmit}>
            <Form.Group controlId="formEmployeeCode">
              <Form.Label>Employee Code</Form.Label>
              <Form.Control
                type="text"
                value={empCode}
                onChange={(e) => setEmpCode(e.target.value)}
                required
              />
            </Form.Group>

            <Form.Group controlId="formSalaryMonth">
              <Form.Label>Salary Month</Form.Label>
              <DatePicker
                selected={salaryMonth}
                onChange={date => setSalaryMonth(date)}
                dateFormat="MM/yyyy"
                showMonthYearPicker
                className="form-control"
                required
              />
            </Form.Group>

            <Form.Group controlId="formEarnings">
              <Form.Label>Earnings</Form.Label>
              <Form.Control
                type="number"
                value={earnings}
                onChange={(e) => setEarnings(parseFloat(e.target.value))}
                required
              />
            </Form.Group>

            <Form.Group controlId="formDeductions">
              <Form.Label>Deductions</Form.Label>
              <Form.Control
                type="number"
                value={deductions}
                onChange={(e) => setDeductions(parseFloat(e.target.value))}
                required
              />
            </Form.Group>

            <Button variant="primary" type="submit">
              Calculate Salary
            </Button>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>

      {result && (
        <div className="mt-4">
          <h2>Salary Details</h2>
          <p><strong>Net Salary:</strong> {result.netSalary}</p>
          <p><strong>Earnings Total:</strong> {result.earningsTotal}</p>
          <p><strong>Deductions Total:</strong> {result.deductionsTotal}</p>
        </div>
      )}
    </>
  );
};

export default SalaryCal;

