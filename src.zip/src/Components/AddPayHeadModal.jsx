

// import React, { useState } from 'react';
// import { Modal, Button, Form } from 'react-bootstrap';
// import axios from 'axios';

// const AddPayHeadModal = ({ show, handleClose,handleAddPayHead }) => {
//     const [form, setForm] = useState({ name: '', paytype: '' });

//     const handleChange = (e) => {
//         setForm({ ...form, [e.target.name]: e.target.value });
//     };

//     const handleSubmit = (e) => {
//         e.preventDefault();
        
//         const newPayHead = {
//             name: form.name,
//             paytype: form.paytype
//         };

//         handleAddPayHead(newPayHead);

//         axios.post('http://localhost:8080/api/payheads', newPayHead)
//             .then(response => {
//                 console.log('Pay head added:', response.data);
//                 handleClose(); // Close modal after successful addition
//                 setForm({ name: '', paytype: '' }); // Clear form fields
//             })
//             .catch(error => {
//                 console.error('Error adding pay head:', error);
//             });
//     };

//     return (
//         <Modal show={show} onHide={handleClose}>
//             <Modal.Header closeButton>
//                 <Modal.Title>Add Pay Head</Modal.Title>
//             </Modal.Header>
//             <Modal.Body>
//                 <Form onSubmit={handleSubmit}>
//                     <Form.Group className="mb-3" controlId="name">
//                         <Form.Label>Name</Form.Label>
//                         <Form.Control
//                             type="text"
//                             name="name"
//                             placeholder="Enter name"
//                             value={form.name}
//                             onChange={handleChange}
//                             required
//                         />
//                     </Form.Group>
//                     <Form.Group className="mb-3" controlId="type">
//                         <Form.Label>Type</Form.Label>
//                         <Form.Select
//                             name="paytype"
//                             value={form.paytype}
//                             onChange={handleChange}
//                             required
//                         >
//                             <option value="">Select Type</option>
//                             <option value="Earnings">Earnings</option>
//                             <option value="Deductions">Deductions</option>
//                         </Form.Select>
//                     </Form.Group>
//                     <Button variant="primary" type="submit">
//                         Add Payhead
//                     </Button>
//                 </Form>
//             </Modal.Body>
//         </Modal>
//     );
// };

// export default AddPayHeadModal;
import React, { useState } from 'react';
import { Modal, Button, Form } from 'react-bootstrap';

const AddPayHeadModal = ({ show, handleClose, handleAddPayHead }) => {
    const [form, setForm] = useState({ name: '', paytype: '' });

    const handleChange = (e) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        
        const newPayHead = {
            name: form.name,
            paytype: form.paytype
        };

        handleAddPayHead(newPayHead);

        handleClose(); // Close modal after successful addition
        setForm({ name: '', paytype: '' }); // Clear form fields
    };

    return (
        <Modal show={show} onHide={handleClose}>
            <Modal.Header closeButton>
                <Modal.Title>Add Pay Head</Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Form onSubmit={handleSubmit}>
                    <Form.Group className="mb-3" controlId="name">
                        <Form.Label>Name</Form.Label>
                        <Form.Control
                            type="text"
                            name="name"
                            placeholder="Enter name"
                            value={form.name}
                            onChange={handleChange}
                            required
                        />
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="type">
                        <Form.Label>Type</Form.Label>
                        <Form.Select
                            name="paytype"
                            value={form.paytype}
                            onChange={handleChange}
                            required
                        >
                            <option value="">Select Type</option>
                            <option value="Earnings">Earnings</option>
                            <option value="Deductions">Deductions</option>
                        </Form.Select>
                    </Form.Group>
                    <Button variant="primary" type="submit">
                        Add Payhead
                    </Button>
                </Form>
            </Modal.Body>
        </Modal>
    );
};

export default AddPayHeadModal;
