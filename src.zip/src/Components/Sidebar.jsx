import React from 'react';
import './Sidebar.css';

const Sidebar = () => {
  return (
    <div className="sidebar">
      <div className="profile">
        <img src="https://via.placeholder.com/100" alt="Profile" />
        <div className="profile-info">
          <h3>Admin</h3>
          <p>admin@gmail.com</p>
        </div>
      </div>
      <ul className="sidebar-menu">
      <li className="menu-item">
          <a href="/Dashboard">
            <i className="fas fa-users"></i>
            Home
          </a>
        </li>
        <li className="menu-item">
          <a href="/EmployeeList">
            <i className="fas fa-users"></i>
            Employees
          </a>
        </li>
        {/* <li className="menu-item">
          <a href="/Salaries">
            <i className="fas fa-money-bill-alt"></i>
            Monthly Salary Slip
          </a>
        </li> */}
        <li className="menu-item">
          <a href="/PayHeads">
            <i className="fas fa-file-invoice-dollar"></i>
            Payheads
          </a>
        </li>
        <li className="menu-item">
          <a href="/SalaryCalculator">
            <i className="fas fa-calculator"></i>
           Salary Components 
          </a>
        </li>
        {/* <li className="menu-item">
          <a href="/MonthSalaryCalculator">
            <i className="fas fa-calculator"></i>
            Monthly Salary Calculation
          </a>
        </li> */}
        <li className="menu-item">
          <a href="/PayrunCard">
            <i className="fas fa-calculator"></i>
           pay runs
          </a>
        </li>
        {/* <li className="menu-item">
          <a href="/TotalOfMonth">
            <i className="fas fa-calculator"></i>
            Monthly Total EmployeeSalary
          </a>
        </li> */}
         <li className="menu-item">
          <a href="/MonthSalaryCalculator">
            <i className="fas fa-money-bill-alt"></i>
            Month salary Calculation
          </a>
          </li>
         {/* <li className="menu-item">
          <a href="/MonthSalaryCalculator">
            <i className="fas fa-money-bill-alt"></i>
            Month Wise salary Calculation
          // </a> */}
          {/* // </li> */}
      </ul>
    </div>
  );
};

export default Sidebar;


