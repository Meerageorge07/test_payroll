// // src/components/SelectMonth.js
// import React, { useState } from 'react';
// import { useHistory } from 'react-router-dom';

// const SelectMonth = () => {
//   const [monthYear, setMonthYear] = useState('');
//   const history = useHistory();

//   const handleMonthYearChange = (e) => {
//     setMonthYear(e.target.value);
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     history.push({
//       pathname: '/salary-form',
//       state: { monthYear },
//     });
//   };

//   return (
//     <div>
//       <h1>Select Salary Month and Year</h1>
//       <form onSubmit={handleSubmit}>
//         <label>
//           Month and Year:
//           <input type="month" value={monthYear} onChange={handleMonthYearChange} required />
//         </label>
//         <button type="submit">Next</button>
//       </form>
//     </div>
//   );
// };

// export default SelectMonth;
