// src/App.js

import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import Sidebar from './Sidebar';

function TotalOfMonth() {
  const [salaryMonth, setSalaryMonth] = useState('');
  const [totalNetSalary, setTotalNetSalary] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleInputChange = (event) => {
    setSalaryMonth(event.target.value);
  };

  const fetchTotalNetSalary = async (event) => {
    event.preventDefault();
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch(`http://localhost:8080/api/salary/totalNetSalary?salaryMonth=${salaryMonth}`);
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      const data = await response.json();
      setTotalNetSalary(data);
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container-fluid">
    <div className="row">
      <div className="col-lg-5 col-md-4 col-sm-5 mt-5">
        
        <Sidebar />
      </div>
      <div className="col-lg-5 col-md-5 col-sm-5 mt-5">
      <div className="card">
        <div className="card-body">
          <h1 className="card-title text-center mb-4">Total </h1>
          <form onSubmit={fetchTotalNetSalary} className="mb-4">
            <div className="mb-3">
              <label htmlFor="salaryMonth" className="form-label">Salary Month:</label>
              <input
                type="text"
                id="salaryMonth"
                className="form-control"
                value={salaryMonth}
                onChange={handleInputChange}
                required
              />
            </div>
            <button type="submit" className="btn btn-primary">Fetch Total employee salary</button>
          </form>
          {loading && <p className="text-center">Loading...</p>}
          {error && <p className="text-danger text-center">Error: {error}</p>}
          {totalNetSalary !== null && !loading && !error && (
            <div className="card">
              <div className="card-body">
                {/* <h5 className="card-title">Total Net Salary</h5> */}
                <p className="card-text">Total Employee Salary for {salaryMonth}: {totalNetSalary}</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div></div></div>
  );
}

export default TotalOfMonth;
