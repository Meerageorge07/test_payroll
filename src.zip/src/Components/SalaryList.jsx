// import React, { useState, useEffect } from 'react';
// import axios from 'axios';

// const SalaryList = () => {
//   const [salaries, setSalaries] = useState([]);
//   const [message, setMessage] = useState(null);

//   useEffect(() => {
//     fetchSalaries();
//   }, []);

//   const fetchSalaries = () => {
//     axios.get('http://localhost:8080/api/salary/get')
//       .then(response => {
//         setSalaries(response.data);
//       })
//       .catch(error => {
//         console.error('Error fetching salaries:', error);
//       });
//   };

//   const handleUpdate = (id, updatedFields) => {
//     axios.put(`http://localhost:8080/api/salary/${id}`, updatedFields)
//       .then(response => {
//         const updatedSalaries = salaries.map(salary => {
//           if (salary.id === id) {
//             return {
//               ...salary,
//               ...updatedFields
//             };
//           }
//           return salary;
//         });
//         setSalaries(updatedSalaries);
//         setMessage({ type: 'success', text: 'Salary updated successfully.' });
//       })
//       .catch(error => {
//         console.error(`Error updating salary with ID ${id}:`, error);
//         setMessage({ type: 'error', text: 'Error updating salary. Please try again.' });
//       });
//   };

//   const handleInputChange = (id, field, value) => {
//     setSalaries(salaries.map(salary => 
//       salary.id === id ? { ...salary, [field]: value } : salary
//     ));
//   };

//   const handleUpdateClick = (id) => {
//     const salary = salaries.find(salary => salary.id === id);
//     const updatedFields = {
//       paidDays: salary.paidDays,
//       taxes: salary.taxes,
//       earnings: salary.earnings,
//       deductionsTotal: salary.deductionsTotal,
//       netSalary: salary.netSalary
//     };

//     handleUpdate(id, updatedFields);
//   };

//   const calculateNetSalary = (empCode, earnings, deductions, taxes) => {
//     axios.put(`http://localhost:8080/api/salary/calculate/${empCode}`, {
//       earnings,
//       deductions,
//       taxes
//     })
//     .then(response => {
//       const updatedSalaries = salaries.map(salary => {
//         if (salary.employees.empCode === empCode) {
//           return {
//             ...salary,
//             netSalary: response.data.netSalary,
//             earnings: response.data.earnings,
//             deductionsTotal: response.data.deductionsTotal,
//             taxes: response.data.taxes
//           };
//         }
//         return salary;
//       });
//       setSalaries(updatedSalaries);
//       setMessage({ type: 'success', text: 'Net salary calculated successfully.' });
//     })
//     .catch(error => {
//       console.error(`Error calculating net salary for employee with empCode ${empCode}:`, error);
//       setMessage({ type: 'error', text: 'Error calculating net salary. Please try again.' });
//     });
//   };

//   const handleCalculateNetSalary = (salary) => {
//     calculateNetSalary(salary.employees.empCode, salary.earnings, salary.deductionsTotal, salary.taxes);
//   };

//   return (
//     <div>
//       <h3>All Salaries</h3>
//       {message && (
//         <div className={`alert ${message.type === 'success' ? 'alert-success' : 'alert-danger'}`} role="alert">
//           {message.text}
//         </div>
//       )}
//       <table className="table table-striped">
//         <thead className="thead-dark">
//           <tr>
//             <th>Employee Code</th>
//             <th>Paid Days</th>
//             <th>Monthly Salary</th>
//             <th>Taxes</th>
//             <th>Earnings</th>
//             <th>Deductions</th>
//             <th>Net Salary</th>
//             <th>Action</th>
//           </tr>
//         </thead>
//         <tbody>
//           {salaries.map(salary => (
//             <tr key={salary.id}>
//               <td>{salary.employees ? salary.employees.empCode : ''}</td>
//               <td>
//                 <input 
//                   type="number"
//                   value={salary.paidDays}
//                   onChange={e => handleInputChange(salary.id, 'paidDays', e.target.value)}
//                 />
//               </td>
//               <td>{salary.monthlySalary}</td>
//               <td>
//                 <input 
//                   type="number"
//                   value={salary.taxes}
//                   onChange={e => handleInputChange(salary.id, 'taxes', e.target.value)}
//                 />
//               </td>
//               <td>
//                 <input 
//                   type="number"
//                   value={salary.earnings}
//                   onChange={e => handleInputChange(salary.id, 'earnings', e.target.value)}
//                 />
//               </td>
//               <td>
//                 <input 
//                   type="number"
//                   value={salary.deductionsTotal}
//                   onChange={e => handleInputChange(salary.id, 'deductionsTotal', e.target.value)}
//                 />
//               </td>
//               <td>{salary.netSalary}</td>
//               <td>
//                 <button className="btn btn-primary" onClick={() => handleCalculateNetSalary(salary)}>Calculate</button>
//                 {/* <button className="btn btn-success" onClick={() => handleUpdateClick(salary.id)}>Update</button> */}
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// }

// export default SalaryList;
// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import './SalaryList.css'; // Import the CSS file for styling

// const SalaryList = () => {
//   const [salaries, setSalaries] = useState([]);
//   const [message, setMessage] = useState(null);

//   useEffect(() => {
//     fetchSalaries();
//   }, []);

//   const fetchSalaries = () => {
//     axios.get('http://localhost:8080/api/salary/get')
//       .then(response => {
//         setSalaries(response.data);
//       })
//       .catch(error => {
//         console.error('Error fetching salaries:', error);
//       });
//   };

//   const handleUpdate = (id, updatedFields) => {
//     axios.put(`http://localhost:8080/api/salary/${id}`, updatedFields)
//       .then(response => {
//         const updatedSalaries = salaries.map(salary => {
//           if (salary.id === id) {
//             return {
//               ...salary,
//               ...updatedFields
//             };
//           }
//           return salary;
//         });
//         setSalaries(updatedSalaries);
//         setMessage({ type: 'success', text: 'Salary updated successfully.' });
//       })
//       .catch(error => {
//         console.error(`Error updating salary with ID ${id}:`, error);
//         setMessage({ type: 'error', text: 'Error updating salary. Please try again.' });
//       });
//   };

//   const handleInputChange = (id, field, value) => {
//     setSalaries(salaries.map(salary => 
//       salary.id === id ? { ...salary, [field]: value } : salary
//     ));
//   };

//   const handleUpdateClick = (id) => {
//     const salary = salaries.find(salary => salary.id === id);
//     const updatedFields = {
//       paidDays: salary.paidDays,
//       taxes: salary.taxes,
//       earnings: salary.earnings,
//       deductionsTotal: salary.deductionsTotal,
//       netSalary: salary.netSalary
//     };

//     handleUpdate(id, updatedFields);
//   };

//   const calculateNetSalary = (empCode, earnings, deductions, taxes) => {
//     axios.put(`http://localhost:8080/api/salary/calculate/${empCode}`, {
//       earnings,
//       deductions,
//       taxes
//     })
//     .then(response => {
//       const updatedSalaries = salaries.map(salary => {
//         if (salary.employees.empCode === empCode) {
//           return {
//             ...salary,
//             netSalary: response.data.netSalary,
//             earnings: response.data.earnings,
//             deductionsTotal: response.data.deductionsTotal,
//             taxes: response.data.taxes
//           };
//         }
//         return salary;
//       });
//       setSalaries(updatedSalaries);
//       setMessage({ type: 'success', text: 'Net salary calculated successfully.' });
//     })
//     .catch(error => {
//       console.error(`Error calculating net salary for employee with empCode ${empCode}:`, error);
//       setMessage({ type: 'error', text: 'Error calculating net salary. Please try again.' });
//     });
//   };

//   const handleCalculateNetSalary = (salary) => {
//     calculateNetSalary(salary.employees.empCode, salary.earnings, salary.deductionsTotal, salary.taxes);
//   };

//   return (
//     <div>
//       {/* <h3>All Salaries</h3> */}
//       {message && (
//         <div className={`alert ${message.type === 'success' ? 'alert-success' : 'alert-danger'}`} role="alert">
//           {message.text}
//         </div>
//       )}
//       <div className="salary-table">
//         <div className="salary-row header">
//           <div className="salary-cell">Employee Code</div>
//           <div className="salary-cell">Paid Days</div>
//           <div className="salary-cell">Monthly Salary</div>
//           <div className="salary-cell">Taxes</div>
//           <div className="salary-cell">Earnings</div>
//           <div className="salary-cell">Deductions</div>
//           <div className="salary-cell">Net Salary</div>
//           <div className="salary-cell">Action</div>
//         </div>
//         {salaries.map(salary => (
//           <div className="salary-row" key={salary.id}>
//             <div className="salary-cell">{salary.employees ? salary.employees.empCode : ''}</div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.paidDays}
//                 onChange={e => handleInputChange(salary.id, 'paidDays', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">{salary.monthlySalary}</div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.taxes}
//                 onChange={e => handleInputChange(salary.id, 'taxes', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.earnings}
//                 onChange={e => handleInputChange(salary.id, 'earnings', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.deductionsTotal}
//                 onChange={e => handleInputChange(salary.id, 'deductionsTotal', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">{salary.netSalary}</div>
//             <div className="salary-cell">
//               <button className="btn btn-primary" onClick={() => handleCalculateNetSalary(salary)}>Calculate</button>
//               {/* <button className="btn btn-success" onClick={() => handleUpdateClick(salary.id)}>Update</button> */}
//             </div>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// }

// export default SalaryList;
// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import jsPDF from 'jspdf';
// import 'jspdf-autotable';
// import './SalaryList.css'; // Import the CSS file for styling

// const SalaryList = () => {
//   const [salaries, setSalaries] = useState([]);
//   const [message, setMessage] = useState(null);

//   useEffect(() => {
//     fetchSalaries();
//   }, []);

//   const fetchSalaries = () => {
//     axios.get('http://localhost:8080/api/salary/get')
//       .then(response => {
//         setSalaries(response.data);
//       })
//       .catch(error => {
//         console.error('Error fetching salaries:', error);
//       });
//   };

//   const handleUpdate = (id, updatedFields) => {
//     axios.put(`http://localhost:8080/api/salary/${id}`, updatedFields)
//       .then(response => {
//         const updatedSalaries = salaries.map(salary => {
//           if (salary.id === id) {
//             return {
//               ...salary,
//               ...updatedFields
//             };
//           }
//           return salary;
//         });
//         setSalaries(updatedSalaries);
//         setMessage({ type: 'success', text: 'Salary updated successfully.' });
//       })
//       .catch(error => {
//         console.error(`Error updating salary with ID ${id}:`, error);
//         setMessage({ type: 'error', text: 'Error updating salary. Please try again.' });
//       });
//   };

//   const handleInputChange = (id, field, value) => {
//     setSalaries(salaries.map(salary => 
//       salary.id === id ? { ...salary, [field]: value } : salary
//     ));
//   };

//   const handleUpdateClick = (id) => {
//     const salary = salaries.find(salary => salary.id === id);
//     const updatedFields = {
//       paidDays: salary.paidDays,
//       taxes: salary.taxes,
//       earnings: salary.earnings,
//       deductionsTotal: salary.deductionsTotal,
//       netSalary: salary.netSalary
//     };

//     handleUpdate(id, updatedFields);
//   };

//   const calculateNetSalary = (empCode, earnings, deductions, taxes) => {
//     axios.put(`http://localhost:8080/api/salary/calculate/${empCode}`, {
//       earnings,
//       deductions,
//       taxes
//     })
//     .then(response => {
//       const updatedSalaries = salaries.map(salary => {
//         if (salary.employees.empCode === empCode) {
//           return {
//             ...salary,
//             netSalary: response.data.netSalary,
//             earnings: response.data.earnings,
//             deductionsTotal: response.data.deductionsTotal,
//             taxes: response.data.taxes
//           };
//         }
//         return salary;
//       });
//       setSalaries(updatedSalaries);
//       setMessage({ type: 'success', text: 'Net salary calculated successfully.' });
//     })
//     .catch(error => {
//       console.error(`Error calculating net salary for employee with empCode ${empCode}:`, error);
//       setMessage({ type: 'error', text: 'Error calculating net salary. Please try again.' });
//     });
//   };

//   const handleCalculateNetSalary = (salary) => {
//     calculateNetSalary(salary.employees.empCode, salary.earnings, salary.deductionsTotal, salary.taxes);
//   };

//   const generatePDF = (salary) => {
//     const doc = new jsPDF();
//     doc.setFontSize(18);
//     doc.text('Salary Details', 14, 22);
//     doc.setFontSize(12);
//     doc.text(`Employee Code: ${salary.employees.empCode}`, 14, 30);
//     doc.text(`Paid Days: ${salary.paidDays}`, 14, 36);
//     doc.text(`Monthly Salary: ${salary.monthlySalary}`, 14, 42);
//     doc.text(`Taxes: ${salary.taxes}`, 14, 48);
//     doc.text(`Earnings: ${salary.earnings}`, 14, 54);
//     doc.text(`Deductions: ${salary.deductionsTotal}`, 14, 60);
//     doc.text(`Net Salary: ${salary.netSalary}`, 14, 66);
//     doc.save(`salary_details_${salary.employees.empCode}.pdf`);
//   };

//   return (
//     <div>
//       {/* <h3>All Salaries</h3> */}
//       {message && (
//         <div className={`alert ${message.type === 'success' ? 'alert-success' : 'alert-danger'}`} role="alert">
//           {message.text}
//         </div>
//       )}
//       <div className="salary-table">
//         <div className="salary-row header">
//           <div className="salary-cell">Employee Code</div>
//           <div className="salary-cell">Name</div>
//           <div className="salary-cell">Paid Days</div>
//           <div className="salary-cell">Monthly Salary</div>
//           <div className="salary-cell">Taxes</div>
//           <div className="salary-cell">Earnings</div>
//           <div className="salary-cell">Deductions</div>
//           <div className="salary-cell">Net Salary</div>
//           <div className="salary-cell">Actions</div>
//         </div>
//         {salaries.map(salary => (
//           <div className="salary-row" key={salary.id}>
//             <div className="salary-cell">{salary.employees ? salary.employees.empCode : ''}</div>
//             <div className="salary-cell">{salary.employees ? salary.employees.name : ''}</div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.paidDays}
//                 onChange={e => handleInputChange(salary.id, 'paidDays', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">{salary.monthlySalary}</div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.taxes}
//                 onChange={e => handleInputChange(salary.id, 'taxes', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.earnings}
//                 onChange={e => handleInputChange(salary.id, 'earnings', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.deductionsTotal}
//                 onChange={e => handleInputChange(salary.id, 'deductionsTotal', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">{salary.netSalary}</div>
//             <div className="salary-cell">
//               <button className="btn btn-primary" onClick={() => handleCalculateNetSalary(salary)}>Calculate</button>
//               <br></br>
//               {/* <button className="btn btn-success" onClick={() => handleUpdateClick(salary.id)}>Update</button> */}
//               <button className="btn btn-secondary" onClick={() => generatePDF(salary)}>Generate PDF</button>
//             </div>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// }

// export default SalaryList;
////////////////////////////////////////////////////////////////////////
// src/components/SalaryList.jsx

// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import jsPDF from 'jspdf';
// import 'jspdf-autotable';
// import './SalaryList.css'; // Import the CSS file for styling

// const SalaryList = () => {
//   const [salaries, setSalaries] = useState([]);
//   const [message, setMessage] = useState(null);

//   useEffect(() => {
//     fetchSalaries();
//   }, []);

//   const fetchSalaries = () => {
//     axios.get('http://localhost:8080/api/salary/get')
//       .then(response => {
//         setSalaries(response.data);
//       })
//       .catch(error => {
//         console.error('Error fetching salaries:', error);
//       });
//   };

//   const handleUpdate = (id, updatedFields) => {
//     axios.put(`http://localhost:8080/api/salary/${id}`, updatedFields)
//       .then(response => {
//         const updatedSalaries = salaries.map(salary => {
//           if (salary.id === id) {
//             return {
//               ...salary,
//               ...updatedFields
//             };
//           }
//           return salary;
//         });
//         setSalaries(updatedSalaries);
//         setMessage({ type: 'success', text: 'Salary updated successfully.' });
//       })
//       .catch(error => {
//         console.error(`Error updating salary with ID ${id}:`, error);
//         setMessage({ type: 'error', text: 'Error updating salary. Please try again.' });
//       });
//   };

//   const handleInputChange = (id, field, value) => {
//     setSalaries(salaries.map(salary => 
//       salary.id === id ? { ...salary, [field]: value } : salary
//     ));
//   };

//   const handleUpdateClick = (id) => {
//     const salary = salaries.find(salary => salary.id === id);
//     const updatedFields = {
//       paidDays: salary.paidDays,
//       taxes: salary.taxes,
//       earnings: salary.earnings,
//       deductionsTotal: salary.deductionsTotal,
//       netSalary: salary.netSalary
//     };

//     handleUpdate(id, updatedFields);
//   };

//   const calculateNetSalary = (empCode, earnings, deductions, taxes) => {
//     axios.put(`http://localhost:8080/api/salary/calculate/${empCode}`, {
//       earnings,
//       deductions,
//       taxes
//     })
//     .then(response => {
//       const updatedSalaries = salaries.map(salary => {
//         if (salary.employees && salary.employees.empCode === empCode) {
//           return {
//             ...salary,
//             netSalary: response.data.netSalary,
//             earnings: response.data.earnings,
//             deductionsTotal: response.data.deductionsTotal,
//             taxes: response.data.taxes
//           };
//         }
//         return salary;
//       });
//       setSalaries(updatedSalaries);
//       setMessage({ type: 'success', text: 'Net salary calculated successfully.' });
//     })
//     .catch(error => {
//       console.error(`Error calculating net salary for employee with empCode ${empCode}:`, error);
//       setMessage({ type: 'error', text: 'Error calculating net salary. Please try again.' });
//     });
//   };

//   const handleCalculateNetSalary = (salary) => {
//     if (salary.employees) {
//       calculateNetSalary(salary.employees.empCode, salary.earnings, salary.deductionsTotal, salary.taxes);
//     } else {
//       setMessage({ type: 'error', text: 'Employee data is missing. Cannot calculate net salary.' });
//     }
//   };

//   const generatePDF = (salary) => {
//     const doc = new jsPDF();
//     doc.setFontSize(18);
//     doc.text('Salary Details', 14, 22);
//     doc.setFontSize(12);
//     doc.text(`Employee Code: ${salary.employees ? salary.employees.empCode : 'N/A'}`, 14, 30);
//     doc.text(`Paid Days: ${salary.paidDays}`, 14, 36);
//     doc.text(`Monthly Salary: ${salary.monthlySalary}`, 14, 42);
//     doc.text(`Taxes: ${salary.taxes}`, 14, 48);
//     doc.text(`Earnings: ${salary.earnings}`, 14, 54);
//     doc.text(`Deductions: ${salary.deductionsTotal}`, 14, 60);
//     doc.text(`Net Salary: ${salary.netSalary}`, 14, 66);
//     doc.save(`salary_details_${salary.employees ? salary.employees.empCode : 'N/A'}.pdf`);
//   };

//   return (
//     <div>
//       {message && (
//         <div className={`alert ${message.type === 'success' ? 'alert-success' : 'alert-danger'}`} role="alert">
//           {message.text}
//         </div>
//       )}
//       <div className="salary-table">
//         <div className="salary-row header">
//           <div className="salary-cell">Employee Code</div>
//           <div className="salary-cell">Name</div>
//           <div className="salary-cell">Paid Days</div>
//           <div className="salary-cell">Monthly Salary</div>
//           <div className="salary-cell">Taxes</div>
//           <div className="salary-cell">Earnings</div>
//           <div className="salary-cell">Deductions</div>
//           <div className="salary-cell">Net Salary</div>
//           <div className="salary-cell">Actions</div>
//         </div>
//         {salaries.map(salary => (
//           <div className="salary-row" key={salary.id}>
//             <div className="salary-cell">{salary.employees ? salary.employees.empCode : ''}</div>
//             <div className="salary-cell">{salary.employees ? salary.employees.name : ''}</div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.paidDays}
//                 onChange={e => handleInputChange(salary.id, 'paidDays', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">{salary.monthlySalary}</div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.taxes}
//                 onChange={e => handleInputChange(salary.id, 'taxes', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.earnings}
//                 onChange={e => handleInputChange(salary.id, 'earnings', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.deductionsTotal}
//                 onChange={e => handleInputChange(salary.id, 'deductionsTotal', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">{salary.netSalary}</div>
//             <div className="salary-cell">
//               <button className="btn btn-primary" onClick={() => handleCalculateNetSalary(salary)}>Calculate</button>
//               <br></br>
//               <button className="btn btn-secondary" onClick={() => generatePDF(salary)}>Generate PDF</button>
//             </div>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// }

// export default SalaryList;
// src/components/SalaryList.jsx
/////////////////////////////////////////////////////////////////
// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import jsPDF from 'jspdf';
// import 'jspdf-autotable';
// import './SalaryList.css'; // Import the CSS file for styling
// import SalaryCalculator1 from './SalaryCalculator1'; // Import the new component

// const SalaryList = () => {
//   const [salaries, setSalaries] = useState([]);
//   const [message, setMessage] = useState(null);
//   const [showCalculator, setShowCalculator] = useState(false); // State to manage the sliding window

//   useEffect(() => {
//     fetchSalaries();
//   }, []);

//   const fetchSalaries = () => {
//     axios.get('http://localhost:8080/api/salary/get')
//       .then(response => {
//         setSalaries(response.data);
//       })
//       .catch(error => {
//         console.error('Error fetching salaries:', error);
//       });
//   };

//   const handleUpdate = (id, updatedFields) => {
//     axios.put(`http://localhost:8080/api/salary/${id}`, updatedFields)
//       .then(response => {
//         const updatedSalaries = salaries.map(salary => {
//           if (salary.id === id) {
//             return {
//               ...salary,
//               ...updatedFields
//             };
//           }
//           return salary;
//         });
//         setSalaries(updatedSalaries);
//         setMessage({ type: 'success', text: 'Salary updated successfully.' });
//       })
//       .catch(error => {
//         console.error(`Error updating salary with ID ${id}:`, error);
//         setMessage({ type: 'error', text: 'Error updating salary. Please try again.' });
//       });
//   };

//   const handleInputChange = (id, field, value) => {
//     setSalaries(salaries.map(salary => 
//       salary.id === id ? { ...salary, [field]: value } : salary
//     ));
//   };

//   const handleUpdateClick = (id) => {
//     const salary = salaries.find(salary => salary.id === id);
//     const updatedFields = {
//       paidDays: salary.paidDays,
//       taxes: salary.taxes,
//       earnings: salary.earnings,
//       deductionsTotal: salary.deductionsTotal,
//       netSalary: salary.netSalary
//     };

//     handleUpdate(id, updatedFields);
//   };

//   const calculateNetSalary = (empCode, earnings, deductions, taxes) => {
//     axios.put(`http://localhost:8080/api/salary/calculate/${empCode}`, {
//       earnings,
//       deductions,
//       taxes
//     })
//     .then(response => {
//       const updatedSalaries = salaries.map(salary => {
//         if (salary.employees && salary.employees.empCode === empCode) {
//           return {
//             ...salary,
//             netSalary: response.data.netSalary,
//             earnings: response.data.earnings,
//             deductionsTotal: response.data.deductionsTotal,
//             taxes: response.data.taxes
//           };
//         }
//         return salary;
//       });
//       setSalaries(updatedSalaries);
//       setMessage({ type: 'success', text: 'Net salary calculated successfully.' });
//     })
//     .catch(error => {
//       console.error(`Error calculating net salary for employee with empCode ${empCode}:`, error);
//       setMessage({ type: 'error', text: 'Error calculating net salary. Please try again.' });
//     });
//   };

//   const handleCalculateNetSalary = (salary) => {
//     if (salary.employees) {
//       calculateNetSalary(salary.employees.empCode, salary.earnings, salary.deductionsTotal, salary.taxes);
//     } else {
//       setMessage({ type: 'error', text: 'Employee data is missing. Cannot calculate net salary.' });
//     }
//   };

//   const generatePDF = (salary) => {
//     const doc = new jsPDF();
//     doc.setFontSize(18);
//     doc.text('Salary Details', 14, 22);
//     doc.setFontSize(12);
//     doc.text(`Employee Code: ${salary.employees ? salary.employees.empCode : 'N/A'}`, 14, 30);
//     doc.text(`Paid Days: ${salary.paidDays}`, 14, 36);
//     doc.text(`Monthly Salary: ${salary.monthlySalary}`, 14, 42);
//     doc.text(`Taxes: ${salary.taxes}`, 14, 48);
//     doc.text(`Earnings: ${salary.earnings}`, 14, 54);
//     doc.text(`Deductions: ${salary.deductionsTotal}`, 14, 60);
//     doc.text(`Net Salary: ${salary.netSalary}`, 14, 66);
//     doc.save(`salary_details_${salary.employees ? salary.employees.empCode : 'N/A'}.pdf`);
//   };

//   const toggleCalculator = () => {
//     setShowCalculator(!showCalculator);
//   };

//   return (
//     <div>
//       {message && (
//         <div className={`alert ${message.type === 'success' ? 'alert-success' : 'alert-danger'}`} role="alert">
//           {message.text}
//         </div>
//       )}
//       <button className="btn btn-primary" onClick={toggleCalculator}>
//         {showCalculator ? 'Close Salary Calculator' : 'Open Salary Calculator'}
//       </button>
//       {showCalculator && <SalaryCalculator1 onClose={toggleCalculator} />}
//       <div className="salary-table">
//         <div className="salary-row header">
//           <div className="salary-cell">Employee Code</div>
//           <div className="salary-cell">Name</div>
//           <div className="salary-cell">Paid Days</div>
//           <div className="salary-cell">Monthly Salary</div>
//           <div className="salary-cell">Taxes</div>
//           <div className="salary-cell">Earnings</div>
//           <div className="salary-cell">Deductions</div>
//           <div className="salary-cell">Net Salary</div>
//           <div className="salary-cell">Actions</div>
//         </div>
//         {salaries.map(salary => (
//           <div className="salary-row" key={salary.id}>
//             <div className="salary-cell">{salary.employees ? salary.employees.empCode : ''}</div>
//             <div className="salary-cell">{salary.employees ? salary.employees.name : ''}</div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.paidDays}
//                 onChange={e => handleInputChange(salary.id, 'paidDays', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">{salary.monthlySalary}</div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.taxes}
//                 onChange={e => handleInputChange(salary.id, 'taxes', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.earnings}
//                 onChange={e => handleInputChange(salary.id, 'earnings', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.deductionsTotal}
//                 onChange={e => handleInputChange(salary.id, 'deductionsTotal', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">{salary.netSalary}</div>
//             <div className="salary-cell">
//               <button className="btn btn-primary" onClick={() => handleCalculateNetSalary(salary)}>Calculate</button>
//               <br></br>
//               <button className="btn btn-secondary" onClick={() => generatePDF(salary)}>Generate PDF</button>
//             </div>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// }

// export default SalaryList;
////////////////////////////////////////////////////
// src/components/SalaryList.jsx

// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import jsPDF from 'jspdf';
// import 'jspdf-autotable';
// import './SalaryList.css'; // Import the CSS file for styling
// import SalaryCalculator1 from './SalaryCalculator1'; // Import the new component

// const SalaryList = () => {
//   const [salaries, setSalaries] = useState([]);
//   const [message, setMessage] = useState(null);
//   const [showCalculator, setShowCalculator] = useState(false); // State to manage the sliding window

//   useEffect(() => {
//     fetchSalaries();
//   }, []);

//   const fetchSalaries = () => {
//     axios.get('http://localhost:8080/api/salary/get')
//       .then(response => {
//         setSalaries(response.data);
//       })
//       .catch(error => {
//         console.error('Error fetching salaries:', error);
//       });
//   };

//   const handleUpdate = (id, updatedFields) => {
//     axios.put(`http://localhost:8080/api/salary/${id}`, updatedFields)
//       .then(response => {
//         const updatedSalaries = salaries.map(salary => {
//           if (salary.id === id) {
//             return {
//               ...salary,
//               ...updatedFields
//             };
//           }
//           return salary;
//         });
//         setSalaries(updatedSalaries);
//         setMessage({ type: 'success', text: 'Salary updated successfully.' });
//       })
//       .catch(error => {
//         console.error(`Error updating salary with ID ${id}:`, error);
//         setMessage({ type: 'error', text: 'Error updating salary. Please try again.' });
//       });
//   };

//   const handleInputChange = (id, field, value) => {
//     setSalaries(salaries.map(salary => 
//       salary.id === id ? { ...salary, [field]: value } : salary
//     ));
//   };

//   const handleUpdateClick = (id) => {
//     const salary = salaries.find(salary => salary.id === id);
//     const updatedFields = {
//       paidDays: salary.paidDays,
//       taxes: salary.taxes,
//       earnings: salary.earnings,
//       deductionsTotal: salary.deductionsTotal,
//       netSalary: salary.netSalary
//     };

//     handleUpdate(id, updatedFields);
//   };

//   const calculateNetSalary = (empCode, earnings, deductions, taxes) => {
//     axios.put(`http://localhost:8080/api/salary/calculate/${empCode}`, {
//       earnings,
//       deductions,
//       taxes
//     })
//     .then(response => {
//       const updatedSalaries = salaries.map(salary => {
//         if (salary.employees && salary.employees.empCode === empCode) {
//           return {
//             ...salary,
//             netSalary: response.data.netSalary,
//             earnings: response.data.earnings,
//             deductionsTotal: response.data.deductionsTotal,
//             taxes: response.data.taxes
//           };
//         }
//         return salary;
//       });
//       setSalaries(updatedSalaries);
//       setMessage({ type: 'success', text: 'Net salary calculated successfully.' });
//     })
//     .catch(error => {
//       console.error(`Error calculating net salary for employee with empCode ${empCode}:`, error);
//       setMessage({ type: 'error', text: 'Error calculating net salary. Please try again.' });
//     });
//   };

//   const handleCalculateNetSalary = (salary) => {
//     if (salary.employees) {
//       calculateNetSalary(salary.employees.empCode, salary.earnings, salary.deductionsTotal, salary.taxes);
//     } else {
//       setMessage({ type: 'error', text: 'Employee data is missing. Cannot calculate net salary.' });
//     }
//   };

//   const generatePDF = (salary) => {
//     const doc = new jsPDF();
//     doc.setFontSize(18);
//     doc.text('Salary Details', 14, 22);
//     doc.setFontSize(12);
//     doc.text(`Employee Code: ${salary.employees ? salary.employees.empCode : 'N/A'}`, 14, 30);
//     doc.text(`Paid Days: ${salary.paidDays}`, 14, 36);
//     doc.text(`Monthly Salary: ${salary.monthlySalary}`, 14, 42);
//     doc.text(`Taxes: ${salary.taxes}`, 14, 48);
//     doc.text(`Earnings: ${salary.earnings}`, 14, 54);
//     doc.text(`Deductions: ${salary.deductionsTotal}`, 14, 60);
//     doc.text(`Net Salary: ${salary.netSalary}`, 14, 66);
//     doc.save(`salary_details_${salary.employees ? salary.employees.empCode : 'N/A'}.pdf`);
//   };

//   const toggleCalculator = () => {
//     setShowCalculator(!showCalculator);
//   };

//   return (
//     <div>
//       {message && (
//         <div className={`alert ${message.type === 'success' ? 'alert-success' : 'alert-danger'}`} role="alert">
//           {message.text}
//         </div>
//       )}
//       <button className="btn btn-primary" onClick={toggleCalculator}>
//         {showCalculator ? 'Close Salary Calculator' : 'Open Salary Calculator'}
//       </button>
//       <SalaryCalculator1 onClose={toggleCalculator} isOpen={showCalculator} />
//       <div className="salary-table">
//         <div className="salary-row header">
//           <div className="salary-cell">Employee Code</div>
//           <div className="salary-cell">Name</div>
//           <div className="salary-cell">Paid Days</div>
//           <div className="salary-cell">Monthly Salary</div>
//           <div className="salary-cell">Taxes</div>
//           <div className="salary-cell">Earnings</div>
//           <div className="salary-cell">Deductions</div>
//           <div className="salary-cell">Net Salary</div>
//           <div className="salary-cell">Actions</div>
//         </div>
//         {salaries.map(salary => (
//           <div className="salary-row" key={salary.id}>
//             <div className="salary-cell">{salary.employees ? salary.employees.empCode : ''}</div>
//             <div className="salary-cell">{salary.employees ? salary.employees.name : ''}</div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.paidDays}
//                 onChange={e => handleInputChange(salary.id, 'paidDays', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">{salary.monthlySalary}</div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.taxes}
//                 onChange={e => handleInputChange(salary.id, 'taxes', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.earnings}
//                 onChange={e => handleInputChange(salary.id, 'earnings', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.deductionsTotal}
//                 onChange={e => handleInputChange(salary.id, 'deductionsTotal', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">{salary.netSalary}</div>
//             <div className="salary-cell">
//               <button className="btn btn-primary" onClick={() => handleCalculateNetSalary(salary)}>Calculate</button>
//               <br></br>
//               <button className="btn btn-secondary" onClick={() => generatePDF(salary)}>Generate PDF</button>
//             </div>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// }

// export default SalaryList;
// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import jsPDF from 'jspdf';
// import 'jspdf-autotable';
// import './SalaryList.css'; // Import the CSS file for styling
// import SalaryCalculator1 from './SalaryCalculator1'; // Import the new component

// const SalaryList = () => {
//   const [salaries, setSalaries] = useState([]);
//   const [message, setMessage] = useState(null);
//   const [showCalculator, setShowCalculator] = useState(false); // State to manage the sliding window

//   useEffect(() => {
//     fetchSalaries();
//   }, []);

//   const fetchSalaries = () => {
//     axios.get('http://localhost:8080/api/salary/get')
//       .then(response => {
//         setSalaries(response.data);
//       })
//       .catch(error => {
//         console.error('Error fetching salaries:', error);
//       });
//   };

//   const handleUpdate = (id, updatedFields) => {
//     axios.put(`http://localhost:8080/api/salary/${id}`, updatedFields)
//       .then(response => {
//         const updatedSalaries = salaries.map(salary => {
//           if (salary.id === id) {
//             return {
//               ...salary,
//               ...updatedFields
//             };
//           }
//           return salary;
//         });
//         setSalaries(updatedSalaries);
//         setMessage({ type: 'success', text: 'Salary updated successfully.' });
//       })
//       .catch(error => {
//         console.error(`Error updating salary with ID ${id}:`, error);
//         setMessage({ type: 'error', text: 'Error updating salary. Please try again.' });
//       });
//   };

//   const handleInputChange = (id, field, value) => {
//     setSalaries(salaries.map(salary => 
//       salary.id === id ? { ...salary, [field]: value } : salary
//     ));
//   };

//   const handleUpdateClick = (id) => {
//     const salary = salaries.find(salary => salary.id === id);
//     const updatedFields = {
//       paidDays: salary.paidDays,
//       taxes: salary.taxes,
//       earnings: salary.earnings,
//       deductionsTotal: salary.deductionsTotal,
//       netSalary: salary.netSalary
//     };

//     handleUpdate(id, updatedFields);
//   };

//   const calculateNetSalary = (empCode, earnings, deductions, taxes) => {
//     axios.put(`http://localhost:8080/api/salary/calculate/${empCode}`, {
//       earnings,
//       deductions,
//       taxes
//     })
//     .then(response => {
//       const updatedSalaries = salaries.map(salary => {
//         if (salary.employees && salary.employees.empCode === empCode) {
//           return {
//             ...salary,
//             netSalary: response.data.netSalary,
//             earnings: response.data.earnings,
//             deductionsTotal: response.data.deductionsTotal,
//             taxes: response.data.taxes
//           };
//         }
//         return salary;
//       });
//       setSalaries(updatedSalaries);
//       setMessage({ type: 'success', text: 'Net salary calculated successfully.' });
//     })
//     .catch(error => {
//       console.error(`Error calculating net salary for employee with empCode ${empCode}:`, error);
//       setMessage({ type: 'error', text: 'Error calculating net salary. Please try again.' });
//     });
//   };

//   const handleCalculateNetSalary = (salary) => {
//     if (salary.employees) {
//       const confirmed = window.confirm(`Are you sure you want to calculate the net salary for employee ${salary.employees.empCode}?`);
//       if (confirmed) {
//         calculateNetSalary(salary.employees.empCode, salary.earnings, salary.deductionsTotal, salary.taxes);
//       }
//     } else {
//       setMessage({ type: 'error', text: 'Employee data is missing. Cannot calculate net salary.' });
//     }
//   };

//   const generatePDF = (salary) => {
//     const doc = new jsPDF();
//     doc.setFontSize(18);
//     doc.text('Salary Details', 14, 22);
//     doc.setFontSize(12);
//     doc.text(`Employee Code: ${salary.employees ? salary.employees.empCode : 'N/A'}`, 14, 30);
//     doc.text(`Paid Days: ${salary.paidDays}`, 14, 36);
//     doc.text(`Monthly Salary: ${salary.monthlySalary}`, 14, 42);
//     doc.text(`Taxes: ${salary.taxes}`, 14, 48);
//     doc.text(`Earnings: ${salary.earnings}`, 14, 54);
//     doc.text(`Deductions: ${salary.deductionsTotal}`, 14, 60);
//     doc.text(`Net Salary: ${salary.netSalary}`, 14, 66);
//     doc.save(`salary_details_${salary.employees ? salary.employees.empCode : 'N/A'}.pdf`);
//   };

//   const toggleCalculator = () => {
//     setShowCalculator(!showCalculator);
//   };

//   return (
//     <div>
//       {message && (
//         <div className={`alert ${message.type === 'success' ? 'alert-success' : 'alert-danger'}`} role="alert">
//           {message.text}
//         </div>
//       )}
//       <button className="btn btn-primary" onClick={toggleCalculator}>
//         {showCalculator ? 'Close Salary Calculator' : 'Open Salary Calculator'}
//       </button>
//       <SalaryCalculator1 onClose={toggleCalculator} isOpen={showCalculator} />
//       <div className="salary-table">
//         <div className="salary-row header">
//           <div className="salary-cell">Employee Code</div>
//           <div className="salary-cell">Name</div>
//           <div className="salary-cell">Paid Days</div>
//           <div className="salary-cell">Monthly Salary</div>
//           <div className="salary-cell">Taxes</div>
//           <div className="salary-cell">Earnings</div>
//           <div className="salary-cell">Deductions</div>
//           <div className="salary-cell">Net Salary</div>
//           <div className="salary-cell">Actions</div>
//         </div>
//         {salaries.map(salary => (
//           <div className="salary-row" key={salary.id}>
//             <div className="salary-cell">{salary.employees ? salary.employees.empCode : ''}</div>
//             <div className="salary-cell">{salary.employees ? salary.employees.name : ''}</div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.paidDays}
//                 onChange={e => handleInputChange(salary.id, 'paidDays', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">{salary.monthlySalary}</div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.taxes}
//                 onChange={e => handleInputChange(salary.id, 'taxes', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.earnings}
//                 onChange={e => handleInputChange(salary.id, 'earnings', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.deductionsTotal}
//                 onChange={e => handleInputChange(salary.id, 'deductionsTotal', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">{salary.netSalary}</div>
//             <div className="salary-cell">
//               <button className="btn btn-primary" onClick={() => handleCalculateNetSalary(salary)}>Calculate</button>
//               <br></br>
//               <button className="btn btn-secondary" onClick={() => generatePDF(salary)}>Generate PDF</button>
//             </div>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// }

// export default SalaryList;
///////////////////////////////////////////////////////////////
// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import jsPDF from 'jspdf';
// import 'jspdf-autotable';
// import './SalaryList.css'; // Import the CSS file for styling
// import SalaryCalculator1 from './SalaryCalculator1'; // Import the new component

// const SalaryList = () => {
//   const [salaries, setSalaries] = useState([]);
//   const [message, setMessage] = useState(null);
//   const [showCalculator, setShowCalculator] = useState(false); // State to manage the sliding window

//   useEffect(() => {
//     fetchSalaries();
//   }, []);

//   const fetchSalaries = () => {
//     axios.get('http://localhost:8080/api/salary/get')
//       .then(response => {
//         setSalaries(response.data);
//       })
//       .catch(error => {
//         console.error('Error fetching salaries:', error);
//       });
//   };

//   const handleUpdate = (id, updatedFields) => {
//     axios.put(`http://localhost:8080/api/salary/${id}`, updatedFields)
//       .then(response => {
//         const updatedSalaries = salaries.map(salary => {
//           if (salary.id === id) {
//             return {
//               ...salary,
//               ...updatedFields
//             };
//           }
//           return salary;
//         });
//         setSalaries(updatedSalaries);
//         setMessage({ type: 'success', text: 'Salary updated successfully.' });
//       })
//       .catch(error => {
//         console.error(`Error updating salary with ID ${id}:`, error);
//         setMessage({ type: 'error', text: 'Error updating salary. Please try again.' });
//       });
//   };

//   const handleInputChange = (id, field, value) => {
//     setSalaries(salaries.map(salary => 
//       salary.id === id ? { ...salary, [field]: value } : salary
//     ));
//   };

//   const handleUpdateClick = (id) => {
//     const salary = salaries.find(salary => salary.id === id);
//     const updatedFields = {
//       paidDays: salary.paidDays,
//       taxes: salary.taxes,
//       earnings: salary.earnings,
//       deductionsTotal: salary.deductionsTotal,
//       netSalary: salary.netSalary
//     };

//     handleUpdate(id, updatedFields);
//   };

//   const calculateNetSalary = (empCode, earnings, deductions, taxes) => {
//     axios.put(`http://localhost:8080/api/salary/calculate/${empCode}`, {
//       earnings,
//       deductions,
//       taxes
//     })
//     .then(response => {
//       const updatedSalaries = salaries.map(salary => {
//         if (salary.employees && salary.employees.empCode === empCode) {
//           return {
//             ...salary,
//             netSalary: response.data.netSalary,
//             earnings: response.data.earnings,
//             deductionsTotal: response.data.deductionsTotal,
//             taxes: response.data.taxes
//           };
//         }
//         return salary;
//       });
//       setSalaries(updatedSalaries);
//       setMessage({ type: 'success', text: 'Net salary calculated successfully.' });
//     })
//     .catch(error => {
//       console.error(`Error calculating net salary for employee with empCode ${empCode}:`, error);
//       setMessage({ type: 'error', text: 'Error calculating net salary. Please try again.' });
//     });
//   };

//   const handleCalculateNetSalary = (salary) => {
//     if (salary.employees) {
//       const confirmed = window.confirm(`Are you sure you want to calculate the net salary for employee ${salary.employees.empCode}?`);
//       if (confirmed) {
//         calculateNetSalary(salary.employees.empCode, salary.earnings, salary.deductionsTotal, salary.taxes);
//       }
//     } else {
//       setMessage({ type: 'error', text: 'Employee data is missing. Cannot calculate net salary.' });
//     }
//   };

//   const generatePDF = (salary) => {
//     const doc = new jsPDF();
//     doc.setFontSize(18);
//     doc.text('Salary Details', 14, 22);
//     doc.setFontSize(12);
//     doc.text(`Employee Code: ${salary.employees ? salary.employees.empCode : 'N/A'}`, 14, 30);
//     doc.text(`Paid Days: ${salary.paidDays}`, 14, 36);
//     doc.text(`Monthly Salary: ${salary.monthlySalary}`, 14, 42);
//     doc.text(`Taxes: ${salary.taxes}`, 14, 48);
//     doc.text(`Earnings: ${salary.earnings}`, 14, 54);
//     doc.text(`Deductions: ${salary.deductionsTotal}`, 14, 60);
//     doc.text(`Net Salary: ${salary.netSalary}`, 14, 66);
//     doc.save(`salary_details_${salary.employees ? salary.employees.empCode : 'N/A'}.pdf`);
//   };

//   const toggleCalculator = () => {
//     setShowCalculator(!showCalculator);
//   };

//   const handleSalaryUpdate = () => {
//     fetchSalaries();
//   };

//   return (
//     <div>
//       {message && (
//         <div className={`alert ${message.type === 'success' ? 'alert-success' : 'alert-danger'}`} role="alert">
//           {message.text}
//         </div>
//       )}
//       <button className="btn btn-primary" onClick={toggleCalculator}>
//         {showCalculator ? 'Close Salary Calculator' : 'Open Salary Calculator'}
//       </button>
//       <SalaryCalculator1 onClose={toggleCalculator} isOpen={showCalculator} onUpdate={handleSalaryUpdate} />
//       <div className="salary-table">
//         <div className="salary-row header">
//           <div className="salary-cell">Employee Code</div>
//           <div className="salary-cell">Name</div>
//           <div className="salary-cell">Paid Days</div>
//           <div className="salary-cell">Monthly Salary</div>
//           <div className="salary-cell">Taxes</div>
//           <div className="salary-cell">Earnings</div>
//           <div className="salary-cell">Deductions</div>
//           <div className="salary-cell">Net Salary</div>
//           <div className="salary-cell">Actions</div>
//         </div>
//         {salaries.map(salary => (
//           <div className="salary-row" key={salary.id}>
//             <div className="salary-cell">{salary.employees ? salary.employees.empCode : ''}</div>
//             <div className="salary-cell">{salary.employees ? salary.employees.name : ''}</div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.paidDays}
//                 onChange={e => handleInputChange(salary.id, 'paidDays', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">{salary.monthlySalary}</div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.taxes}
//                 onChange={e => handleInputChange(salary.id, 'taxes', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.earnings}
//                 onChange={e => handleInputChange(salary.id, 'earnings', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.deductionsTotal}
//                 onChange={e => handleInputChange(salary.id, 'deductionsTotal', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">{salary.netSalary}</div>
//             <div className="salary-cell">
//               <button className="btn btn-primary" onClick={() => handleCalculateNetSalary(salary)}>Calculate</button>
//               <br></br>
//               <button className="btn btn-secondary" onClick={() => generatePDF(salary)}>Generate PDF</button>
//             </div>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// }

// export default SalaryList;
//////////////////////////////////////////////////////
// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import jsPDF from 'jspdf';
// import 'jspdf-autotable';
// import './SalaryList.css'; // Import the CSS file for styling
// import SalaryCalculator1 from './SalaryCalculator1'; // Import the new component

// const SalaryList = () => {
//   const [salaries, setSalaries] = useState([]);
//   const [message, setMessage] = useState(null);
//   const [showCalculator, setShowCalculator] = useState(false); // State to manage the sliding window
//   const [currentEmployee, setCurrentEmployee] = useState(null); // State to manage the current employee for calculator

//   useEffect(() => {
//     fetchSalaries();
//   }, []);

//   const fetchSalaries = () => {
//     axios.get('http://localhost:8080/api/salary/get')
//       .then(response => {
//         setSalaries(response.data);
//       })
//       .catch(error => {
//         console.error('Error fetching salaries:', error);
//       });
//   };

//   const handleUpdate = (id, updatedFields) => {
//     axios.put(`http://localhost:8080/api/salary/${id}`, updatedFields)
//       .then(response => {
//         const updatedSalaries = salaries.map(salary => {
//           if (salary.id === id) {
//             return {
//               ...salary,
//               ...updatedFields
//             };
//           }
//           return salary;
//         });
//         setSalaries(updatedSalaries);
//         setMessage({ type: 'success', text: 'Salary updated successfully.' });
//       })
//       .catch(error => {
//         console.error(`Error updating salary with ID ${id}:`, error);
//         setMessage({ type: 'error', text: 'Error updating salary. Please try again.' });
//       });
//   };

//   const handleInputChange = (id, field, value) => {
//     setSalaries(salaries.map(salary => 
//       salary.id === id ? { ...salary, [field]: value } : salary
//     ));
//   };

//   const handleUpdateClick = (id) => {
//     const salary = salaries.find(salary => salary.id === id);
//     const updatedFields = {
//       paidDays: salary.paidDays,
//       taxes: salary.taxes,
//       earnings: salary.earnings,
//       deductionsTotal: salary.deductionsTotal,
//       netSalary: salary.netSalary
//     };

//     handleUpdate(id, updatedFields);
//   };

//   const calculateNetSalary = (empCode, earnings, deductions, taxes) => {
//     axios.put(`http://localhost:8080/api/salary/calculate/${empCode}`, {
//       earnings,
//       deductions,
//       taxes
//     })
//     .then(response => {
//       const updatedSalaries = salaries.map(salary => {
//         if (salary.employees && salary.employees.empCode === empCode) {
//           return {
//             ...salary,
//             netSalary: response.data.netSalary,
//             earnings: response.data.earnings,
//             deductionsTotal: response.data.deductionsTotal,
//             taxes: response.data.taxes
//           };
//         }
//         return salary;
//       });
//       setSalaries(updatedSalaries);
//       setMessage({ type: 'success', text: 'Net salary calculated successfully.' });
//     })
//     .catch(error => {
//       console.error(`Error calculating net salary for employee with empCode ${empCode}:`, error);
//       setMessage({ type: 'error', text: 'Error calculating net salary. Please try again.' });
//     });
//   };

//   const handleCalculateNetSalary = (salary) => {
//     if (salary.employees) {
//       const confirmed = window.confirm(`Are you sure you want to calculate the net salary for employee ${salary.employees.empCode}?`);
//       if (confirmed) {
//         calculateNetSalary(salary.employees.empCode, salary.earnings, salary.deductionsTotal, salary.taxes);
//       }
//     } else {
//       setMessage({ type: 'error', text: 'Employee data is missing. Cannot calculate net salary.' });
//     }
//   };

//   const generatePDF = (salary) => {
//     const doc = new jsPDF();
//     doc.setFontSize(18);
//     doc.text('Salary Details', 14, 22);
//     doc.setFontSize(12);
//     doc.text(`Employee Code: ${salary.employees ? salary.employees.empCode : 'N/A'}`, 14, 30);
//     doc.text(`Paid Days: ${salary.paidDays}`, 14, 36);
//     doc.text(`Monthly Salary: ${salary.monthlySalary}`, 14, 42);
//     doc.text(`Taxes: ${salary.taxes}`, 14, 48);
//     doc.text(`Earnings: ${salary.earnings}`, 14, 54);
//     doc.text(`Deductions: ${salary.deductionsTotal}`, 14, 60);
//     doc.text(`Net Salary: ${salary.netSalary}`, 14, 66);
//     doc.save(`salary_details_${salary.employees ? salary.employees.empCode : 'N/A'}.pdf`);
//   };

//   const openCalculator = (employee) => {
//     setCurrentEmployee(employee);
//     setShowCalculator(true);
//   };

//   const closeCalculator = () => {
//     setCurrentEmployee(null);
//     setShowCalculator(false);
//   };

//   const handleSalaryUpdate = () => {
//     fetchSalaries();
//   };

//   return (
//     <div>
//       {message && (
//         <div className={`alert ${message.type === 'success' ? 'alert-success' : 'alert-danger'}`} role="alert">
//           {message.text}
//         </div>
//       )}
//       <div className="salary-table">
//         <div className="salary-row header">
//           <div className="salary-cell">Employee Code</div>
//           <div className="salary-cell">Name</div>
//           <div className="salary-cell">Paid Days</div>
//           <div className="salary-cell">Monthly Salary</div>
//           <div className="salary-cell">Taxes</div>
//           <div className="salary-cell">Earnings</div>
//           <div className="salary-cell">Deductions</div>
//           <div className="salary-cell">Net Salary</div>
//           <div className="salary-cell">Actions</div>
//         </div>
//         {salaries.map(salary => (
//           <div className="salary-row" key={salary.id}>
//             <div className="salary-cell">{salary.employees ? salary.employees.empCode : ''}</div>
//             <div className="salary-cell">{salary.employees ? salary.employees.name : ''}</div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.paidDays}
//                 onChange={e => handleInputChange(salary.id, 'paidDays', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">{salary.monthlySalary}</div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.taxes}
//                 onChange={e => handleInputChange(salary.id, 'taxes', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.earnings}
//                 onChange={e => handleInputChange(salary.id, 'earnings', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.deductionsTotal}
//                 onChange={e => handleInputChange(salary.id, 'deductionsTotal', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">{salary.netSalary}</div>
//             <div className="salary-cell">
//               <button className="btn btn-primary" onClick={() => handleCalculateNetSalary(salary)}>Calculate</button>
//               <br></br>
//               <button className="btn btn-secondary" onClick={() => generatePDF(salary)}>Generate PDF</button>
//               <br></br>
//               <button className="btn btn-info" onClick={() => openCalculator(salary.employees)}>Edit</button>
//             </div>
//           </div>
//         ))}
//       </div>
//       {showCalculator && (
//         <SalaryCalculator1
//           onClose={closeCalculator}
//           isOpen={showCalculator}
//           onUpdate={handleSalaryUpdate}
//           employee={currentEmployee}
//         />
//       )}
//     </div>
//   );
// }

// export default SalaryList;
/////////////////////////////////
// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import jsPDF from 'jspdf';
// import 'jspdf-autotable';
// import './SalaryList.css'; // Import the CSS file for styling
// import SalaryCalculator1 from './SalaryCalculator1'; // Import the new component

// const SalaryList = () => {
//   const [salaries, setSalaries] = useState([]);
//   const [message, setMessage] = useState(null);
//   const [showCalculator, setShowCalculator] = useState(false); // State to manage the sliding window
//   const [currentEmployee, setCurrentEmployee] = useState(null); // State to manage the current employee for calculator

//   useEffect(() => {
//     fetchSalaries();
//   }, []);

//   useEffect(() => {
//     if (message) {
//       const timer = setTimeout(() => {
//         setMessage(null);
//       }, 3000); // Adjust the time (in milliseconds) to your preference

//       return () => clearTimeout(timer);
//     }
//   }, [message]);

//   const fetchSalaries = () => {
//     axios.get('http://localhost:8080/api/salary/get')
//       .then(response => {
//         setSalaries(response.data);
//       })
//       .catch(error => {
//         console.error('Error fetching salaries:', error);
//       });
//   };

//   const handleUpdate = (id, updatedFields) => {
//     axios.put(`http://localhost:8080/api/salary/${id}`, updatedFields)
//       .then(response => {
//         const updatedSalaries = salaries.map(salary => {
//           if (salary.id === id) {
//             return {
//               ...salary,
//               ...updatedFields
//             };
//           }
//           return salary;
//         });
//         setSalaries(updatedSalaries);
//         setMessage({ type: 'success', text: 'Salary updated successfully.' });
//       })
//       .catch(error => {
//         console.error(`Error updating salary with ID ${id}:`, error);
//         setMessage({ type: 'error', text: 'Error updating salary. Please try again.' });
//       });
//   };

//   const handleInputChange = (id, field, value) => {
//     setSalaries(salaries.map(salary => 
//       salary.id === id ? { ...salary, [field]: value } : salary
//     ));
//   };

//   const handleUpdateClick = (id) => {
//     const salary = salaries.find(salary => salary.id === id);
//     const updatedFields = {
//       paidDays: salary.paidDays,
//       taxes: salary.taxes,
//       earnings: salary.earnings,
//       deductionsTotal: salary.deductionsTotal,
//       netSalary: salary.netSalary
//     };

//     handleUpdate(id, updatedFields);
//   };

//   const calculateNetSalary = (empCode, earnings, deductions, taxes) => {
//     axios.put(`http://localhost:8080/api/salary/calculate/${empCode}`, {
//       earnings,
//       deductions,
//       taxes
//     })
//     .then(response => {
//       const updatedSalaries = salaries.map(salary => {
//         if (salary.employees && salary.employees.empCode === empCode) {
//           return {
//             ...salary,
//             netSalary: response.data.netSalary,
//             earnings: response.data.earnings,
//             deductionsTotal: response.data.deductionsTotal,
//             taxes: response.data.taxes
//           };
//         }
//         return salary;
//       });
//       setSalaries(updatedSalaries);
//       setMessage({ type: 'success', text: `Net salary calculated successfully for employee with id  ${empCode}.` });
//     })
//     .catch(error => {
//       console.error(`Error calculating net salary for employee with empCode ${empCode}:`, error);
//       setMessage({ type: 'error', text: 'Error calculating net salary. Please try again.' });
//     });
//   };

//   const handleCalculateNetSalary = (salary) => {
//     if (salary.employees) {
//       const confirmed = window.confirm(`Are you sure you want to calculate the net salary for employee ${salary.employees.empCode}?`);
//       if (confirmed) {
//         calculateNetSalary(salary.employees.empCode, salary.earnings, salary.deductionsTotal, salary.taxes);
//       }
//     } else {
//       setMessage({ type: 'error', text: 'Employee data is missing. Cannot calculate net salary.' });
//     }
//   };

//   const generatePDF = (salary) => {
//     const doc = new jsPDF();
//     doc.setFontSize(18);
//     doc.text('Salary Details', 14, 22);
//     doc.setFontSize(12);
//     doc.text(`Employee Code: ${salary.employees ? salary.employees.empCode : 'N/A'}`, 14, 30);
//     doc.text(`Paid Days: ${salary.paidDays}`, 14, 36);
//     doc.text(`Monthly Salary: ${salary.monthlySalary}`, 14, 42);
//     doc.text(`Taxes: ${salary.taxes}`, 14, 48);
//     doc.text(`Earnings: ${salary.earnings}`, 14, 54);
//     doc.text(`Deductions: ${salary.deductionsTotal}`, 14, 60);
//     doc.text(`Net Salary: ${salary.netSalary}`, 14, 66);
//     doc.save(`salary_details_${salary.employees ? salary.employees.empCode : 'N/A'}.pdf`);
//   };

//   const openCalculator = (employee) => {
//     setCurrentEmployee(employee);
//     setShowCalculator(true);
//   };

//   const closeCalculator = () => {
//     setCurrentEmployee(null);
//     setShowCalculator(false);
//   };

//   const handleSalaryUpdate = () => {
//     fetchSalaries();
//   };

//   return (
//     <div>
//       {message && (
//         <div className={`alert ${message.type === 'success' ? 'alert-success' : 'alert-danger'}`} role="alert">
//           {message.text}
//         </div>
//       )}
//       <div className="salary-table">
//         <div className="salary-row header">
//           <div className="salary-cell">Employee Code</div>
//           <div className="salary-cell">Name</div>
//           <div className="salary-cell">Paid Days</div>
//           <div className="salary-cell">Monthly Salary</div>
//           <div className="salary-cell">Taxes</div>
//           <div className="salary-cell">Earnings</div>
//           <div className="salary-cell">Deductions</div>
//           <div className="salary-cell">Net Salary</div>
//           <div className="salary-cell">Actions</div>
//         </div>
//         {salaries.map(salary => (
//           <div className="salary-row" key={salary.id}>
//             <div className="salary-cell">{salary.employees ? salary.employees.empCode : ''}</div>
//             <div className="salary-cell">{salary.employees ? salary.employees.name : ''}</div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.paidDays}
//                 onChange={e => handleInputChange(salary.id, 'paidDays', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">{salary.monthlySalary}</div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.taxes}
//                 onChange={e => handleInputChange(salary.id, 'taxes', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.earnings}
//                 onChange={e => handleInputChange(salary.id, 'earnings', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">
//               <input 
//                 type="number"
//                 value={salary.deductionsTotal}
//                 onChange={e => handleInputChange(salary.id, 'deductionsTotal', e.target.value)}
//               />
//             </div>
//             <div className="salary-cell">{salary.netSalary}</div>
//             <div className="salary-cell">
//               <button className="btn btn-primary" onClick={() => handleCalculateNetSalary(salary)}>Calculate</button>
//               <br></br>
//               <button className="btn btn-secondary" onClick={() => generatePDF(salary)}>Generate PDF</button>
//               <br></br>
//               <button className="btn btn-info" onClick={() => openCalculator(salary.employees)}>Edit</button>
//             </div>
//           </div>
//         ))}
//       </div>
//       {showCalculator && (
//         <SalaryCalculator1
//           onClose={closeCalculator}
//           isOpen={showCalculator}
//           onUpdate={handleSalaryUpdate}
//           employee={currentEmployee}
//         />
//       )}
//     </div>
//   );
// }

// export default SalaryList;
/////////////////////////////////////////////////
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import './SalaryList.css'; // Import the CSS file for styling
import SalaryCalculator1 from './SalaryCalculator1'; // Import the new component

const SalaryList = () => {
  const [salaries, setSalaries] = useState([]);
  const [message, setMessage] = useState(null);
  const [showCalculator, setShowCalculator] = useState(false); // State to manage the sliding window
  const [currentEmployee, setCurrentEmployee] = useState(null); // State to manage the current employee for calculator
  const [currentEarnings, setCurrentEarnings] = useState({}); // State to store current earnings
  const [currentDeductions, setCurrentDeductions] = useState({}); // State to store current deductions

  useEffect(() => {
    fetchSalaries();
  }, []);

  useEffect(() => {
         if (message) {
           const timer = setTimeout(() => {
             setMessage(null);
          }, 3000); // Adjust the time (in milliseconds) to your preference
    
          return () => clearTimeout(timer);
        }
      }, [message]);

  const fetchSalaries = () => {
    axios.get('http://localhost:8080/api/salary/get')
      .then(response => {
        setSalaries(response.data);
      })
      .catch(error => {
        console.error('Error fetching salaries:', error);
      });
  };

  const handleUpdate = (id, updatedFields) => {
    axios.put(`http://localhost:8080/api/salary/${id}`, updatedFields)
      .then(response => {
        const updatedSalaries = salaries.map(salary => {
          if (salary.id === id) {
            return {
              ...salary,
              ...updatedFields
            };
          }
          return salary;
        });
        setSalaries(updatedSalaries);
        setMessage({ type: 'success', text: 'Salary updated successfully.' });
      })
      .catch(error => {
        console.error(`Error updating salary with ID ${id}:`, error);
        setMessage({ type: 'error', text: 'Error updating salary. Please try again.' });
      });
  };

  const handleInputChange = (id, field, value) => {
    setSalaries(salaries.map(salary => 
      salary.id === id ? { ...salary, [field]: value } : salary
    ));
  };

  const handleUpdateClick = (id) => {
    const salary = salaries.find(salary => salary.id === id);
    const updatedFields = {
      paidDays: salary.paidDays,
      taxes: salary.taxes,
      earnings: salary.earnings,
      deductionsTotal: salary.deductionsTotal,
      netSalary: salary.netSalary
    };

    handleUpdate(id, updatedFields);
  };

  const calculateNetSalary = (empCode, earnings, deductions, taxes) => {
    axios.put(`http://localhost:8080/api/salary/calculate/${empCode}`, {
      earnings,
      deductions,
      taxes
    })
    .then(response => {
      const updatedSalaries = salaries.map(salary => {
        if (salary.employees && salary.employees.empCode === empCode) {
          return {
            ...salary,
            netSalary: response.data.netSalary,
            earnings: response.data.earnings,
            deductionsTotal: response.data.deductionsTotal,
            taxes: response.data.taxes
          };
        }
        return salary;
      });
      setSalaries(updatedSalaries);
      setMessage({ type: 'success', text: `Net salary calculated successfully for employee with id ${empCode}` });
    })
    .catch(error => {
      console.error(`Error calculating net salary for employee with empCode ${empCode}:`, error);
      setMessage({ type: 'error', text: 'Error calculating net salary. Please try again.' });
    });
  };

  const handleCalculateNetSalary = (salary) => {
    if (salary.employees) {
      const confirmed = window.confirm(`Are you sure you want to calculate the net salary for employee ${salary.employees.empCode}?`);
      if (confirmed) {
        calculateNetSalary(salary.employees.empCode, salary.earnings, salary.deductionsTotal, salary.taxes);
      }
    } else {
      setMessage({ type: 'error', text: 'Employee data is missing. Cannot calculate net salary.' });
    }
  };

  const generatePDF = (salary) => {
    const doc = new jsPDF();
    doc.setFontSize(18);
    doc.text('Salary Details', 14, 22);
    doc.setFontSize(12);
    doc.text(`Employee Code: ${salary.employees ? salary.employees.empCode : 'N/A'}`, 14, 30);
    doc.text(`Paid Days: ${salary.paidDays}`, 14, 36);
    doc.text(`Monthly Salary: ${salary.monthlySalary}`, 14, 42);
    doc.text(`Taxes: ${salary.taxes}`, 14, 48);
    doc.text(`Earnings: ${salary.earnings}`, 14, 54);
    doc.text(`Deductions: ${salary.deductionsTotal}`, 14, 60);
    doc.text(`Net Salary: ${salary.netSalary}`, 14, 66);

    doc.text(`Earnings Details: ${JSON.stringify(currentEarnings)}`, 14, 72);
    doc.text(`Deductions Details: ${JSON.stringify(currentDeductions)}`, 14, 78);

    doc.save(`salary_details_${salary.employees ? salary.employees.empCode : 'N/A'}.pdf`);
  };

  const openCalculator = (employee) => {
    setCurrentEmployee(employee);
    setShowCalculator(true);
  };

  const closeCalculator = () => {
    setCurrentEmployee(null);
    setShowCalculator(false);
  };

  const handleSalaryUpdate = () => {
    fetchSalaries();
  };

  const handleSave = (data) => {
    setCurrentEarnings(data.earnings);
    setCurrentDeductions(data.deductions);
  };

  return (
    <div>
       {message && (
         <div className={`alert ${message.type === 'success' ? 'alert-success' : 'alert-danger'}`} role="alert">
           {message.text}
         </div>
    )}
      <div className="salary-table">
        <div className="salary-row header">
          <div className="salary-cell">Employee Code</div>
          <div className="salary-cell">Name</div>
          <div className="salary-cell">Paid Days</div>
          <div className="salary-cell">Monthly Salary</div>
          <div className="salary-cell">Taxes</div>
          <div className="salary-cell">Earnings</div>
          <div className="salary-cell">Deductions</div>
          <div className="salary-cell">Net Salary</div>
          <div className="salary-cell">Actions</div>
        </div>
        {salaries.map(salary => (
          <div className="salary-row" key={salary.id}>
            <div className="salary-cell">{salary.employees ? salary.employees.empCode : ''}</div>
            <div className="salary-cell">{salary.employees ? salary.employees.name : ''}</div>
            <div className="salary-cell">
              <input 
                type="number"
                value={salary.paidDays}
                onChange={e => handleInputChange(salary.id, 'paidDays', e.target.value)}
              />
            </div>
            <div className="salary-cell">{salary.monthlySalary}</div>
            <div className="salary-cell">
              <input 
                type="number"
                value={salary.taxes}
                onChange={e => handleInputChange(salary.id, 'taxes', e.target.value)}
              />
            </div>
            <div className="salary-cell">
              <input 
                type="number"
                value={salary.earnings}
                onChange={e => handleInputChange(salary.id, 'earnings', e.target.value)}
              />
            </div>
            <div className="salary-cell">
              <input 
                type="number"
                value={salary.deductionsTotal}
                onChange={e => handleInputChange(salary.id, 'deductionsTotal', e.target.value)}
              />
            </div>
            <div className="salary-cell">{salary.netSalary}</div>
            <div className="salary-cell">
              <button className="btn btn-primary" onClick={() => handleCalculateNetSalary(salary)}>Calculate</button>
              <br></br>
              <button className="btn btn-secondary" onClick={() => generatePDF(salary)}>Generate PDF</button>
              <br></br>
              <button className="btn btn-info" onClick={() => openCalculator(salary.employees)}>Edit</button>
            </div>
          </div>
        ))}
      </div>
      {showCalculator && (
        <SalaryCalculator1
          onClose={closeCalculator}
          isOpen={showCalculator}
          onUpdate={handleSalaryUpdate}
          onSave={handleSave}
          employee={currentEmployee}
        />
      )}
    </div>
  );
}

export default SalaryList;
