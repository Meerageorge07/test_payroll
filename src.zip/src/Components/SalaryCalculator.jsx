// // src/components/SalaryCalculator.js
// import React, { useState } from 'react';
// import { getGrossSalary } from './salaryService';
// import Sidebar from './Sidebar';
// import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS

// const SalaryCalculator = () => {
//   const [employeeId, setEmployeeId] = useState('');
//   // const [employeeName, setEmployeeName] = useState('');
//   const [salaryComponents, setSalaryComponents] = useState(null);
//   const [error, setError] = useState('');

//   const handleCalculate = async () => {
//     try {
//       const components = await getGrossSalary(employeeId);
//       setSalaryComponents(components);
//       setError('');
//     } catch (error) {
//       setError('Error fetching gross salary. Please try again.');
//       setSalaryComponents(null);
//     }
//   };

//   return (
//     <div className="container">
//       <div className="row">
//         <div className="col-3">
//           <Sidebar />
//         </div>
//         <div className="col-9">
//           <h1>Salary Calculator</h1>
//           <div className="mb-3">
//             <label className="form-label">
//               Employee ID:
//               <input
//                 type="text"
//                 className="form-control"
//                 value={employeeId}
//                 onChange={(e) => setEmployeeId(e.target.value)}
//               />
//             </label>
//           </div>
//           {/* <div className="mb-3">
//             <label className="form-label">
//               Employee Name:
//               <input
//                 type="text"
//                 className="form-control"
//                 value={employeeName}
//                 onChange={(e) => setEmployeeName(e.target.value)}
//               />
//             </label> */}
//           {/* </div> */}
//           <button className="btn btn-primary" onClick={handleCalculate}>
//             Calculate Gross Salary
//           </button>
//           {error && <div className="alert alert-danger mt-3">{error}</div>}
//           {salaryComponents && (
//             <div className="mt-3">
//               <h2>Salary Components</h2>
//               <div className="card">
//                 <div className="card-body">
//                   <div className="d-flex justify-content-between">
//                     <span>Basic Salary:</span>
//                     <span>{salaryComponents.basicSalary}</span>
//                   </div>
//                   <div className="d-flex justify-content-between">
//                     <span>HRA:</span>
//                     <span>{salaryComponents.hra}</span>
//                   </div>
//                   <div className="d-flex justify-content-between">
//                     <span>PF:</span>
//                     <span>{salaryComponents.pf}</span>
//                   </div>
//                   <div className="d-flex justify-content-between">
//                     <span>LTA:</span>
//                     <span>{salaryComponents.lta}</span>
//                   </div>
//                   <div className="d-flex justify-content-between">
//                     <span>Medical Allowance:</span>
//                     <span>{salaryComponents.medicalAllowance}</span>
//                   </div>
//                   <div className="d-flex justify-content-between">
//                     <span>Professional Tax:</span>
//                     <span>{salaryComponents.professionalTax}</span>
//                   </div>
//                   <div className="d-flex justify-content-between">
//                     <span>EPF:</span>
//                     <span>{salaryComponents.epf}</span>
//                   </div>
//                   <div className="d-flex justify-content-between">
//                     <span>Insurance:</span>
//                     <span>{salaryComponents.insurance}</span>
//                   </div>
//                   <div className="d-flex justify-content-between">
//                     <span>Income Tax:</span>
//                     <span>{salaryComponents.incomeTax}</span>
//                   </div>

//                   <br></br>
//                   <div className="d-flex justify-content-between">
//                     <span>Gross Salary:</span>
//                     <span>{salaryComponents.grossSalary}</span>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SalaryCalculator;
import React, { useState } from 'react';
import { getGrossSalary } from './salaryService';
import Sidebar from './Sidebar';
import 'bootstrap/dist/css/bootstrap.min.css';

const SalaryCalculator = () => {
  const [employeeId, setEmployeeId] = useState('');
  const [salaryComponents, setSalaryComponents] = useState(null);
  const [error, setError] = useState('');

  const handleCalculate = async () => {
    try {
      const components = await getGrossSalary(employeeId);
      setSalaryComponents(components);
      setError('');
    } catch (error) {
      setError('Error fetching gross salary. Please try again.');
      setSalaryComponents(null);
    }
  };

  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-lg-5 col-md-4 col-sm-5 mt-5">
          
          <Sidebar />
        </div>
        <div className="col-lg-5 col-md-5 col-sm-5 mt-5">
          <div className="card">
            <div className="card-body">
              <h1 className="card-title">Salary Calculator</h1>
              <div className="mb-3">
                <label className="form-label">
                  Employee ID:
                  <input
                    type="text"
                    className="form-control"
                    value={employeeId}
                    onChange={(e) => setEmployeeId(e.target.value)}
                  />
                </label>
              </div>
              <button className="btn btn-primary mb-3" onClick={handleCalculate}>
                Calculate Gross Salary
              </button>
              {error && <div className="alert alert-danger">{error}</div>}
              {salaryComponents && (
                <div className="card mt-3">
                  <div className="card-body">
                    <h2 className="card-title">Salary Components</h2>
                    <div className="mb-3">
                      <div className="d-flex justify-content-between">
                        <span>Basic Salary:</span>
                        <span>{salaryComponents.basicSalary}</span>
                      </div>
                      <div className="d-flex justify-content-between">
                        <span>HRA:</span>
                        <span>{salaryComponents.hra}</span>
                      </div>
                      <div className="d-flex justify-content-between">
                        <span>PF:</span>
                        <span>{salaryComponents.pf}</span>
                      </div>
                      <div className="d-flex justify-content-between">
                        <span>LTA:</span>
                        <span>{salaryComponents.lta}</span>
                      </div>
                      <div className="d-flex justify-content-between">
                        <span>Medical Allowance:</span>
                        <span>{salaryComponents.medicalAllowance}</span>
                      </div>
                      <div className="d-flex justify-content-between">
                        <span>Professional Tax:</span>
                        <span>{salaryComponents.professionalTax}</span>
                      </div>
                      <div className="d-flex justify-content-between">
                        <span>EPF:</span>
                        <span>{salaryComponents.epf}</span>
                      </div>
                      <div className="d-flex justify-content-between">
                        <span>Insurance:</span>
                        <span>{salaryComponents.insurance}</span>
                      </div>
                      <div className="d-flex justify-content-between">
                        <span>Income Tax:</span>
                        <span>{salaryComponents.incomeTax}</span>
                      </div>
                      {/* <div className="d-flex justify-content-between">
                        <span>Gross Salary:</span>
                        <span>{salaryComponents.grossSalary}</span>
                      </div>
                      <div className="d-flex justify-content-between">
                        <span>Net Salary:</span>
                        <span>{salaryComponents.netSalary}</span> */}
                      {/* </div> */}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SalaryCalculator;
