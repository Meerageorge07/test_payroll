
// // import React, { useState, useEffect } from 'react';
// // import axios from 'axios';
// // import 'bootstrap/dist/css/bootstrap.min.css';
// // import 'bootstrap/dist/js/bootstrap.bundle.min';

// // const SalaryMonthModal = ({ employee, handleClose, onSalaryCreated }) => {
// //   const [months, setMonths] = useState([]);
// //   const [years, setYears] = useState([]);
// //   const [earnings, setEarnings] = useState(0);
// //   const [deductions, setDeductions] = useState(0);
// //   const [selectedMonth, setSelectedMonth] = useState(null);
// //   const [selectedYear, setSelectedYear] = useState(null);

// //   useEffect(() => {
// //     const calculateMonthsAndYears = () => {
// //       const currentMonth = new Date().getMonth() + 1;
// //       const currentYear = new Date().getFullYear();
// //       const before2Month = currentMonth - 2;
// //       const monthsArray = [];
// //       const yearsArray = [];

// //       for (let i = before2Month; i < before2Month + 16; i++) {
// //         const date = new Date(currentYear, i, 1);
// //         monthsArray.push(date.toLocaleString('default', { month: 'long' }));
// //         yearsArray.push(date.getFullYear());
// //       }

// //       setMonths(monthsArray);
// //       setYears(yearsArray);
// //     };

// //     calculateMonthsAndYears();
// //   }, []);

// //   const handleMonthClick = (month, year) => {
// //     setSelectedMonth(month);
// //     setSelectedYear(year);
// //   };

// //   const handleSubmit = async () => {
// //     const salaryData = {
// //       empCode: employee.empCode,
// //       name: employee.name,
// //       salaryMonth: `${selectedMonth} ${selectedYear}`,
// //       earnings: earnings,
// //       deductions: deductions,
// //       netSalary: earnings - deductions,
// //     };

// //     try {
// //       const response = await axios.post("http://localhost:8080/api/salary", salaryData);
// //       onSalaryCreated(response.data);
// //       handleClose();
// //     } catch (error) {
// //       console.error("Error creating salary:", error);
// //     }
// //   };

// //   return (
// //     <div className={`modal fade show`} style={{ display: 'block' }} tabIndex="-1">
// //       <div className="modal-dialog">
// //         <div className="modal-content">
// //           <div className="modal-header">
// //             <button type="button" className="close" aria-label="Close" onClick={handleClose}>
// //               <span aria-hidden="true">&times;</span>
// //             </button>
// //             <h4 className="modal-title">Select Month for Salary</h4>
// //           </div>
// //           <div className="modal-body">
// //             {!selectedMonth && !selectedYear ? (
// //               <div className="row">
// //                 {months.map((month, index) => (
// //                   <div
// //                     key={index}
// //                     className={`col-sm-3 ${month === new Date().toLocaleString('default', { month: 'long' }) && years[index] === new Date().getFullYear() ? 'bg-danger' : ''}`}
// //                   >
// //                     <a href="#" onClick={() => handleMonthClick(month, years[index])}>
// //                       {month.toUpperCase()}<br />{years[index]}
// //                     </a>
// //                   </div>
// //                 ))}
// //               </div>
// //             ) : (
// //               <div>
// //                 <div className="form-group">
// //                   <label htmlFor="selectedMonth">Selected Month</label>
// //                   <input
// //                     type="text"
// //                     className="form-control"
// //                     id="selectedMonth"
// //                     value={`${selectedMonth} ${selectedYear}`}
// //                     readOnly
// //                   />
// //                 </div>
// //                 <div className="form-group">
// //                   <label htmlFor="earnings">Earnings</label>
// //                   <input
// //                     type="number"
// //                     className="form-control"
// //                     id="earnings"
// //                     value={earnings}
// //                     onChange={(e) => setEarnings(parseFloat(e.target.value))}
// //                   />
// //                 </div>
// //                 <div className="form-group">
// //                   <label htmlFor="deductions">Deductions</label>
// //                   <input
// //                     type="number"
// //                     className="form-control"
// //                     id="deductions"
// //                     value={deductions}
// //                     onChange={(e) => setDeductions(parseFloat(e.target.value))}
// //                   />
// //                 </div>
// //                 <button type="button" className="btn btn-primary" onClick={handleSubmit}>
// //                   Submit
// //                 </button>
// //               </div>
// //             )}
// //           </div>
// //         </div>
// //       </div>
// //     </div>
// //   );
// // };

// // export default SalaryMonthModal;
// //=================================
// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import 'bootstrap/dist/css/bootstrap.min.css';
// import 'bootstrap/dist/js/bootstrap.bundle.min';

// const SalaryMonthModal = ({ employee, handleClose, onSalaryCreated }) => {
//   const [months, setMonths] = useState([]);
//   const [years, setYears] = useState([]);
//   const [payheads, setPayheads] = useState([]);
//   const [selectedPayheads, setSelectedPayheads] = useState([]);
//   const [selectedMonth, setSelectedMonth] = useState(null);
//   const [selectedYear, setSelectedYear] = useState(null);

//   useEffect(() => {
//     const calculateMonthsAndYears = () => {
//       const currentMonth = new Date().getMonth() + 1;
//       const currentYear = new Date().getFullYear();
//       const before2Month = currentMonth - 2;
//       const monthsArray = [];
//       const yearsArray = [];

//       for (let i = before2Month; i < before2Month + 16; i++) {
//         const date = new Date(currentYear, i, 1);
//         monthsArray.push(date.toLocaleString('default', { month: 'long' }));
//         yearsArray.push(date.getFullYear());
//       }

//       setMonths(monthsArray);
//       setYears(yearsArray);
//     };

//     calculateMonthsAndYears();

//     const fetchPayheads = async () => {
//       try {
//         const response = await axios.get("http://localhost:8080/api/payheads");
//         setPayheads(response.data);
//       } catch (error) {
//         console.error("Error fetching payheads:", error);
//       }
//     };

//     fetchPayheads();
//   }, []);

//   const handleMonthClick = (month, year) => {
//     setSelectedMonth(month);
//     setSelectedYear(year);
//   };

//   const handlePayheadChange = (index, amount) => {
//     const newSelectedPayheads = [...selectedPayheads];
//     newSelectedPayheads[index] = {
//       ...newSelectedPayheads[index],
//       amount: parseFloat(amount) || 0
//     };
//     setSelectedPayheads(newSelectedPayheads);
//   };

//   const handlePayheadSelect = (payhead) => {
//     setSelectedPayheads([...selectedPayheads, { ...payhead, amount: 0 }]);
//   };

//   const handleRemovePayhead = (index) => {
//     const newSelectedPayheads = selectedPayheads.filter((_, i) => i !== index);
//     setSelectedPayheads(newSelectedPayheads);
//   };

//   const calculateTotals = () => {
//     let earnings = 0;
//     let deductions = 0;
//     selectedPayheads.forEach((payhead) => {
//       if (payhead.type === "earning") {
//         earnings += payhead.amount;
//       } else if (payhead.type === "deduction") {
//         deductions += payhead.amount;
//       }
//     });
//     return { earnings, deductions };
//   };

//   const handleSubmit = async () => {
//     const { earnings, deductions } = calculateTotals();
//     const salaryData = {
//       empCode: employee.empCode,
//       name: employee.name,
//       salaryMonth: `${selectedMonth} ${selectedYear}`,
//       earnings,
//       deductions,
//       netSalary: earnings - deductions,
//       payheads: selectedPayheads
//     };

//     try {
//       const response = await axios.post("http://localhost:8080/api/salary/calculate", salaryData);
//       onSalaryCreated(response.data);
//       handleClose();
//     } catch (error) {
//       console.error("Error creating salary:", error);
//     }
//   };

//   return (
//     <div className={`modal fade show`} style={{ display: 'block' }} tabIndex="-1">
//       <div className="modal-dialog">
//         <div className="modal-content">
//           <div className="modal-header">
//             <button type="button" className="close" aria-label="Close" onClick={handleClose}>
//               <span aria-hidden="true">&times;</span>
//             </button>
//             <h4 className="modal-title">Select Month for Salary</h4>
//           </div>
//           <div className="modal-body">
//             {!selectedMonth && !selectedYear ? (
//               <div className="row">
//                 {months.map((month, index) => (
//                   <div
//                     key={index}
//                     className={`col-sm-3 ${month === new Date().toLocaleString('default', { month: 'long' }) && years[index] === new Date().getFullYear() ? 'bg-danger' : ''}`}
//                   >
//                     <a href="#" onClick={() => handleMonthClick(month, years[index])}>
//                       {month.toUpperCase()}<br />{years[index]}
//                     </a>
//                   </div>
//                 ))}
//               </div>
//             ) : (
//               <div>
//                 <div className="form-group">
//                   <label htmlFor="selectedMonth">Selected Month</label>
//                   <input
//                     type="text"
//                     className="form-control"
//                     id="selectedMonth"
//                     value={`${selectedMonth} ${selectedYear}`}
//                     readOnly
//                   />
//                 </div>
//                 <div className="form-group">
//                   <label htmlFor="payheadSelect">Select Payhead</label>
//                   <select
//                     className="form-control"
//                     id="payheadSelect"
//                     onChange={(e) => handlePayheadSelect(payheads.find(ph => ph.id === parseInt(e.target.value)))}
//                   >
//                     <option value="">--Select Payhead--</option>
//                     {payheads.map((payhead) => (
//                       <option key={payhead.id} value={payhead.id}>
//                         {payhead.name} ({payhead.type})
//                       </option>
//                     ))}
//                   </select>
//                 </div>
//                 <div>
//                   {selectedPayheads.map((payhead, index) => (
//                     <div key={index} className="form-group">
//                       <label>{payhead.name} ({payhead.type})</label>
//                       <input
//                         type="number"
//                         className="form-control"
//                         value={payhead.amount}
//                         onChange={(e) => handlePayheadChange(index, e.target.value)}
//                       />
//                       <button className="btn btn-danger" onClick={() => handleRemovePayhead(index)}>Remove</button>
//                     </div>
//                   ))}
//                 </div>
//                 <button type="button" className="btn btn-primary" onClick={handleSubmit}>
//                   Submit
//                 </button>
//               </div>
//             )}
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SalaryMonthModal;
////////////////////////////////////=================================///////////
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';

const SalaryMonthModal = ({ employee, handleClose, showAddSalaryModal, onSalaryCreated }) => {
  const [months, setMonths] = useState([]);
  const [years, setYears] = useState([]);
  const [payheads, setPayheads] = useState([]);
  const [selectedPayheads, setSelectedPayheads] = useState([]);
  const [selectedMonth, setSelectedMonth] = useState(null);
  const [selectedYear, setSelectedYear] = useState(null);

  useEffect(() => {
    const calculateMonthsAndYears = () => {
      const currentMonth = new Date().getMonth() + 1;
      const currentYear = new Date().getFullYear();
      const before2Month = currentMonth - 2;
      const monthsArray = [];
      const yearsArray = [];

      for (let i = before2Month; i < before2Month + 16; i++) {
        const date = new Date(currentYear, i, 1);
        monthsArray.push(date.toLocaleString('default', { month: 'long' }));
        yearsArray.push(date.getFullYear());
      }

      setMonths(monthsArray);
      setYears(yearsArray);
    };

    calculateMonthsAndYears();

    const fetchPayheads = async () => {
      try {
        const response = await axios.get("http://localhost:8080/api/payheads");
        setPayheads(response.data);
      } catch (error) {
        console.error("Error fetching payheads:", error);
      }
    };

    fetchPayheads();
  }, []);

  const handleMonthClick = (month, year) => {
    setSelectedMonth(month);
    setSelectedYear(year);
  };

  const handlePayheadChange = (index, amount) => {
    const newSelectedPayheads = [...selectedPayheads];
    newSelectedPayheads[index] = {
      ...newSelectedPayheads[index],
      amount: parseFloat(amount) || 0
    };
    setSelectedPayheads(newSelectedPayheads);
  };

  const handlePayheadSelect = (payhead) => {
    setSelectedPayheads([...selectedPayheads, { ...payhead, amount: 0 }]);
  };

  const handleRemovePayhead = (index) => {
    const newSelectedPayheads = selectedPayheads.filter((_, i) => i !== index);
    setSelectedPayheads(newSelectedPayheads);
  };

  const calculateTotals = () => {
    let earnings = 0;
    let deductions = 0;
    selectedPayheads.forEach((payhead) => {
      if (payhead.type === "earning") {
        earnings += payhead.amount;
      } else if (payhead.type === "deduction") {
        deductions += payhead.amount;
      }
    });
    return { earnings, deductions };
  };

  const handleSubmit = async () => {
    const { earnings, deductions } = calculateTotals();
    const salaryData = {
      empCode: employee.empCode,
      name: employee.name,
      salaryMonth: `${selectedMonth} ${selectedYear}`,
      earnings,
      deductions,
      netSalary: earnings - deductions,
      payheads: selectedPayheads
    };

    try {
      const response = await axios.post("http://localhost:8080/api/salary", salaryData);
      onSalaryCreated(response.data);
      handleClose();
    } catch (error) {
      console.error("Error creating salary:", error);
    }
  };

  return (
    <div className={`modal fade show`} style={{ display: 'block' }} tabIndex="-1">
      <div className="modal-dialog">
        <div className="modal-content">
          <div className="modal-header">
            <button type="button" className="close" aria-label="Close" onClick={handleClose}>
              <span aria-hidden="true">&times;</span>
            </button>
            <h4 className="modal-title">Select Month for Salary</h4>
          </div>
          <div className="modal-body">
            {!selectedMonth && !selectedYear ? (
              <div className="row">
                {months.map((month, index) => (
                  <div
                    key={index}
                    className={`col-sm-3 ${month === new Date().toLocaleString('default', { month: 'long' }) && years[index] === new Date().getFullYear() ? 'bg-danger' : ''}`}
                  >
                    <a href="#" onClick={() => handleMonthClick(month, years[index])}>
                      {month.toUpperCase()}<br />{years[index]}
                    </a>
                  </div>
                ))}
              </div>
            ) : (
              <div>
                <div className="form-group">
                  <label htmlFor="selectedMonth">Selected Month</label>
                  <input
                    type="text"
                    className="form-control"
                    id="selectedMonth"
                    value={`${selectedMonth} ${selectedYear}`}
                    readOnly
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="payheadSelect">Select Payhead</label>
                  <select
                    className="form-control"
                    id="payheadSelect"
                    onChange={(e) => handlePayheadSelect(payheads.find(ph => ph.id === parseInt(e.target.value)))}
                  >
                    <option value="">--Select Payhead--</option>
                    {payheads.map((payhead) => (
                      <option key={payhead.id} value={payhead.id}>
                        {payhead.name} ({payhead.type})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  {selectedPayheads.map((payhead, index) => (
                    <div key={index} className="form-group">
                      <label>{payhead.name} ({payhead.type})</label>
                      <input
                        type="number"
                        className="form-control"
                        value={payhead.amount}
                        onChange={(e) => handlePayheadChange(index, e.target.value)}
                      />
                      <button className="btn btn-danger" onClick={() => handleRemovePayhead(index)}>Remove</button>
                    </div>
                  ))}
                </div>
                <button type="button" className="btn btn-primary" onClick={handleSubmit}>
                  Submit
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SalaryMonthModal;
