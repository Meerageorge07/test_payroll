// src/CalculateSalaryForm.js

import React, { useState } from 'react';

const SalaryForm = () => {
    const [empCode, setEmpCode] = useState('');
    const [salaryMonth, setSalaryMonth] = useState('');
    const [earnings, setEarnings] = useState('');
    const [deductions, setDeductions] = useState('');
    const [calculatedSalary, setCalculatedSalary] = useState(null);

    const handleSubmit = async (e) => {
        e.preventDefault();

        const response = await fetch("http://localhost:8080/api/salary/calculate", {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                empCode,
                salaryMonth,
                earnings: parseFloat(earnings),
                deductions: parseFloat(deductions),
            }),
        });

        if (response.ok) {
            const data = await response.json();
            setCalculatedSalary(data);
        } else {
            console.error('Failed to calculate salary');
        }
    };

    return (
        <div>
            <h2>Calculate Salary</h2>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>
                        Employee Code:
                        <input type="text" value={empCode} onChange={(e) => setEmpCode(e.target.value)} required />
                    </label>
                </div>
                <div>
                    <label>
                        Salary Month:
                        <input type="text" value={salaryMonth} onChange={(e) => setSalaryMonth(e.target.value)} required />
                    </label>
                </div>
                <div>
                    <label>
                        Earnings:
                        <input type="number" step="0.01" value={earnings} onChange={(e) => setEarnings(e.target.value)} required />
                    </label>
                </div>
                <div>
                    <label>
                        Deductions:
                        <input type="number" step="0.01" value={deductions} onChange={(e) => setDeductions(e.target.value)} required />
                    </label>
                </div>
                <button type="submit">Calculate</button>
            </form>
            {calculatedSalary && (
                <div>
                    <h3>Calculated Salary</h3>
                    <p>Employee: {calculatedSalary.employees.name}</p>
                    <p>Salary Month: {calculatedSalary.salaryMonth}</p>
                    <p>Earnings Total: {calculatedSalary.earningsTotal}</p>
                    <p>Deductions Total: {calculatedSalary.deductionsTotal}</p>
                    <p>Net Salary: {calculatedSalary.netSalary}</p>
                </div>
            )}
        </div>
    );
};

export default SalaryForm;
