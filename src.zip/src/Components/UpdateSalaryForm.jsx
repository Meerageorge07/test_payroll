import React, { useState } from 'react';
import axios from 'axios';

function UpdateSalaryForm({ salary, onUpdate }) {
    const [updatedSalary, setUpdatedSalary] = useState({
        paystructure: salary.paystructure ? salary.paystructure.paystructure : '',
        employees: salary.employees ? salary.employees.empCode : '',
        paidDays: salary.paidDays || '',
        Taxes: salary.Taxes || '',
        payheadname: salary.payheadname || '',
        salaryMonth: salary.salaryMonth || '',
        payAmount: salary.payAmount || '',
        earningsTotal: salary.earningsTotal || '',
        deductionsTotal: salary.deductionsTotal || '',
        netSalary: salary.netSalary || '',
        payType: salary.payType || '',
        monthlySalary: salary.monthlySalary || ''
    });

    const handleInputChange = event => {
        const { name, value } = event.target;
        setUpdatedSalary(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const handleSubmit = event => {
        event.preventDefault();
        axios.put(`http://localhost:8080/api/salary/update/${salary.id}`, updatedSalary)
            .then(response => {
                console.log('Salary updated successfully:', response.data);
                onUpdate(response.data); // Update the state with the updated salary
            })
            .catch(error => {
                console.error('Error updating salary:', error);
            });
    };

    return (
        <form onSubmit={handleSubmit}>
            <input type="text" name="paystructure" value={updatedSalary.paystructure} onChange={handleInputChange} />
            <input type="text" name="employees" value={updatedSalary.employees} onChange={handleInputChange} />
            <input type="number" name="paidDays" value={updatedSalary.paidDays} onChange={handleInputChange} />
            <input type="number" name="Taxes" value={updatedSalary.Taxes} onChange={handleInputChange} />
            <input type="text" name="payheadname" value={updatedSalary.payheadname} onChange={handleInputChange} />
            <input type="text" name="salaryMonth" value={updatedSalary.salaryMonth} onChange={handleInputChange} />
            <input type="text" name="payAmount" value={updatedSalary.payAmount} onChange={handleInputChange} />
            <input type="number" name="earningsTotal" value={updatedSalary.earningsTotal} onChange={handleInputChange} />
            <input type="number" name="deductionsTotal" value={updatedSalary.deductionsTotal} onChange={handleInputChange} />
            <input type="number" name="netSalary" value={updatedSalary.netSalary} onChange={handleInputChange} />
            <input type="text" name="payType" value={updatedSalary.payType} onChange={handleInputChange} />
            <input type="number" name="monthlySalary" value={updatedSalary.monthlySalary} onChange={handleInputChange} />
            <button type="submit">Update</button>
        </form>
    );
}

export default UpdateSalaryForm;
