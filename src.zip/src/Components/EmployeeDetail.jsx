// import React, { useEffect, useState } from 'react';
// import axios from 'axios';

// const EmployeeDetail = ({ empCode }) => {
//     const [employees, setEmployee] = useState(null);
//     const [salaries, setSalaries] = useState([]);

//     // useEffect(() => {
//     //     axios.get(`/api/employees/${empCode}`)
//     //         .then(response => setEmployee(response.data));

//     //     axios.get(`/api/salaries/${empCode}/currentMonth`) // Assuming you have a way to get the current month
//     //         .then(response => setSalaries(response.data));
//     // }, [empCode]);

//     // if (!employee) return <div>Loading...</div>;

//     return (
//         <div>
//             <h1>Salary for {employees.name} </h1>
//             <table>
//                 <thead>
//                     <tr>
//                         <th>Earnings</th>
//                         <th>Amount (Rs.)</th>
//                         <th>Deductions</th>
//                         <th>Amount (Rs.)</th>
//                     </tr>
//                 </thead>
//                 <tbody>
//                     {salaries.map(salary => (
//                         <tr key={salary.id}>
//                             <td>{salary.payheadName}</td>
//                             <td>{salary.payAmount}</td>
//                         </tr>
//                     ))}
//                 </tbody>
//             </table>
//         </div>
//     );
// };

// export default EmployeeDetail;
