// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import { Button } from 'react-bootstrap';
// import AddSalaryModal from './AddSalaryModal';
// import Sidebar from './Sidebar';
// import './Salaries.css';

// const Salaries = () => {
//     const [salaries, setSalaries] = useState([]);
//     // const [showModal, setShowModal] = useState(false);

//     useEffect(() => {
//         fetchSalaries(); // Fetch salaries on component mount
//     }, []);

//     const fetchSalaries = () => {
//         axios.get("http://localhost:8080/api/salary/get")
//             .then(response => {
//                 setSalaries(response.data);
//             })
//             .catch(error => {
//                 console.error('Error fetching salaries:', error);
//             });
//     };

//     // const handleCloseModal = () => setShowModal(false);

//     const handleAddSalary = (newSalary) => {
//         axios.post("http://localhost:8080/api/salary/get", newSalary)
//             .then(response => {
//                 setSalaries([...salaries, response.data]);
//                 // handleCloseModal(); // Close modal after successful addition
//             })
//             .catch(error => {
//                 console.error('Error creating salary:', error);
//             });
//     };

//     return (
//         <div className="main-layout">
//             <Sidebar/>
//             <div className="content">
//             <div className="d-flex justify-content-end mb-4">
//                 {/* <Button variant="primary" onClick={() => setShowModal(true)}>
//                     Add Salary
//                 </Button> */}
//             </div>
//             <h2 className="text-center">Salaries</h2>
//             <table className="table table-bordered table-striped">
//                 <thead>
//                     <tr>
//                         <th>Employee ID</th>
//                         <th>Salary Month</th>
//                         <th>Earnings</th>
//                         <th>Deductions</th>
//                         <th>Net Salary</th>

//                     </tr>
//                 </thead>
//                 <tbody>
//                     {salaries.map((salary, index) => (
//                         <tr key={salary.id}>
//                             <td>{salary.employees.empCode}</td>
//                            <td>{salary.salaryMonth}</td>
//                             <td>{salary.earningsTotal}</td>
//                             <td>{salary.deductionsTotal}</td>
//                             <td>{salary.netSalary}</td>
//                         </tr>
//                     ))}
//                 </tbody>
//             </table>
//             {/* <AddSalaryModal
//                 show={showModal}
//                 handleClose={handleCloseModal}
//                 handleAddSalary={handleAddSalary}
//             /> */}
//         </div></div>
//     );
// };

// export default Salaries;
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Button } from 'react-bootstrap';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import AddSalaryModal from './AddSalaryModal';
import Sidebar from './Sidebar';
import './Salaries.css';

const Salaries = () => {
    const [salaries, setSalaries] = useState([]);
    // const [showModal, setShowModal] = useState(false);

    useEffect(() => {
        fetchSalaries(); // Fetch salaries on component mount
    }, []);

    const fetchSalaries = () => {
        axios.get("http://localhost:8080/api/salary/get")
            .then(response => {
                setSalaries(response.data);
            })
            .catch(error => {
                console.error('Error fetching salaries:', error);
            });
    };

    // const handleCloseModal = () => setShowModal(false);

    const handleAddSalary = (newSalary) => {
        axios.post("http://localhost:8080/api/salary/get", newSalary)
            .then(response => {
                setSalaries([...salaries, response.data]);
                // handleCloseModal(); // Close modal after successful addition
            })
            .catch(error => {
                console.error('Error creating salary:', error);
            });
    };

    const generatePDF = (salary) => {
        const doc = new jsPDF();

        doc.text('Payslip', 14, 22);
        doc.autoTable({
            startY: 30,
            head: [['Field', 'Value']],
            body: [
                ['Employee ID', salary.employees.empCode],
                ['Salary Month', salary.salaryMonth],
                ['Earnings', salary.earningsTotal],
                ['Deductions', salary.deductionsTotal],
                ['Net Salary', salary.netSalary]
            ]
        });

        doc.save(`payslip_${salary.employees.empCode}.pdf`);
    };

    return (
        <div className="main-layout">
            <Sidebar />
            <div className="content">
                <div className="d-flex justify-content-end mb-4">
                    {/* <Button variant="primary" onClick={() => setShowModal(true)}>
                        Add Salary
                    </Button> */}
                </div>
                <h2 className="text-center">Salaries</h2>
                <table className="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Employee ID</th>
                            <th>Salary Month</th>
                            <th>Earnings</th>
                            <th>Deductions</th>
                            <th>Net Salary</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        {salaries.map((salary, index) => (
                            <tr key={salary.id}>
                                <td>{salary.employees.empCode}</td>
                                <td>{salary.salaryMonth}</td>
                                <td>{salary.earningsTotal}</td>
                                <td>{salary.deductionsTotal}</td>
                                <td>{salary.netSalary}</td>
                                <td>
                                    <Button
                                        variant="secondary"
                                        onClick={() => generatePDF(salary)}
                                    >
                                        Generate Payslip
                                    </Button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                {/* <AddSalaryModal
                    show={showModal}
                    handleClose={handleCloseModal}
                    handleAddSalary={handleAddSalary}
                /> */}
            </div>
        </div>
    );
};

export default Salaries;
