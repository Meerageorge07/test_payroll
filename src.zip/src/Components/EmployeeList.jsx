
// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import { useNavigate } from 'react-router-dom';
// import Sidebar from './Sidebar';
// import './EmployeeList.css';
// import SalaryCalModal from './SalaryCalModal';
// import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
// import { faMoneyBillAlt } from '@fortawesome/free-solid-svg-icons';

// const EmployeeList = () => {
//     const [registration, setRegistration] = useState([]);
//     const [calculatedSalary, setCalculatedSalary] = useState(null);
//     const [showSalaryModal, setShowSalaryModal] = useState(false);

//     const navigate = useNavigate();

//     useEffect(() => {
//         async function fetchRegistration() {
//             try {
//                 const response = await axios.get("http://localhost:8080/api/list");
//                 setRegistration(response.data);
//             } catch (error) {
//                 console.error("Error fetching registrations:", error);
//             }
//         }

//         fetchRegistration();
//     }, []);

//     const handleSalarySubmit = async (data) => {
//         try {
//             const response = await axios.post('http://localhost:8080/api/salary/calculate', {
//                 empCode: data.empCode,
//                 salaryMonth: data.salaryMonth,
//                 earnings: data.earnings,
//                 deductions: data.deductions
//             });

//             if (response.status === 200) {
//                 const result = response.data;
//                 setCalculatedSalary(result);
//                 setShowSalaryModal(false);
//             } else {
//                 console.error('Failed to calculate salary');
//             }
//         } catch (error) {
//             console.error('Error calculating salary:', error);
//         }
//     };

//     const handleSalaryCreated = (data) => {
//         setCalculatedSalary(data);
//     };

//     const showSalaryCalculatorModal = () => {
//         setShowSalaryModal(true);
//     };

//     const hideSalaryCalculatorModal = () => {
//         setShowSalaryModal(false);
//     };

//     return (
//         <div className="main-layout">
//             <Sidebar />
//             <div className="content">
//                 <h2 className="text-center">Employees</h2>

//                 <table className="table table-bordered table-striped">
//                     <thead>
//                         <tr>
//                             <th>Sl.No</th>
//                             <th>Name</th>
//                             <th>Date Of Joining</th>
//                             <th>Email</th>
//                             <th>Position</th>
//                             <th>Net Salary</th>
//                             <th>Actions</th>
//                         </tr>
//                     </thead>
//                     <tbody>
//                         {registration.map((employee, index) => (
//                             <tr key={employee.id}>
//                                 <td>{index + 1}</td>
//                                 <td>{employee.name}</td>
//                                 <td>{employee.dateOfJoining}</td>
//                                 <td>{employee.email}</td>
//                                 <td>{employee.position}</td>
//                                 <td>{employee.monthlySalary}</td>
//                                 <td>
//                                 <div className="actions">
//                                     <button
//                                         type="button" 
//                                         className="btn btn-primary btn-icon"
//                                         onClick={showSalaryCalculatorModal}
//                                     >
//                                        <FontAwesomeIcon icon={faMoneyBillAlt} />
//                                     </button>
//                                     </div>
//                                 </td>
//                             </tr>
//                         ))}
//                     </tbody>
//                 </table>
//             </div>

//             <SalaryCalModal
//                 showModal={showSalaryModal}
//                 handleCloseModal={hideSalaryCalculatorModal}
//                 handleSalarySubmit={handleSalarySubmit}
//                 handleSalaryCreated={handleSalaryCreated}
//             />

//             {calculatedSalary && (
//                 <div className="mt-4">
//                     <h2>Salary Details</h2>
//                     <p><strong>Net Salary:</strong> {calculatedSalary.netSalary}</p>
//                     <p><strong>Earnings Total:</strong> {calculatedSalary.earningsTotal}</p>
//                     <p><strong>Deductions Total:</strong> {calculatedSalary.deductionsTotal}</p>
//                 </div>
//             )}
//         </div>
//     );
// };

//  export default EmployeeList;
//  //====================================================

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import Sidebar from './Sidebar';
import './EmployeeList.css';
import SalaryCalModal from './SalaryCalModal';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMoneyBillAlt } from '@fortawesome/free-solid-svg-icons';

const EmployeeList = () => {
    const [registration, setRegistration] = useState([]);
    const [calculatedSalary, setCalculatedSalary] = useState(null);
    const [showSalaryModal, setShowSalaryModal] = useState(false);
    const [salaryMessage, setSalaryMessage] = useState('');

    const navigate = useNavigate();

    useEffect(() => {
        async function fetchRegistration() {
            try {
                const response = await axios.get("http://localhost:8080/api/list");
                setRegistration(response.data);
            } catch (error) {
                console.error("Error fetching registrations:", error);
            }
        }

        fetchRegistration();
    }, []);

    const handleSalarySubmit = async (data) => {
        try {
            const response = await axios.post('http://localhost:8080/api/salary/calculate', {
                empCode: data.empCode,
                salaryMonth: data.salaryMonth,
                earnings: data.earnings,
                deductions: data.deductions
            });

            if (response.status === 200) {
                const result = response.data;
                setCalculatedSalary(result);
                setShowSalaryModal(false);
                setSalaryMessage('Salary created successfully!');
            } else {
                console.error('Failed to calculate salary');
            }
        } catch (error) {
            console.error('Error calculating salary:', error);
        }
    };

    const handleSalaryCreated = (data) => {
        setCalculatedSalary(data);
    };

    const handleSalaryCreatedMessage = (message) => {
        setSalaryMessage(message);
    };

    const showSalaryCalculatorModal = () => {
        setShowSalaryModal(true);
    };

    const hideSalaryCalculatorModal = () => {
        setShowSalaryModal(false);
    };

    return (
        <div className="main-layout">
            <Sidebar />
            <div className="content">
                <h2 className="text-center">Employees</h2>

                <table className="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Sl.No</th>
                            <th>Name</th>
                            <th>Date Of Joining</th>
                            <th>Email</th>
                            <th>Position</th>
                            <th>Monthly Salary</th>
                            {/* <th>Actions</th> */}
                        </tr>
                    </thead>
                    <tbody>
                        {registration.map((employee, index) => (
                            <tr key={employee.id}>
                                <td>{index + 1}</td>
                                <td>{employee.name}</td>
                                <td>{employee.dateOfJoining}</td>
                                <td>{employee.email}</td>
                                <td>{employee.position}</td>
                                <td>{employee.monthlySalary}</td>
                                {/* <td>
                                <div className="actions">
                                    <button
                                        type="button" 
                                        className="btn btn-primary btn-icon"
                                        onClick={showSalaryCalculatorModal}
                                    >
                                       <FontAwesomeIcon icon={faMoneyBillAlt} />
                                    </button>
                                    </div>
                                </td> */}
                            </tr>
                        ))}
                    </tbody>
                </table>

                {salaryMessage && (
                    <div className="alert alert-success mt-4">
                        {salaryMessage}
                    </div>
                )}

                {calculatedSalary && (
                    <div className="mt-4">
                        <h2>Salary Details</h2>
                        <p><strong>Net Salary:</strong> {calculatedSalary.netSalary}</p>
                        <p><strong>Earnings Total:</strong> {calculatedSalary.earningsTotal}</p>
                        <p><strong>Deductions Total:</strong> {calculatedSalary.deductionsTotal}</p>
                    </div>
                )}
            </div>

            <SalaryCalModal
                showModal={showSalaryModal}
                handleCloseModal={hideSalaryCalculatorModal}
                handleSalarySubmit={handleSalarySubmit}
                handleSalaryCreatedMessage={handleSalaryCreatedMessage}
            />
        </div>
    );
};

export default EmployeeList;

