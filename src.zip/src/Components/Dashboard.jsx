
// import React from 'react';
// import Sidebar from './Sidebar';
// import './Dashboard.css';

// const Dashboard = () => {
//   return (
//     <div className="main-layout">
//             <Sidebar/>
//             <div className="content">
//                 <div className="container mt-4">
//                     <div className="d-flex justify-content-end mb-4"></div>
//     <div className="user-page">
//       <Sidebar />
//       <div className="main-content">
//         <h1>Welcome to the User Dashboard</h1>
//         <p>This is the main content area where user-specific content will be displayed.</p>
//       </div>
//     </div> </div> </div> </div>
//   );
// };

// export default Dashboard;
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Sidebar from './Sidebar';
import { Card } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Dashboard.css';

const EmployeeCountCard = () => {
  const [employeeCount, setEmployeeCount] = useState(0);

  useEffect(() => {
    const fetchEmployeeCount = async () => {
      try {
        const response = await axios.get("http://localhost:8080/api/employees/count");
        setEmployeeCount(response.data);
      } catch (error) {
        console.error('Error fetching employee count:', error);
      }
    };

    fetchEmployeeCount();
  }, []);

  return (
    <div className="main-layout">
      <Sidebar />
      <div className="content">
        <div className="container mt-4">
          <div className="d-flex justify-content-end mb-4"></div>

          <Card
            className="text-center square-card"
            style={{ width: '200px', height: '200px' }}
          >
            <Card.Body className="card-body">
              <Card.Title>Active Employees</Card.Title>
              <Card.Text>{employeeCount}</Card.Text>
            </Card.Body>
          </Card>

        </div>
      </div>
    </div>
  );
};

export default EmployeeCountCard;


