package com.example.payroll_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PayrollManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
