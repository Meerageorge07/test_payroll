package com.example.payroll_management.dto;

public class payrunDto {
    private String empCode;
    private String employeeName;
    private long paidDays;
    private double deductions;
    private double earnings;
    private double taxes;

    public payrunDto() {
    }

    public payrunDto(String empCode, String employeeName, long paidDays, double deductions, double earnings, double taxes) {
        this.empCode = empCode;
        this.employeeName = employeeName;
        this.paidDays = paidDays;
        this.deductions = deductions;
        this.earnings = earnings;
        this.taxes = taxes;
    }

    public String getEmpCode() {
        return empCode;
    }

    public void setEmpCode(String empCode) {
        this.empCode = empCode;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public long getPaidDays() {
        return paidDays;
    }

    public void setPaidDays(long paidDays) {
        this.paidDays = paidDays;
    }

    public double getDeductions() {
        return deductions;
    }

    public void setDeductions(double deductions) {
        this.deductions = deductions;
    }

    public double getEarnings() {
        return earnings;
    }

    public void setEarnings(double earnings) {
        this.earnings = earnings;
    }

    public double getTaxes() {
        return taxes;
    }

    public void setTaxes(double taxes) {
        this.taxes = taxes;
    }
}
