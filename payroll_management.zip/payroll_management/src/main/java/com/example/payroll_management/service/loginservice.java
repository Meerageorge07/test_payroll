package com.example.payroll_management.service;

import com.example.payroll_management.dto.employeesdto;


public interface loginservice {
    String login(employeesdto employeesdto);
}
