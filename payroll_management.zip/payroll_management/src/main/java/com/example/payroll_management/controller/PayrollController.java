package com.example.payroll_management.controller;

import com.example.payroll_management.dto.payrunDto;
import com.example.payroll_management.entity.payrun;
import com.example.payroll_management.exception.ResourceNotFoundException;
import com.example.payroll_management.repository.PayrunRepository;
import com.example.payroll_management.serviceImpl.PayrollService;
import com.example.payroll_management.serviceImpl.payrunService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
@CrossOrigin
@RestController
@RequestMapping("/api/payroll")
public class PayrollController {

  @Autowired
  private PayrollService payrollService;
  @Autowired
  private PayrunRepository payrunRepository;

  @Autowired
  private payrunService payrunService;

//    @PostMapping("/calculate-net-pay")
//    public void calculateAndSaveNetPay() {
//        payrollService.calculateAndSaveNetPay();
//    }

    @PostMapping("/calculate-net-pay")
    public void calculateAndSaveNetPay() {
        payrollService.calculateAndSaveNetPay();
    }

    @PostMapping("/manual-calculate-net-pay")
    public void manualCalculateAndSaveNetPay() {
        payrollService.calculateAndSaveNetPay();
    }
    @GetMapping("/latest")
    public ResponseEntity<payrun> getLatestPayrun() {
        // Assuming there's a method in the repository to find the latest payrun
        payrun latestPayrun = payrunRepository.findTopByOrderByPaymentDateDesc();
        return ResponseEntity.ok(latestPayrun);
    }

@PostMapping("/manual-save-current-month-net-pay")
public void manualSaveCurrentMonthNetPayInAdvance() {
    payrollService.saveCurrentMonthNetPayInAdvance();
}
    @PostMapping("/mark-payrun-as-paid/{payrunId}")
    public void markPayrunAsPaid(@PathVariable Long payrunId) {
        payrollService.markPayrunAsPaid(payrunId);
    }

    @PutMapping("/{id}")
    public ResponseEntity<payrun> updatePaymentDate(@PathVariable Long id, @RequestBody payrun payrunDetails) {
        payrun payrun = payrunRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payrun not found with id " + id));

        payrun.setPaymentDate(payrunDetails.getPaymentDate());
        payrun updatedPayrun = payrunRepository.save(payrun);
        return ResponseEntity.ok(updatedPayrun);
    }

    @GetMapping
    public List<payrun> getAllPayruns() {
        return payrunService.getAllPayruns();
    }

    @GetMapping("/{id}")
    public payrun getPayrunById(@PathVariable Long id) {
        return payrunService.getPayrunById(id);
    }
    }


