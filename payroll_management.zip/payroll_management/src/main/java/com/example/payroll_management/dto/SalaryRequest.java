package com.example.payroll_management.dto;

import com.example.payroll_management.entity.PayheadAmount;
import com.example.payroll_management.entity.Salary;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;

public class SalaryRequest {

    private String empCode;
   private double taxes;
    private double earnings;
    private double deductions;

    public SalaryRequest() {
    }

    public String getEmpCode() {
        return empCode;
    }

    public void setEmpCode(String empCode) {
        this.empCode = empCode;
    }

    public double getTaxes() {
        return taxes;
    }

    public void setTaxes(double taxes) {
        this.taxes = taxes;
    }

    public double getEarnings() {
        return earnings;
    }

    public void setEarnings(double earnings) {
        this.earnings = earnings;
    }

    public double getDeductions() {
        return deductions;
    }

    public void setDeductions(double deductions) {
        this.deductions = deductions;
    }


    public SalaryRequest(String empCode, double taxes, double earnings, double deductions) {
        this.empCode = empCode;
        this.taxes = taxes;
        this.earnings = earnings;
        this.deductions = deductions;
    }


}
