package com.example.payroll_management.service;

import com.example.payroll_management.entity.payheads;

import java.util.List;

public interface listPayheads {
    List<payheads> getAllPayHeads();
}
