package com.example.payroll_management.entity;

import jakarta.persistence.*;
import com.example.payroll_management.enums.payStatus;

import java.time.LocalDate;


@Entity
@Table
public class payrun {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    private  double employeesNetPay;
    private LocalDate paymentDate;
    @Enumerated(EnumType.STRING)
    private payStatus payStatus;
    private LocalDate paymentStartDate;
    public Long paidDays;
    private  double payableAmount;

    public payrun(Long id, double employeesNetPay, LocalDate paymentDate, com.example.payroll_management.enums.payStatus payStatus, LocalDate paymentStartDate, Long paidDays, double payableAmount) {
        this.id = id;
        this.employeesNetPay = employeesNetPay;
        this.paymentDate = paymentDate;
        this.payStatus = payStatus;
        this.paymentStartDate = paymentStartDate;
        this.paidDays = paidDays;
        this.payableAmount = payableAmount;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public double getEmployeesNetPay() {
        return employeesNetPay;
    }

    public void setEmployeesNetPay(double employeesNetPay) {
        this.employeesNetPay = employeesNetPay;
    }

    public LocalDate getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(LocalDate paymentDate) {
        this.paymentDate = paymentDate;
    }

    public com.example.payroll_management.enums.payStatus getPayStatus() {
        return payStatus;
    }

    public void setPayStatus(com.example.payroll_management.enums.payStatus payStatus) {
        this.payStatus = payStatus;
    }

    public LocalDate getPaymentStartDate() {
        return paymentStartDate;
    }

    public void setPaymentStartDate(LocalDate paymentStartDate) {
        this.paymentStartDate = paymentStartDate;
    }

    public Long getPaidDays() {
        return paidDays;
    }

    public void setPaidDays(Long paidDays) {
        this.paidDays = paidDays;
    }

    public double getPayableAmount() {
        return payableAmount;
    }

    public void setPayableAmount(double payableAmount) {
        this.payableAmount = payableAmount;
    }

    public payrun() {
    }
}
