package com.example.payroll_management.controller;

import com.example.payroll_management.entity.payheads;
import com.example.payroll_management.serviceImpl.payHeadService;
import com.example.payroll_management.repository.payheadsRepo;
import com.example.payroll_management.service.listPayheads;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/payhead")
public class payheadListController {

    @Autowired
    private  listPayheads listPayheads;

    @Autowired
    private  payheadsRepo payheadsRepo;

    @Autowired
    private  payHeadService payHeadService;


    @GetMapping("/list")
    public List<payheads> getAllUsers() {
        return listPayheads.getAllPayHeads();

    }
    @GetMapping("/earnings")
    public List<payheads> getEarnings() {
        return payHeadService.getEarnings();
    }

    @GetMapping("/deductions")
    public List<payheads> getDeductions() {
        return payHeadService.getDeductions();
    }

//    @PostMapping("/calculate")
//    public ResponseEntity<Void> calculateEarningsAndDeductions(@RequestBody String empCode) {
//        payHeadService.calculateAndUpdateEarningsAndDeductions(empCode);
//        return ResponseEntity.ok().build();
//    }


    @GetMapping("/payheads")
    public ResponseEntity<List<payheads>> getEarningsAndDeductions(@RequestParam String empCode) {
        List<payheads> payheads = payHeadService.getEarningsAndDeductions(empCode);
        return ResponseEntity.ok(payheads);
    }

    @PostMapping("/update")
    public ResponseEntity<Void> updateEarningsAndDeductions(@RequestParam String empCode,
                                                            @RequestBody Map<String, Map<String, Double>> request) {
        Map<String, Double> earningsMap = request.get("earnings");
        Map<String, Double> deductionsMap = request.get("deductions");
        payHeadService.updateEarningsAndDeductions(empCode, earningsMap, deductionsMap);
        return ResponseEntity.ok().build();
    }
}
