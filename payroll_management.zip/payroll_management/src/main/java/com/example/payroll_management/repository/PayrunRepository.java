package com.example.payroll_management.repository;

import com.example.payroll_management.entity.employees;
import com.example.payroll_management.entity.payrun;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface PayrunRepository extends JpaRepository<payrun, Long> {
    payrun findTopByOrderByPaymentDateDesc();

 //   <T> Optional<T> findTopByEmployeeOrderByPaymentDateDesc(employees employee);
//
//    <T> Optional<T> findTopByEmployeeIdOrderByPaymentDateDesc(Long employeeId);
//
//    <T> Optional<T> findTopByEmployeeOrderByPaymentDateDesc(employees employee);
}
