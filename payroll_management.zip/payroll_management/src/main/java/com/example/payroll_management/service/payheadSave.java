package com.example.payroll_management.service;

import com.example.payroll_management.entity.payheads;

public interface payheadSave {
    public payheads savePayHead(payheads payheads);
}
