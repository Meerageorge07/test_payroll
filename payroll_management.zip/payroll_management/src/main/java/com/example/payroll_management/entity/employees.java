package com.example.payroll_management.entity;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table
public class employees {




    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
 @Column(name = "Id")
    private Long Id;
    private String  empCode;

    private String Name;

    @Column(name = "Date of Joining")
    private LocalDate DateOfJoining;
    @Column(name = "Position")
    private String position;

    private String accountNumber;
    @Column(name = "Password")
    private String password;

    @Column(name = "Role")
    private String role;

    @Column(name = "Email")
    private String email;

    private double grossSalary;
     private  double AnnualCTC;
     private  double monthlySalary;

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getEmpCode() {
        return empCode;
    }

    public void setEmpCode(String empCode) {
        this.empCode = empCode;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public LocalDate getDateOfJoining() {
        return DateOfJoining;
    }

    public void setDateOfJoining(LocalDate dateOfJoining) {
        DateOfJoining = dateOfJoining;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public double getGrossSalary() {
        return grossSalary;
    }

    public void setGrossSalary(double grossSalary) {
        this.grossSalary = grossSalary;
    }

    public double getAnnualCTC() {
        return AnnualCTC;
    }

    public void setAnnualCTC(double annualCTC) {
        AnnualCTC = annualCTC;
    }

    public double getMonthlySalary() {
        return monthlySalary;
    }

    public void setMonthlySalary(double monthlySalary) {
        this.monthlySalary = monthlySalary;
    }

    public employees() {
    }

    public employees(Long id, String empCode, String name, LocalDate dateOfJoining, String position, String accountNumber, String password, String role, String email, double grossSalary, double annualCTC, double monthlySalary) {
        Id = id;
        this.empCode = empCode;
        Name = name;
        DateOfJoining = dateOfJoining;
        this.position = position;
        this.accountNumber = accountNumber;
        this.password = password;
        this.role = role;
        this.email = email;
        this.grossSalary = grossSalary;
        AnnualCTC = annualCTC;
        this.monthlySalary = monthlySalary;
    }
}