package com.example.payroll_management.serviceImpl;


import com.example.payroll_management.dto.employeesdto;
import com.example.payroll_management.entity.employees;
import com.example.payroll_management.repository.usersRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmployeeService {

    @Autowired
    private usersRepo employeeRepository;

    public List<employeesdto> getAllEmployees() {
        List<employees> employees = employeeRepository.findAll();
        return employees.stream().map(this::convertToDTO).collect(Collectors.toList());
    }

    public employeesdto getEmployeeByEmpCode(String empCode) {
        employees employee = employeeRepository.findByEmpCode(empCode);
        return convertToDTO(employee);
    }

    private employeesdto convertToDTO(employees employee) {
        employeesdto dto = new employeesdto();

        dto.setName(employee.getName());
        return dto;
    }
}

