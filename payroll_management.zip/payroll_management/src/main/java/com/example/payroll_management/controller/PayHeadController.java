package com.example.payroll_management.controller;

import com.example.payroll_management.entity.payheads;
import com.example.payroll_management.serviceImpl.listPayheadsImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin
@RestController
@RequestMapping("/api/payheads")
public class PayHeadController {
    @Autowired
    private listPayheadsImpl listPayheadsImpl;

    @GetMapping
    public List<payheads> getAllPayHeads() {
        return listPayheadsImpl.getAllPayHeads();
    }

    @PostMapping
    public payheads createPayHead(@RequestBody payheads payheads) {
        return listPayheadsImpl.savePayHead(payheads);
    }
}

