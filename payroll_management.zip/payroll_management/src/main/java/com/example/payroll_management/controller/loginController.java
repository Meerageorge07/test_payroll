package com.example.payroll_management.controller;
import com.example.payroll_management.dto.employeesdto;

import com.example.payroll_management.service.loginservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("login")
public class loginController {

    @Autowired
    private loginservice loginservice;

    @PostMapping("/role")
    public String login(@RequestBody employeesdto employeesdto) {
        return loginservice.login(employeesdto);
    }
}
