package com.example.payroll_management.repository;

import com.example.payroll_management.entity.payheads;
import com.example.payroll_management.enums.paytype;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface payheadsRepo extends  JpaRepository<payheads,Long> {
    List<payheads> findByPaytype(paytype paytype);
   //  payheads findById(payId payId);
}




