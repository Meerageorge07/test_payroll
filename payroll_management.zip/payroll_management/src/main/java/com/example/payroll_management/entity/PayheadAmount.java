package com.example.payroll_management.entity;

import jakarta.persistence.*;

@Entity
public class PayheadAmount {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "pay_id", referencedColumnName = "pay_id")
    private payheads payheads;

    public Salary getSalary() {
        return salary;
    }

    public void setSalary(Salary salary) {
        this.salary = salary;
    }

    @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "empCode", referencedColumnName = "empCode")
    private Salary salary;



    private double amount;

    public PayheadAmount() {
    }

    public PayheadAmount(Long id, com.example.payroll_management.entity.payheads payheads, double amount) {
        this.id = id;
        this.payheads = payheads;
        this.amount = amount;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public com.example.payroll_management.entity.payheads getPayheads() {
        return payheads;
    }

    public void setPayheads(com.example.payroll_management.entity.payheads payheads) {
        this.payheads = payheads;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
}