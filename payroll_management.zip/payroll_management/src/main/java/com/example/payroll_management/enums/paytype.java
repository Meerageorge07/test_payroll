package com.example.payroll_management.enums;

public enum paytype {

    Earnings,
    Deductions
}
