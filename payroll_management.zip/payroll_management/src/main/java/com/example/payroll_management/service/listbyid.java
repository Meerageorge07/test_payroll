package com.example.payroll_management.service;

import com.example.payroll_management.entity.employees;

public interface listbyid {
    employees getUserById(Long id);
}
