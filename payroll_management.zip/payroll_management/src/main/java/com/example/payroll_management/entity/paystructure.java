package com.example.payroll_management.entity;


import jakarta.persistence.*;
@Entity
@Table
public class paystructure {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long salary_id;




    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "pay_id",referencedColumnName = "pay_id" )
    private payheads payheads;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "empCode",referencedColumnName = "empCode" )
    private  employees employees;

    private String Salary;
    public paystructure() {
    }

    public paystructure(Long salary_id, com.example.payroll_management.entity.payheads payheads, com.example.payroll_management.entity.employees employees, String salary) {
        this.salary_id = salary_id;
        this.payheads = payheads;
        this.employees = employees;
        Salary = salary;
    }

    public Long getSalary_id() {
        return salary_id;
    }

    public void setSalary_id(Long salary_id) {
        this.salary_id = salary_id;
    }

    public com.example.payroll_management.entity.payheads getPayheads() {
        return payheads;
    }

    public void setPayheads(com.example.payroll_management.entity.payheads payheads) {
        this.payheads = payheads;
    }

    public com.example.payroll_management.entity.employees getEmployees() {
        return employees;
    }

    public void setEmployees(com.example.payroll_management.entity.employees employees) {
        this.employees = employees;
    }

    public String getSalary() {
        return Salary;
    }

    public void setSalary(String salary) {
        Salary = salary;
    }
}
