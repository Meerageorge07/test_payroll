package com.example.payroll_management.config;

import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.YearMonth;

@Component
public class PayrollConfig {
    private LocalDate paymentDate = YearMonth.now().atEndOfMonth();

    public LocalDate getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(LocalDate paymentDate) {
        this.paymentDate = paymentDate;
    }

    public void resetToEndOfMonth() {
        this.paymentDate = YearMonth.now().atEndOfMonth();
    }
}

