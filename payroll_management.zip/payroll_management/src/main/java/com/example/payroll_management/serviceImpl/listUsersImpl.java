package com.example.payroll_management.serviceImpl;

import com.example.payroll_management.repository.usersRepo;
import com.example.payroll_management.entity.employees;
import com.example.payroll_management.service.listUsers;
import com.example.payroll_management.service.listbyid;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Transactional
public class listUsersImpl implements listUsers, listbyid {

    @Autowired
    private  usersRepo usersRepo;

    @Override
    public List<employees> getAllUsers() {
        return usersRepo.findAll();
    }

    @Override
    public employees getUserById(Long id) {
        return  usersRepo.findById(id).orElse(null);
    }

}
