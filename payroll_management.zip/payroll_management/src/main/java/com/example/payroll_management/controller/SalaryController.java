package com.example.payroll_management.controller;

import com.example.payroll_management.dto.SalaryDto;
import com.example.payroll_management.dto.SalaryRequest;
import com.example.payroll_management.entity.payrun;
import com.example.payroll_management.repository.usersRepo;
import com.example.payroll_management.entity.Salary;
import com.example.payroll_management.entity.employees;
import com.example.payroll_management.entity.SalaryComponents;
import com.example.payroll_management.service.EmployeeService;
import com.example.payroll_management.serviceImpl.SalaryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.logging.Logger;

@CrossOrigin
@RestController
@RequestMapping("/api/salary")
public class SalaryController {
    private static final Logger logger = Logger.getLogger(SalaryController.class.getName());

    @Autowired
    private SalaryService salaryService;

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private usersRepo usersRepo;





    @Autowired
    public SalaryController(SalaryService salaryService) {
        this.salaryService = salaryService;
    }

    public SalaryController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    @GetMapping("/employees/{id}")
    public SalaryComponents getGrossSalary(@PathVariable Long id) {
        return salaryService.calculateGrossSalary(id);
    }

    @GetMapping("/get")
    public List<SalaryDto> getAllSalaries() {
        return salaryService.getAllSalaries();
    }

    @ExceptionHandler(RuntimeException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public String handleRuntimeException(RuntimeException ex) {
        return ex.getMessage();
    }


    @PostMapping("/calculate")
    public ResponseEntity<Salary> calculateSalary(@RequestBody SalaryRequest request) {
        try {
            Salary salary = salaryService.calculateSalary(
                    request.getEmpCode(),
                    request.getTaxes(),
                    request.getEarnings(),
                    request.getDeductions()
            );
            return ResponseEntity.ok(salary);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(null);
        }
    }

//    @GetMapping("/employees/{empCode}/monthly-net-salary")
//    public double getMonthlyNetSalary(@PathVariable String empCode) {
//        // Assuming salaryService has a method to fetch employee by empCode and calculate net salary
//        employees employee = usersRepo.findByEmpCode(empCode);
//
//        return salaryService.getMonthlyNetSalary(employee);
//    }
@GetMapping("/net/{empCode}")
public ResponseEntity<Double> getMonthlyNetSalary1(@PathVariable String empCode) {
    try {
        double monthlyNetSalary = salaryService.getMonthlyNetSalary(empCode);
        return new ResponseEntity<>(monthlyNetSalary, HttpStatus.OK);
    } catch (IllegalArgumentException e) {
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    } catch (Exception e) {
        return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    }
}


//    @GetMapping("/totalNetSalary")
//    public Double getTotalNetSalary(@RequestParam String salaryMonth) {
//        return salaryService.getTotalNetSalaryForMonth(salaryMonth);
//    }


    @GetMapping("/totalMonthlySalary")
    public double getTotalMonthlySalary() {
        return employeeService.calculateTotalMonthlySalary();
    }



    @GetMapping("/{id}")
    public ResponseEntity<Salary> getSalaryById(@PathVariable Long id) {
        return salaryService.getSalaryById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

//updating salary

    @PutMapping("/{id}")
    public ResponseEntity<Salary> updateSalary(@PathVariable Long id, @RequestBody SalaryDto salaryDto) {
        Salary updatedSalary = salaryService.updateSalary(id, salaryDto);
        return ResponseEntity.ok(updatedSalary);
    }

//    @PutMapping("/{id}")
//    public Salary updateSalary(@PathVariable Long id, @RequestBody SalaryUpdateRequest request) {
//        return salaryService.updateSalary(id, request.getSalaryDetails(), request.getPayRunDetails());
//    }
//

    @PutMapping("/calculate/{empCode}")
    public ResponseEntity<Salary> calculateSalary(@PathVariable String empCode, @RequestBody SalaryRequest request) {
        try {
            request.setEmpCode(empCode); // Set empCode from path variable into request object
            Salary calculatedSalary = salaryService.calculateSalary(request);
            return ResponseEntity.ok(calculatedSalary);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null); // Return a 400 Bad Request on error
        }}


        @PostMapping("/create")
        public ResponseEntity<String> createPayrun(@RequestBody SalaryDto salaryDto) {
            try {
                salaryService.savePayrunFromSalaryDto(salaryDto);
                return ResponseEntity.ok("Payrun saved successfully.");
            } catch (Exception e) {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to save payrun: " + e.getMessage());
            }
        }

    }
