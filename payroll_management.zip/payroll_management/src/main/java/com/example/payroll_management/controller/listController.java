package com.example.payroll_management.controller;
import com.example.payroll_management.entity.employees;
import com.example.payroll_management.repository.usersRepo;
import com.example.payroll_management.service.listUsers;
import com.example.payroll_management.service.listbyid;
import com.example.payroll_management.serviceImpl.listUsersImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin
@RestController
@RequestMapping("/api")
public class listController {


    @Autowired
    private  listUsers listUsers;
    @Autowired
    private listbyid listbyid;
    @Autowired
    private usersRepo usersRepo;

    public listController(com.example.payroll_management.repository.usersRepo usersRepo) {
        this.usersRepo = usersRepo;
    }

    @GetMapping("/list")
    public List<employees> getAllUsers() {
        return listUsers.getAllUsers();
    }

    @GetMapping("/{id}")
    public employees getUserById(@PathVariable Long id) {
        return listbyid.getUserById(id);
    }

    @GetMapping("/employees/count")
    public long countEmployees() {
        return usersRepo.count();
    }
}
