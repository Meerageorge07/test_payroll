package com.example.payroll_management.serviceImpl;

import com.example.payroll_management.entity.employees;
import com.example.payroll_management.entity.payrun;
import com.example.payroll_management.enums.payStatus;
import com.example.payroll_management.repository.usersRepo;
import com.example.payroll_management.repository.PayrunRepository;
import com.example.payroll_management.utils.DateUtils;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Transactional
@Service
public class PayrollService {

    @Autowired
    private usersRepo employeesRepository;

    @Autowired
    private PayrunRepository payrunRepository;


@Scheduled(cron = "0 0 0 28-31 * ?")
public void calculateAndSaveNetPay() {
    LocalDate today = LocalDate.now();
    YearMonth yearMonth = YearMonth.from(today);
    LocalDate lastDayOfMonth = yearMonth.atEndOfMonth();

    if (today.equals(DateUtils.getLastWorkingDayOfMonth(lastDayOfMonth))) {
        // Calculate the sum of monthly salaries of all employees
        List<employees> employeesList = employeesRepository.findAll();
        double totalNetPay = employeesList.stream().mapToDouble(employees::getMonthlySalary).sum();

        // Set the start and end dates of the payment
        LocalDate paymentStartDate = yearMonth.atDay(1);
        LocalDate paymentDate = DateUtils.getLastWorkingDayOfMonth(lastDayOfMonth);

        // Calculate the number of paid days
        long paidDays = ChronoUnit.DAYS.between(paymentStartDate, paymentDate) + 1;

        // Save the result to the payrun table
        payrun payrunEntry = new payrun();
        payrunEntry.setEmployeesNetPay(totalNetPay);
        payrunEntry.setPaymentDate(paymentDate);
        payrunEntry.setPaymentStartDate(paymentStartDate);
        payrunEntry.setPayStatus(payStatus.unpaid);
        payrunEntry.setPaidDays(paidDays);

        payrunRepository.save(payrunEntry);
    }
}


    @Scheduled(cron = "0 0 0 1 * ?")
    public void saveCurrentMonthNetPayInAdvance() {
        LocalDate today = LocalDate.now();
        YearMonth yearMonth = YearMonth.from(today);
        LocalDate firstDayOfMonth = yearMonth.atDay(1); // First day of the month
        LocalDate lastDayOfMonth = yearMonth.atEndOfMonth();
        LocalDate lastWorkingDay = DateUtils.getLastWorkingDayOfMonth(lastDayOfMonth);

        // Calculate the sum of monthly salaries of all employees
        List<employees> employeesList = employeesRepository.findAll();
        double totalNetPay = employeesList.stream().mapToDouble(employees::getMonthlySalary).sum();

        // Calculate the number of paid days
       long paidDays = ChronoUnit.DAYS.between(firstDayOfMonth, lastWorkingDay) + 1;

        // Save the result to the payrun table
        payrun payrunEntry = new payrun();
        payrunEntry.setEmployeesNetPay(totalNetPay);
        payrunEntry.setPaymentDate(lastWorkingDay);
        payrunEntry.setPaymentStartDate(firstDayOfMonth); // Set payment start date to the first day of the month
        payrunEntry.setPayStatus(payStatus.unpaid);
        payrunEntry.setPaidDays(paidDays); // Set the number of paid days
        payrunRepository.save(payrunEntry);
    }

    public void markPayrunAsPaid(Long payrunId) {
        payrun payrunEntry = payrunRepository.findById(payrunId).orElseThrow(() -> new RuntimeException("Payrun not found"));
        payrunEntry.setPayStatus(payStatus.paid); // Set status to PAID
        payrunRepository.save(payrunEntry);
    }
//    public Long getPaidDaysForEmployee(employees employee) {
//        return payrunRepository.findTopByEmployeeOrderByPaymentDateDesc(employee)
//                .map(payrun::getPaidDays)
//                .orElse(0L);
//    }
}





