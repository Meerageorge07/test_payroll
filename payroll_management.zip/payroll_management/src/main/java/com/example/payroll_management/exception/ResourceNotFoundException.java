//package com.example.payroll_management.exception;
//
//public class ResourceNotFoundException {
//}
package com.example.payroll_management.exception;

public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) {
        super(message);
    }
}
