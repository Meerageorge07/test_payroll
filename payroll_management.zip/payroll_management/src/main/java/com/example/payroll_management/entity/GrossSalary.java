package com.example.payroll_management.entity;

import jakarta.persistence.CascadeType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

public class GrossSalary {

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "empCode", referencedColumnName = "empCode")
    private employees employees;

    private double basicSalary;
    private double grossSalary;
    private double houseRentAllowance;
    private double providentFund;
    private double leaveTravelAllowance;
    private double medicalAllowance;
    private double professionalTax;
    private double epf;
    private  double incomeTax;
    private double insurance;


    public com.example.payroll_management.entity.employees getEmployees() {
        return employees;
    }

    public void setEmployees(com.example.payroll_management.entity.employees employees) {
        this.employees = employees;
    }

    public double getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(double basicSalary) {
        this.basicSalary = basicSalary;
    }

    public double getGrossSalary() {
        return grossSalary;
    }

    public void setGrossSalary(double grossSalary) {
        this.grossSalary = grossSalary;
    }

    public double getHouseRentAllowance() {
        return houseRentAllowance;
    }

    public void setHouseRentAllowance(double houseRentAllowance) {
        this.houseRentAllowance = houseRentAllowance;
    }

    public double getProvidentFund() {
        return providentFund;
    }

    public void setProvidentFund(double providentFund) {
        this.providentFund = providentFund;
    }

    public double getLeaveTravelAllowance() {
        return leaveTravelAllowance;
    }

    public void setLeaveTravelAllowance(double leaveTravelAllowance) {
        this.leaveTravelAllowance = leaveTravelAllowance;
    }

    public double getMedicalAllowance() {
        return medicalAllowance;
    }

    public void setMedicalAllowance(double medicalAllowance) {
        this.medicalAllowance = medicalAllowance;
    }

    public double getProfessionalTax() {
        return professionalTax;
    }

    public void setProfessionalTax(double professionalTax) {
        this.professionalTax = professionalTax;
    }

    public double getEpf() {
        return epf;
    }

    public void setEpf(double epf) {
        this.epf = epf;
    }

    public double getIncomeTax() {
        return incomeTax;
    }

    public void setIncomeTax(double incomeTax) {
        this.incomeTax = incomeTax;
    }

    public double getInsurance() {
        return insurance;
    }

    public void setInsurance(double insurance) {
        this.insurance = insurance;
    }

    public GrossSalary(com.example.payroll_management.entity.employees employees, double basicSalary, double grossSalary, double houseRentAllowance, double providentFund, double leaveTravelAllowance, double medicalAllowance, double professionalTax, double epf, double incomeTax, double insurance) {
        this.employees = employees;
        this.basicSalary = basicSalary;
        this.grossSalary = grossSalary;
        this.houseRentAllowance = houseRentAllowance;
        this.providentFund = providentFund;
        this.leaveTravelAllowance = leaveTravelAllowance;
        this.medicalAllowance = medicalAllowance;
        this.professionalTax = professionalTax;
        this.epf = epf;
        this.incomeTax = incomeTax;
        this.insurance = insurance;
    }

    public GrossSalary() {
    }
}
