package com.example.payroll_management.repository;

import com.example.payroll_management.entity.employees;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface usersRepo extends JpaRepository<employees,Long> {

    employees findByEmail(String email);
    employees findByEmpCode(String empCode);

   // double findAnnualCtcByEmployeeId(String empCode);
   double findAnnualCtcByEmpCode(String empCode);

    //long countById(Long id);
}
