package com.example.payroll_management.dto;
 import com.example.payroll_management.enums.paytype;

public class payheadsDto {


    private Long pay_id;
    private String Name;
    private paytype paytype;

    public payheadsDto() {
    }

    public payheadsDto(Long pay_id, String name, com.example.payroll_management.enums.paytype paytype) {
        this.pay_id = pay_id;
        Name = name;
        this.paytype = paytype;
    }

    public Long getPay_id() {
        return pay_id;
    }

    public void setPay_id(Long pay_id) {
        this.pay_id = pay_id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public com.example.payroll_management.enums.paytype getPaytype() {
        return paytype;
    }

    public void setPaytype(com.example.payroll_management.enums.paytype paytype) {
        this.paytype = paytype;
    }
}
