package com.example.payroll_management.enums;

public enum payStatus {
    paid,
    unpaid
}
