package com.example.payroll_management.serviceImpl;

import com.example.payroll_management.entity.payheads;
import  com.example.payroll_management.repository.payheadsRepo;
import com.example.payroll_management.service.listPayheads;
import com.example.payroll_management.service.payheadSave;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
@Transactional
public class listPayheadsImpl implements listPayheads, payheadSave {

@Autowired
private  payheadsRepo payheadsRepo;


    @Override
    public List<payheads> getAllPayHeads() {
        return payheadsRepo.findAll();
    }

    @Override
    public payheads savePayHead(payheads payheads) {
        return payheadsRepo.save(payheads);
    }
}
