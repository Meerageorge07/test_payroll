package com.example.payroll_management.entity;

import com.example.payroll_management.enums.paytype;
import jakarta.persistence.*;



@Table(name = "Salary", uniqueConstraints = @UniqueConstraint(columnNames = {"empCode"}))
@Entity
public class Salary {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "salary_id", referencedColumnName = "salary_id")
    private paystructure paystructure;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "empCode", referencedColumnName = "empCode")
    private employees employees;



 private double Taxes = 200;
    private  double earnings;
    private String payheadname;
    private String salaryMonth;
    private double payAmount;
    private double earningsTotal;
    private double deductionsTotal;
    private double netSalary;
    private String payType;
 private double monthlySalary;

    public Salary() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public com.example.payroll_management.entity.paystructure getPaystructure() {
        return paystructure;
    }

    public void setPaystructure(com.example.payroll_management.entity.paystructure paystructure) {
        this.paystructure = paystructure;
    }

    public com.example.payroll_management.entity.employees getEmployees() {
        return employees;
    }

    public void setEmployees(com.example.payroll_management.entity.employees employees) {
        this.employees = employees;
    }

//    public long getPaidDays() {
//        return paidDays;
//    }
//
//    public void setPaidDays(long paidDays) {
//        this.paidDays = paidDays;
//    }

    public double getTaxes() {
        return Taxes;
    }

    public void setTaxes(double taxes) {
        Taxes = taxes;
    }

    public double getEarnings() {
        return earnings;
    }

    public void setEarnings(double earnings) {
        this.earnings = earnings;
    }

    public String getPayheadname() {
        return payheadname;
    }

    public void setPayheadname(String payheadname) {
        this.payheadname = payheadname;
    }

    public String getSalaryMonth() {
        return salaryMonth;
    }

    public void setSalaryMonth(String salaryMonth) {
        this.salaryMonth = salaryMonth;
    }

//

    public double getPayAmount() {
        return payAmount;
    }

    public void setPayAmount(double payAmount) {
        this.payAmount = payAmount;
    }

    public double getEarningsTotal() {
        return earningsTotal;
    }

    public void setEarningsTotal(double earningsTotal) {
        this.earningsTotal = earningsTotal;
    }

    public double getDeductionsTotal() {
        return deductionsTotal;
    }

    public void setDeductionsTotal(double deductionsTotal) {
        this.deductionsTotal = deductionsTotal;
    }

    public double getNetSalary() {
        return netSalary;
    }

    public void setNetSalary(double netSalary) {
        this.netSalary = netSalary;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public double getMonthlySalary() {
        return monthlySalary;
    }

    public void setMonthlySalary(double monthlySalary) {
        this.monthlySalary = monthlySalary;
    }

    public Salary(Long id, com.example.payroll_management.entity.paystructure paystructure, com.example.payroll_management.entity.employees employees, double taxes, double earnings, String payheadname, String salaryMonth, double payAmount, double earningsTotal, double deductionsTotal, double netSalary, String payType, double monthlySalary) {
        this.id = id;
        this.paystructure = paystructure;
        this.employees = employees;
        Taxes = taxes;
        this.earnings = earnings;
        this.payheadname = payheadname;
        this.salaryMonth = salaryMonth;
        this.payAmount = payAmount;
        this.earningsTotal = earningsTotal;
        this.deductionsTotal = deductionsTotal;
        this.netSalary = netSalary;
        this.payType = payType;
        this.monthlySalary = monthlySalary;
    }
}