package com.example.payroll_management.controller;

public class PayheadsController {
}
