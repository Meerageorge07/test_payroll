package com.example.payroll_management.repository;


import com.example.payroll_management.entity.PayheadAmount;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PayheadAmountRepository  extends JpaRepository<PayheadAmount,Long> {


}
