package com.example.payroll_management.repository;

import com.example.payroll_management.entity.GrossSalary;
import com.example.payroll_management.entity.SalaryComponents;
import org.springframework.data.jpa.repository.JpaRepository;

public interface grossRepo extends JpaRepository<SalaryComponents,Long> {
}
