package com.example.payroll_management.service;

import com.example.payroll_management.entity.employees;

import java.util.List;

public interface EmployeeService {
    List<employees> getAllEmployees();
    double calculateTotalMonthlySalary();
}

