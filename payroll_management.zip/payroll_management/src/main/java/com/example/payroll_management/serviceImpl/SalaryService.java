package com.example.payroll_management.serviceImpl;

import com.example.payroll_management.dto.SalaryDto;
import com.example.payroll_management.dto.SalaryRequest;
import com.example.payroll_management.entity.*;
import com.example.payroll_management.repository.*;
import com.example.payroll_management.service.EmployeeService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@Service
@Transactional
public class SalaryService implements EmployeeService {
    @Autowired
    private SalaryRepository salaryRepository;
    @Autowired
    private usersRepo usersRepo;
    @Autowired
    private grossRepo grossRepo;
    @Autowired
    private payheadsRepo payheadsRepo;
    @Autowired
    private PayrunRepository payrunRepository;
@Autowired
private  PayrollService payrollService;

    private List<employees> employees;

    public SalaryService(List<com.example.payroll_management.entity.employees> employees) {
        this.employees = employees;
    }

    public List<SalaryDto> getAllSalaries() {
        List<Salary> salaryList= salaryRepository.findAll();
        payrun payrun=payrunRepository.findTopByOrderByPaymentDateDesc();
        List<SalaryDto> responseList=new ArrayList<>();
        for (int i = 0; i < salaryList.size(); i++) {
            SalaryDto salaryDto=new SalaryDto();
            Salary salary=salaryList.get(i);
            salaryDto.setId(salary.getId());
            salaryDto.setEarnings(salary.getEarnings());
            salaryDto.setDeductionsTotal(salary.getDeductionsTotal());
            salaryDto.setEmployees(salary.getEmployees());
            salaryDto.setMonthlySalary(salary.getMonthlySalary());
            salaryDto.setNetSalary(salary.getNetSalary());
            salaryDto.setSalaryMonth(salary.getSalaryMonth());
            salaryDto.setTaxes(Double.parseDouble("200"));
            salaryDto.setPayType(salary.getPayType());
            if(payrun!=null){
                salaryDto.setPaidDays(payrun.getPaidDays());
            }
            responseList.add(salaryDto);

        }
        return responseList;
    }

public Salary calculateSalary(String empCode,double earnings, double deductions,double taxes) {
    employees employee = usersRepo.findByEmpCode(empCode);
    if (employee == null) {
        throw new IllegalArgumentException("Employee not found with empCode: " + empCode);
    }

    double basicSalary = employee.getMonthlySalary();
    double earningsTotal = basicSalary + earnings;
    double netSalary = earningsTotal - deductions-taxes;

    Salary existingSalary = salaryRepository.findByEmployees_EmpCode(empCode);

    if (existingSalary != null) {
        existingSalary.setEarningsTotal(earningsTotal);
        existingSalary.setDeductionsTotal(deductions);
        existingSalary.setTaxes(taxes);
        existingSalary.setNetSalary(netSalary);
        salaryRepository.save(existingSalary);
        return existingSalary;
    } else {
        Salary salary = new Salary();
        salary.setEmployees(employee);
        salary.setEarningsTotal(earningsTotal);
        salary.setDeductionsTotal(deductions);
        salary.setTaxes(taxes);
        salary.setNetSalary(netSalary);
        salaryRepository.save(salary);
        return salary;
    }
}


    public SalaryComponents calculateGrossSalary(Long employeeId) {
        // Fetch the annual CTC for the employee using employeeId
        employees employee = usersRepo.findById(employeeId)
                .orElseThrow(() -> new RuntimeException("Employee not found"));
        double annualCtc = employee.getAnnualCTC();

        return calculateSalaryComponents(employeeId, annualCtc);
    }

    private SalaryComponents calculateSalaryComponents(Long employeeId, double annualCTC) {
        // Constants (these values might vary based on the organization)
        double basicSalaryPercentage = 0.40;
        double hraPercentage = 0.20;
        double daPercentage = 0.10;
        double pfPercentage = 0.12;

        // Calculate components
        double basicSalary = annualCTC * basicSalaryPercentage;
        double hra = basicSalary * hraPercentage;
        double DA = basicSalary * daPercentage;
        double pf = basicSalary * pfPercentage;
        double lta = 10000; // Example fixed value
        double medicalAllowance = 15000; // Example fixed value
        double professionalTax = 2400; // Example fixed value
        double epf = pf; // EPF same as PF
        double incomeTax = calculateIncomeTax(annualCTC); // Example function
        double insurance = 5000; // Example fixed value

        // Calculate gross salary and net salary
        double grossSalary = basicSalary + hra + DA + lta + medicalAllowance;
        double totalDeductions = pf + professionalTax + epf + incomeTax + insurance;
        double netSalary = grossSalary - totalDeductions;

        // Create and return SalaryComponents object
        SalaryComponents components = new SalaryComponents();
        components.setEmployeeId(employeeId);
        components.setBasicSalary(basicSalary);
        components.setHra(hra);
        components.setDA(DA);
        components.setPf(pf);
        components.setLta(lta);
        components.setMedicalAllowance(medicalAllowance);
        components.setProfessionalTax(professionalTax);
        components.setGrossSalary(grossSalary);
        components.setEpf(epf);
        components.setIncomeTax(incomeTax);
        components.setInsurance(insurance);
        components.setNetSalary(netSalary);

        return components;
    }

    private double calculateIncomeTax(double annualCTC) {
        // Simplified tax calculation
        if (annualCTC <= 250000) return 0;
        if (annualCTC <= 500000) return 0.05 * (annualCTC - 250000);
        if (annualCTC <= 1000000) return 0.20 * (annualCTC - 500000) + 12500;
        return 0.30 * (annualCTC - 1000000) + 112500;
    }

//    public double getMonthlyNetSalary(employees employees) {
//        double annualCTC = employees.getAnnualCTC();
//        double monthlyNetSalary = annualCTC / 12;
//
//        long roundedMonthlyNetSalary = Math.round(monthlyNetSalary);
//        employees.setMonthlySalary(roundedMonthlyNetSalary);
//
//        usersRepo.save(employees);
//        Salary salary = new Salary();
//        salary.setEmployees(employees); // Ensure the method name matches your entity
//        salary.setMonthlySalary(roundedMonthlyNetSalary);
//        salaryRepository.save(salary); // Save the Salary entity
//
//        return roundedMonthlyNetSalary;
////        return employees.getMonthlySalary();
//    }

//   public double getMonthlyNetSalary(String empCode) {
//    // Find the employee by empCode
//    employees employee = usersRepo.findByEmpCode(empCode);
//
//    if (employee == null) {
//        throw new IllegalArgumentException("Employee with empCode " + empCode + " not found");
//    }
//
//    // Check if a salary record already exists for this employee
//    Salary existingSalary = salaryRepository.findByEmployees_EmpCode(empCode);
//
//    if (existingSalary != null) {
//        // If the salary record exists, return the existing monthly net salary
//        return existingSalary.getMonthlySalary();
//    } else {
//        // If the salary record does not exist, calculate the monthly net salary
//        double annualCTC = employee.getAnnualCTC();
//        double monthlyNetSalary = annualCTC / 12;
//        long roundedMonthlyNetSalary = Math.round(monthlyNetSalary);
//
//        // Update the employee's monthly salary
//        employee.setMonthlySalary(roundedMonthlyNetSalary);
//        usersRepo.save(employee);
//
//        // Create a new Salary record and save it
//        Salary salary = new Salary();
//       // salary.setEmployee(employee);
//        salary.setMonthlySalary(roundedMonthlyNetSalary);
//        salaryRepository.save(salary);
//
//        // Return the calculated monthly net salary
//        return roundedMonthlyNetSalary;
//    }
//}


    public Double getTotalNetSalaryForMonth(String salaryMonth) {
        List<Salary> salaries = salaryRepository.findBySalaryMonth(salaryMonth);
        return salaries.stream().mapToDouble(Salary::getNetSalary).sum();
    }

    @Override
    public List<employees> getAllEmployees() {
        return List.of();
    }

    public double calculateTotalMonthlySalary() {
        double total = 0;
        for (employees emp : employees) {
            total += emp.getMonthlySalary();
        }
        return total;
    }

    public Salary getSalaryDetailsById(Long id) {
        return salaryRepository.findById(id).orElse(null);
    }


    public Optional<Salary> getSalaryById(Long id) {
        return salaryRepository.findById(id);
    }

//    @Transactional
//    public Salary updateSalary(Long id, SalaryDto salaryDto) {
//
//        return salaryRepository.findById(id).map(salary -> {
//
//            salary.setTaxes(salaryDto.getTaxes());
//            salary.setEarnings(salaryDto.getEarnings());
//            salary.setEarningsTotal(salaryDto.getEarningsTotal());
//            salary.setPaidDays(salaryDto.getPaidDays());
//
//            return salaryRepository.save(salary);
//        }).orElseGet(() -> {
//            salaryDto.setId(id);
//            return salaryRepository.save(salaryDto);
//        });
//    }
//

    @Transactional
    public Salary updateSalary(Long id, SalaryDto salaryDto) {
        return salaryRepository.findById(id).map(salary -> {
            salary.setTaxes(salaryDto.getTaxes());
            salary.setEarnings(salaryDto.getEarnings());
            salary.setEarningsTotal(salaryDto.getEarningsTotal());
           // salary.setPaidDays(salaryDto.getPaidDays());
            return salaryRepository.save(salary);
        }).orElseGet(() -> {
            Salary newSalary = new Salary();
            newSalary.setId(id);
            newSalary.setTaxes(salaryDto.getTaxes());
            newSalary.setEarnings(salaryDto.getEarnings());
            newSalary.setEarningsTotal(salaryDto.getEarningsTotal());
           // newSalary.setPaidDays(salaryDto.getPaidDays());
            return salaryRepository.save(newSalary);
        });
    }
   ////// ///correct one but not saving employee code////////////


    @Transactional
    public Salary calculateSalary(SalaryRequest request) {
        String empCode = request.getEmpCode();
        employees employee = usersRepo.findByEmpCode(empCode);
        if (employee == null) {
            throw new IllegalArgumentException("Employee not found with empCode: " + empCode);
        }
        Salary existingSalary = salaryRepository.findByEmployees_EmpCode(empCode);
     double basicSalary=existingSalary.getMonthlySalary();
       // double basicSalary = employee.getMonthlySalary();
        double earnings= request.getEarnings();
        double earningsTotal = basicSalary + earnings;
        //double netSalary = earningsTotal - request.getDeductions() - request.getTaxes();
       // double netSalary = earningsTotal - request.getDeductions() - request.getTaxes();
        double netSalary = earningsTotal - request.getDeductions() - request.getTaxes();
       // Salary existingSalary = salaryRepository.findByEmployees_EmpCode(empCode);

        if (existingSalary != null) {
            existingSalary.setEarningsTotal(earningsTotal);
            existingSalary.setEarnings(earnings);
            existingSalary.setDeductionsTotal(request.getDeductions());
            existingSalary.setTaxes(request.getTaxes());
            existingSalary.setNetSalary(netSalary);
            salaryRepository.save(existingSalary);
            return existingSalary;
        } else {
            Salary salary = new Salary();
            salary.setEmployees(employee);
            salary.setEarnings(earnings);
            salary.setEarningsTotal(earningsTotal);
            salary.setDeductionsTotal(request.getDeductions());
            salary.setTaxes(request.getTaxes());
            salary.setNetSalary(netSalary);
            salaryRepository.save(salary);
            return salary;
        }
    }
//////////////////////////////////earlier i think so//////////////////////////
//    @Transactional
//    public Salary calculateSalary(SalaryRequest request) {
//        String empCode = request.getEmpCode();
//        employees employee = usersRepo.findByEmpCode(empCode);
//
//        if (employee == null) {
//            throw new IllegalArgumentException("Employee not found with empCode: " + empCode);
//        }
//
//        Salary existingSalary = salaryRepository.findByEmployees_EmpCode(empCode);
//        double basicSalary;
//
//        if (existingSalary != null) {
//            basicSalary = existingSalary.getMonthlySalary();
//        } else {
//            throw new IllegalArgumentException("Salary record not found for empCode: " + empCode);
//        }
//
//        double earnings = request.getEarnings();
//        double earningsTotal = basicSalary + earnings;
//        double netSalary = earningsTotal - request.getDeductions() - request.getTaxes();
//
//        if (existingSalary != null) {
//            existingSalary.setEarningsTotal(earningsTotal);
//            existingSalary.setEarnings(earnings);
//            existingSalary.setDeductionsTotal(request.getDeductions());
//            existingSalary.setTaxes(request.getTaxes());
//            existingSalary.setNetSalary(netSalary);
//            salaryRepository.save(existingSalary);
//            return existingSalary;
//        } else {
//            Salary salary = new Salary();
//            salary.setEmployees(employee);
//            salary.setEarnings(earnings);
//            salary.setEarningsTotal(earningsTotal);
//            salary.setDeductionsTotal(request.getDeductions());
//            salary.setTaxes(request.getTaxes());
//            salary.setNetSalary(netSalary);
//            salaryRepository.save(salary);
//            return salary;
//        }
//    }



    public void savePayrunFromSalaryDto(SalaryDto salaryDto) {
        double netSalary = salaryDto.getNetSalary(); // Assuming netSalary is already computed after deductions

        payrun payrun = new payrun();
      //  payrun.setSalaryDto(salaryDto);
        payrun.setPayableAmount(netSalary); // Directly set netSalary as payableAmount
//        payrun.setPaymentDate(paymentDate);
//        payrun.setPaymentStartDate(paymentStartDate);
//        payrun.setPaidDays(paidDays);

        payrunRepository.save(payrun); // Save the payrun entity to the database
    }

// now am i correcting to save empCode
public double getMonthlyNetSalary(String empCode) {
    // Find the employee by empCode
    employees employee = usersRepo.findByEmpCode(empCode);

    if (employee == null) {
        throw new IllegalArgumentException("Employee with empCode " + empCode + " not found");
    }

    // Check if a salary record already exists for this employee
    Salary existingSalary = salaryRepository.findByEmployees_EmpCode(empCode);

    if (existingSalary != null) {
        // If the salary record exists, return the existing monthly net salary
        return existingSalary.getMonthlySalary();
    } else {
        // If the salary record does not exist, calculate the monthly net salary
        double annualCTC = employee.getAnnualCTC();
        double monthlyNetSalary = annualCTC / 12;
        long roundedMonthlyNetSalary = Math.round(monthlyNetSalary);

        // Update the employee's monthly salary
        employee.setMonthlySalary(roundedMonthlyNetSalary);
        usersRepo.save(employee);

        // Create a new Salary record and save it
        Salary salary = new Salary();
        salary.setEmployees(employee); // Set the employee
        salary.setMonthlySalary(roundedMonthlyNetSalary);
        salaryRepository.save(salary);

        // Return the calculated monthly net salary
        return roundedMonthlyNetSalary;
    }
}


}








