package com.example.payroll_management.serviceImpl;
import com.example.payroll_management.entity.payrun;
import com.example.payroll_management.repository.PayrunRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class payrunService {

    @Autowired
    private PayrunRepository payrunRepository;

    public List<payrun> getAllPayruns() {
        return payrunRepository.findAll();
    }

    public payrun getPayrunById(Long id) {
        return payrunRepository.findById(id).orElse(null);
    }

}



