package com.example.payroll_management.repository;

import com.example.payroll_management.entity.Salary;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.YearMonth;
import java.util.List;



public interface SalaryRepository extends JpaRepository<Salary, Long> {
    Salary findByEmployees_EmpCodeAndSalaryMonth(String empCode, String salaryMonth);
    List<Salary> findBySalaryMonth(String salaryMonth);

    Salary findByEmployees_EmpCode(String empCode);
    List<Salary> findByEmployeesEmpCode(String empCode);
//    List<Salary> findByEmployeeId(Long id);
}

