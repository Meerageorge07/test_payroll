package com.example.payroll_management.entity;

import jakarta.persistence.*;

@Entity
@Table
public class SalaryComponents {
    @jakarta.persistence.Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private Long Id;
   private  Long  employeeId;
    private   double basicSalary;
    private  double hra;
    private  double DA;
    private  double pf;
    private  double lta;
    private  double medicalAllowance;
    private  double professionalTax;
    private  double grossSalary;
    private double epf;
    private  double incomeTax;
    private double insurance;
    private double netSalary;

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public Long getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Long employeeId) {
        this.employeeId = employeeId;
    }

    public double getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(double basicSalary) {
        this.basicSalary = basicSalary;
    }

    public double getHra() {
        return hra;
    }

    public void setHra(double hra) {
        this.hra = hra;
    }

    public double getDA() {
        return DA;
    }

    public void setDA(double DA) {
        this.DA = DA;
    }

    public double getPf() {
        return pf;
    }

    public void setPf(double pf) {
        this.pf = pf;
    }

    public double getLta() {
        return lta;
    }

    public void setLta(double lta) {
        this.lta = lta;
    }

    public double getMedicalAllowance() {
        return medicalAllowance;
    }

    public void setMedicalAllowance(double medicalAllowance) {
        this.medicalAllowance = medicalAllowance;
    }

    public double getProfessionalTax() {
        return professionalTax;
    }

    public void setProfessionalTax(double professionalTax) {
        this.professionalTax = professionalTax;
    }

    public double getGrossSalary() {
        return grossSalary;
    }

    public void setGrossSalary(double grossSalary) {
        this.grossSalary = grossSalary;
    }

    public double getEpf() {
        return epf;
    }

    public void setEpf(double epf) {
        this.epf = epf;
    }

    public double getIncomeTax() {
        return incomeTax;
    }

    public void setIncomeTax(double incomeTax) {
        this.incomeTax = incomeTax;
    }

    public double getInsurance() {
        return insurance;
    }

    public void setInsurance(double insurance) {
        this.insurance = insurance;
    }

    public double getNetSalary() {
        return netSalary;
    }

    public void setNetSalary(double netSalary) {
        this.netSalary = netSalary;
    }

    public SalaryComponents() {
    }

    public SalaryComponents(Long id, Long employeeId, double basicSalary, double hra, double DA, double pf, double lta, double medicalAllowance, double professionalTax, double grossSalary, double epf, double incomeTax, double insurance, double netSalary) {
        Id = id;
        this.employeeId = employeeId;
        this.basicSalary = basicSalary;
        this.hra = hra;
        this.DA = DA;
        this.pf = pf;
        this.lta = lta;
        this.medicalAllowance = medicalAllowance;
        this.professionalTax = professionalTax;
        this.grossSalary = grossSalary;
        this.epf = epf;
        this.incomeTax = incomeTax;
        this.insurance = insurance;
        this.netSalary = netSalary;
    }
}
