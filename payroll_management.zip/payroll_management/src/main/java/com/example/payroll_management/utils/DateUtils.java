package com.example.payroll_management.utils;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.YearMonth;

public class DateUtils {

    public static LocalDate getLastWorkingDayOfMonth(LocalDate date) {
        YearMonth yearMonth = YearMonth.from(date);
        LocalDate lastDay = yearMonth.atEndOfMonth();

        while (lastDay.getDayOfWeek() == DayOfWeek.SATURDAY || lastDay.getDayOfWeek() == DayOfWeek.SUNDAY) {
            lastDay = lastDay.minusDays(1);
        }

        return lastDay;
    }
}

