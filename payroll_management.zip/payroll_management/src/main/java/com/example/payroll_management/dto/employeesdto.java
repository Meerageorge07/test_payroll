package com.example.payroll_management.dto;

import java.time.LocalDate;

public class employeesdto {
    private  String name;
    private  String password;
    private  String role;
    private  String Email;
    private LocalDate DateOfJoining;
    private  String position;
    private String accountNumber;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public LocalDate getDateOfJoining() {
        return DateOfJoining;
    }

    public void setDateOfJoining(LocalDate dateOfJoining) {
        DateOfJoining = dateOfJoining;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public employeesdto() {
    }

    public employeesdto(String name, String password, String role, String email, LocalDate dateOfJoining, String position, String accountNumber) {
        this.name = name;
        this.password = password;
        this.role = role;
        Email = email;
        DateOfJoining = dateOfJoining;
        this.position = position;
        this.accountNumber = accountNumber;
    }
}
