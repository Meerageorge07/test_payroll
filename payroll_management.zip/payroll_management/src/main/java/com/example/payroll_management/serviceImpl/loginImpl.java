package com.example.payroll_management.serviceImpl;

import com.example.payroll_management.dto.employeesdto;
import com.example.payroll_management.entity.employees;
import com.example.payroll_management.repository.usersRepo;
import com.example.payroll_management.service.loginservice;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
@Transactional
public class loginImpl implements loginservice {

@Autowired
private  usersRepo usersRepo;


    @Override
    public String login(employeesdto employeesdto) {


        employees userExist = usersRepo.findByEmail(employeesdto.getEmail());

        if (userExist != null) {
            if (userExist.getPassword().equals(employeesdto.getPassword())) {
                String role = userExist.getRole();

                if ("1".equals(role)) {

                    return "user is admin";
                } else if ("2".equals(role)) {

                    return "user is an employee";
                }
            }
        }

        return "invalid";
    }
    }


