package com.example.payroll_management.entity;

import com.example.payroll_management.enums.paytype;
import jakarta.persistence.*;


@Entity
@Table
public class payheads {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long pay_id;
    private String Name;

    @Enumerated(EnumType.STRING)
    private paytype paytype;

    public Long getPay_id() {
        return pay_id;
    }

    public void setPay_id(Long pay_id) {
        this.pay_id = pay_id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public com.example.payroll_management.enums.paytype getPaytype() {
        return paytype;
    }

    public void setPaytype(com.example.payroll_management.enums.paytype paytype) {
        this.paytype = paytype;
    }

    public payheads() {
    }

    public payheads(Long pay_id, String name, com.example.payroll_management.enums.paytype paytype) {
        this.pay_id = pay_id;
        Name = name;
        this.paytype = paytype;
    }
}
