package com.example.payroll_management.dto;

import com.example.payroll_management.entity.employees;
import com.example.payroll_management.entity.paystructure;
import jakarta.persistence.*;

public class SalaryDto {

    private Long id;
    private paystructure paystructure;
    private employees employees;
    private double Taxes;
    private  double earnings;
    private String payheadname;
    private String salaryMonth;
    private String payAmount;
    private double earningsTotal;
    private double deductionsTotal;
    private double netSalary;
    private String payType;
    private double monthlySalary;
    private long paidDays;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public com.example.payroll_management.entity.paystructure getPaystructure() {
        return paystructure;
    }

    public void setPaystructure(com.example.payroll_management.entity.paystructure paystructure) {
        this.paystructure = paystructure;
    }

    public com.example.payroll_management.entity.employees getEmployees() {
        return employees;
    }

    public void setEmployees(com.example.payroll_management.entity.employees employees) {
        this.employees = employees;
    }

    public double getTaxes() {
        return Taxes;
    }

    public void setTaxes(double taxes) {
        Taxes = 200;
    }

    public double getEarnings() {
        return earnings;
    }

    public void setEarnings(double earnings) {
        this.earnings = earnings;
    }

    public String getPayheadname() {
        return payheadname;
    }

    public void setPayheadname(String payheadname) {
        this.payheadname = payheadname;
    }

    public String getSalaryMonth() {
        return salaryMonth;
    }

    public void setSalaryMonth(String salaryMonth) {
        this.salaryMonth = salaryMonth;
    }

    public String getPayAmount() {
        return payAmount;
    }

    public void setPayAmount(String payAmount) {
        this.payAmount = payAmount;
    }

    public double getEarningsTotal() {
        return earningsTotal;
    }

    public void setEarningsTotal(double earningsTotal) {
        this.earningsTotal = earningsTotal;
    }

    public double getDeductionsTotal() {
        return deductionsTotal;
    }

    public void setDeductionsTotal(double deductionsTotal) {
        this.deductionsTotal = deductionsTotal;
    }

    public double getNetSalary() {
        return netSalary;
    }

    public void setNetSalary(double netSalary) {
        this.netSalary = netSalary;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public double getMonthlySalary() {
        return monthlySalary;
    }

    public void setMonthlySalary(double monthlySalary) {
        this.monthlySalary = monthlySalary;
    }

    public long getPaidDays() {
        return paidDays;
    }

    public void setPaidDays(long paidDays) {
        this.paidDays = paidDays;
    }
}
