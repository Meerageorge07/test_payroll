package com.example.payroll_management.serviceImpl;

import com.example.payroll_management.entity.PayheadAmount;
import com.example.payroll_management.entity.Salary;
import com.example.payroll_management.entity.employees;
import com.example.payroll_management.entity.payheads;
import com.example.payroll_management.enums.paytype;
import com.example.payroll_management.repository.PayheadAmountRepository;
import com.example.payroll_management.repository.SalaryRepository;
import com.example.payroll_management.repository.payheadsRepo;
import com.example.payroll_management.repository.usersRepo;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.Console;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.logging.Logger;

@Service
@Transactional

public class payHeadService {
    @Autowired
    private payheadsRepo payheadsRepo;
    @Autowired
    private usersRepo usersRepo;
    @Autowired
    private SalaryRepository SalaryRepository;
    @Autowired
    private PayheadAmountRepository  payheadAmountRepository;


    public List<payheads> getEarnings() {
        return payheadsRepo.findByPaytype(paytype.Earnings);
    }

    public List<payheads> getDeductions() {
        return payheadsRepo.findByPaytype(paytype.Deductions);
    }
    public List<payheads> getEarningsAndDeductions(String empCode) {
        List<payheads> earnings = payheadsRepo.findByPaytype(paytype.Earnings);
        List<payheads> deductions = payheadsRepo.findByPaytype(paytype.Deductions);
        // Combine earnings and deductions
        List<payheads> payheads = new ArrayList<>();
        payheads.addAll(earnings);
        payheads.addAll(deductions);
        return payheads;
    }
    //first one and almost correct**************************+++++=================
//@Transactional
//    public void updateEarningsAndDeductions(String empCode, Map<String, Double> earningsMap, Map<String, Double> deductionsMap) {
//        List<Salary> salaries =SalaryRepository.findByEmployeesEmpCode(empCode);
//
//        for (Salary salary : salaries) {
//            double totalEarnings=0;
//           // double totalEarnings = salary.getEarningsTotal();
//            double totalDeductions = salary.getDeductionsTotal();
//
//            for (Map.Entry<String, Double> entry : earningsMap.entrySet()) {
//                totalEarnings += entry.getValue();
//                System.out.println(totalEarnings);
//
//            }
//
//            for (Map.Entry<String, Double> entry : deductionsMap.entrySet()) {
//                totalDeductions += entry.getValue();
//                System.out.println(totalDeductions);
//            }
//
//            salary.setDeductionsTotal(totalDeductions);
//           salary.setEarnings(totalEarnings);
//            //   salary.setDeductionsTotal(totalDeductions);
//            //double netSalary = totalEarnings - totalDeductions - salary.getTaxes();
//           // salary.setNetSalary(netSalary);
//
//            SalaryRepository.save(salary);
//        }
//    }
    ////////////////////////////////////////////////////////////////////////////

//public void updateEarningsAndDeductions(String empCode, Map<String, Double> earningsMap, Map<String, Double> deductionsMap) {
//    List<Salary> salaries = SalaryRepository.findByEmployeesEmpCode(empCode);
//
//    salaries.forEach(salary -> {
//        // Calculate total earnings
//        double totalEarnings = earningsMap.values().stream()
//                .mapToDouble(Double::doubleValue)
//                .sum();
//
//        // Calculate total deductions
//        double totalDeductions = salary.getDeductionsTotal() +
//                deductionsMap.values().stream()
//                        .mapToDouble(Double::doubleValue)
//                        .sum();
//
//        // Update salary object with new totals
//        salary.setEarningsTotal(totalEarnings);
//        salary.setDeductionsTotal(totalDeductions);
//
//        // Save updated salary object
//       SalaryRepository.save(salary);
//    });
//}


private static final Logger logger = Logger.getLogger(SalaryService.class.getName());
@Transactional
    public void updateEarningsAndDeductions(String empCode, Map<String, Double> earningsMap, Map<String, Double> deductionsMap) {
        // Fetching the salaries
        List<Salary> salaries = SalaryRepository.findByEmployeesEmpCode(empCode);

        // Check if salaries are found
        if (salaries.isEmpty()) {
            logger.warning("No salaries found for empCode: " + empCode);
            return;
        }

        // Logging found salaries
        logger.info("Found " + salaries.size() + " salaries for empCode: " + empCode);

        salaries.forEach(salary -> {
            // Calculate total earnings
            double totalEarnings = 0;
            double totalDeductions = 0;

             totalEarnings = earningsMap.values().stream()
                    .mapToDouble(Double::doubleValue)
                    .sum();

            // Calculate total deductions
           //  totalDeductions = salary.getDeductionsTotal() +
             totalDeductions   =    deductionsMap.values().stream()
                            .mapToDouble(Double::doubleValue)
                            .sum();

            // Logging calculations
            logger.info("Updating salary ID: " + salary.getId());
            logger.info("Total Earnings: " + totalEarnings);
            logger.info("Total Deductions: " + totalDeductions);

            // Update salary object with new totals
            salary.setEarnings(totalEarnings);
            salary.setDeductionsTotal(totalDeductions);

            // Save updated salary object
            SalaryRepository.save(salary);
        });
    }
}


